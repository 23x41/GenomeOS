#!/bin/sh
# build genome.img: kernel, init, shell, tools and programs, plus everything in home/
cd "$(dirname "$0")"
G=../GATCnux.py
for f in src/*.tpl; do python3 ../gen_aa.py $f ${f%.tpl}.aa 2>/dev/null || { echo "build failed: $f"; exit 1; }; done
B=""
for f in init gsh echo seq upper wc head yes grep ls cat cp mv rm rmdir mkdir touch df top edit debug; do B="$B /bin/$f=src/$f.aa"; done
for f in counta countb ask spin crash; do B="$B /bin/$f=$f.aa"; done
python3 $G mkimage genome.img --kernel ../kernel.aa $B \
  /bin/sak=../shell.aa /bin/shell=../shell.aa /bin/netkit=../netkit.aa /bin/dnakit=../dnakit.aa /bin/paint=../paint.aa /bin/life=../life.aa \
  --dir /home=home "$@"
