# yes [text]: the text (or y) on every line, forever - stop it with Ctrl+C
.include sys.inc
  .init
  GETARGS C
  @ARG F HAVE *
  'y' @ARG T 0 @ARG + T
:HAVE
:LP
  @ARG
:CH
  D F D EOL J
  W + CH B
:EOL
  ] CR LP B
