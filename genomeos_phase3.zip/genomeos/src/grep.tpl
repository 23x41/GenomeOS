# grep TEXT: the lines of its input that contain TEXT
.include sys.inc
.buf LN 512
  .init
  GETARGS C
:LINE
  0 $n T
:RD
  GETC D 0 L LAST *
  D 10 E EOL *
  $n F 510 / RDSKIP *
  $n F @LN A T $n PSTO RD B
:RDSKIP
  ! RD B
:EOL
  ! 0 $n F @LN A T TEST C LINE B
:LAST
  ! $n F END J
  0 $n F @LN A T TEST C
:END
  H
:TEST                      # print LN if ARG occurs in it
  0 $i T
:TI
  $i F @LN A F TNO J
  $i F @LN A @ARG
:TJ
  D F TYES J
  OVER F OVER F = TNEXT *
  + SWAP + SWAP TJ B
:TNEXT
  ] $i PSTO TI B
:TYES
  ] @LN
:TP
  D F D TPE J
  W + TP B
:TPE
  ] CR R
:TNO
  R
