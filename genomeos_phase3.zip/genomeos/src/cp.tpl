# cp SRC DST: copy a file (DST may be a directory)
.include sys.inc
.buf DST 256
  .init
  GETARGS C 0 $nap T
  NEXTARG C D USAGE J $src T
  NEXTARG C D USAGE J $dst T
  $dst F @DST STRCP C
  @DST ISDIR C NOTDIR J
  @DST $dst F STRLEN C A '/' OVER T + $src F BASENAME C SWAP STRCP C
:NOTDIR
  $src F %SA1 T 0 %SA2 T 9 FSYS C SFAIL J %SR1 F $in T
  @DST %SA1 T 1 %SA2 T 9 FSYS C DFAIL J %SR1 F $out T
:LP
  $in F %SA1 T @IOB %SA2 T 512 %SA3 T 10 FSYS C END J
  %SR1 F D END0 J
  $n T $out F %SA1 T @IOB %SA2 T $n F %SA3 T 11 FSYS C WFAIL J
  LP B
:END0
  !
:END
  $in F %SA1 T 12 FSYS C ! $out F %SA1 T 12 FSYS C ! H
:WFAIL
  "cp: " @DST OOPS C END B
:SFAIL
  "cp: " $src F OOPS C 1 Q
:DFAIL
  "cp: " @DST OOPS C 1 Q
:USAGE
  ! "usage: cp SOURCE DESTINATION" CR 1 Q
:STRCP                     # (src dst --)
  OVER F OVER T OVER F SCPE J
  + SWAP + SWAP STRCP B
:SCPE
  ] R
:STRLEN
  D
:SLN
  D F SLE J
  + SLN B
:SLE
  SWAP S R
