# =====================================================================
# debug PROGRAM [args]  --  the GenomeOS debugger
# Starts PROGRAM paused under the kernel's control (spawn flag 2) and lets you
# step it, stop it at breakpoints and look inside.  With a symbol file
# (/sym/PROGRAM, written by mkimage / genomefs put) addresses get their label
# names and $variables can be read and changed by name.
#   s [n] step   n next (over a CALL)   c continue   b X / d X / bl  breakpoints
#   l [X] list   st stack   bt calls   r registers   p X[=v] value   m X [n] memory
#   j X jump     restart   q quit      X = a number, a label or a variable
# Every instruction is shown in its codon colour (the palette paint uses).
# =====================================================================
.include sys.inc
.include opcodes.inc
.const SYMK 65552
.buf LINE 256
.buf W1 64
.buf W2 64
.buf W3 64
.buf PROG 64
.buf PARGS 128
.buf SYMP 80
.buf LADDR 3000
.buf LNAME 3000
.buf VADDR 1000
.buf VNAME 1000
.buf BRK 32
  .init
  4138 F 18003 = NOFS *
  GETARGS C 0 $nap T
  NEXTARG C D USAGE J @PROG SCOPY C
  0 @PARGS T $nap F D NOARGS J
  F NOARGS J
  $nap F @PARGS SCOPY C
:NOARGS
  0 $nbrk T 0 $nl T 0 $nv T
  LOADSYM C
  27 W "[1;36mGATC debugger" 27 W "[0m  " @PROG PRINTS C
  $nl F NOSYM J
  "   " $nl F Y " labels, " $nv F Y " variables" CR DSTART B
:NOSYM
  "   (no symbols: /sym/" @PROG BASENAME C PRINTS C " not found - addresses only)" CR
:DSTART
  START C
  "type h for help.  The program is paused at its first instruction." CR
  SHOWPC C
:PROMPT
  27 W "[1;35mdbg" 27 W "[0m> "
  READLINE C DQUIT0 J
  SPLIT C
  @W1 F PROMPT J
  @W1 @"h" STREQ C @W1 @"help" STREQ C O CHELP *
  @W1 @"q" STREQ C @W1 @"quit" STREQ C O CQUIT *
  @W1 @"restart" STREQ C CRESTART *
  $alive F DEAD J
  @W1 @"s" STREQ C @W1 @"step" STREQ C O CSTEP *
  @W1 @"n" STREQ C @W1 @"next" STREQ C O CNEXT *
  @W1 @"c" STREQ C @W1 @"cont" STREQ C O CCONT *
  @W1 @"b" STREQ C @W1 @"break" STREQ C O CBREAK *
  @W1 @"d" STREQ C @W1 @"delete" STREQ C O CDEL *
  @W1 @"bl" STREQ C CBLIST *
  @W1 @"l" STREQ C @W1 @"list" STREQ C O CLIST *
  @W1 @"st" STREQ C @W1 @"stack" STREQ C O CSTACK *
  @W1 @"bt" STREQ C CBT *
  @W1 @"r" STREQ C @W1 @"regs" STREQ C O CREGS *
  @W1 @"p" STREQ C @W1 @"print" STREQ C O CPRINT *
  @W1 @"set" STREQ C CSET *
  @W1 @"m" STREQ C @W1 @"mem" STREQ C O CMEM *
  @W1 @"j" STREQ C @W1 @"jump" STREQ C O CJUMP *
  "unknown command " @W1 PRINTS C " (h for help)" CR PROMPT B
:DEAD
  "the program has ended: restart, or q" CR PROMPT B
:USAGE
  ! "usage: debug PROGRAM [arguments]" CR 1 Q
:NOFS
  "debug runs inside GenomeOS" CR 1 Q
:DQUIT0
  CR
:CQUIT
  $alive F CQBYE J
  $pid F %SA1 T 104 %SNUM T $pid F %SA1 T 101 %SNUM T
:CQBYE
  H

# ---------------------------------------------------------------------
:SCOPY
  OVER F OVER T OVER F SCE J
  + SWAP + SWAP SCOPY B
:SCE
  ] R
:STREQ
  OVER F OVER F = SQN *
  OVER F SQY J
  + SWAP + SWAP STREQ B
:SQY
  ] 1 R
:SQN
  ] 0 R
:READLINE                  # ( -- ok)  a line into LINE
  0 $ln T
:RLLP
  GETC D 0 L RLEOF *
  D 10 E RLEND *
  $ln F 250 / RLSK *
  $ln F @LINE A T $ln PSTO RLLP B
:RLSK
  ! RLLP B
:RLEND
  ! 0 $ln F @LINE A T 1 R
:RLEOF
  ! 0 R
:WORD                      # (dst --)  next word of LINE at $lp
  $wd T
:WSK
  $lp F @LINE A F 32 E WSKY *
  $lp F @LINE A F '=' E WSKY *
  0 $wk T
:WCP
  $lp F @LINE A F D WEND J D 32 E WEND * D '=' E WEND *
  $wk F 62 / WSKC *
  $wk F $wd F A T $wk PSTO $lp PSTO WCP B
:WSKC
  ! $lp PSTO WCP B
:WSKY
  $lp PSTO WSK B
:WEND
  ! 0 $wk F $wd F A T R
:SPLIT
  0 $lp T @W1 WORD C @W2 WORD C @W3 WORD B
:ISNUM                     # (str -- flag)
  F D '0' / SWAP '9' ^ P R

# ---------------------------------------------------------------------
#  the program under test
# ---------------------------------------------------------------------
:START
  @PROG %SA1 T @PARGS %SA2 T 0 %SA3 T 2 %SA4 T 100 %SNUM T
  %SST F SFAIL J
  %SR1 F $pid T 1 $alive T 0 $i T
:SBRK                      # breakpoints carry over to a restart
  $i F $nbrk F / SRET *
  $i F @BRK A F 1 BRKSET C $i PSTO SBRK B
:SRET
  R
:SFAIL
  "debug: cannot start " @PROG PRINTS C " (try ls /bin)" CR 1 Q
:CRESTART
  $alive F CRS2 J
  $pid F %SA1 T 104 %SNUM T $pid F %SA1 T 101 %SNUM T
:CRS2
  START C "restarted " @PROG PRINTS C CR SHOWPC C PROMPT B
:DBG                       # (a2 number -- status)  a debug call on $pid
  SWAP %SA2 T $pid F %SA1 T %SNUM T %SST F R
:REGS                      # sets $pc $depth $calls $steps
  0 114 DBG C ! %SR1 F $pc T %SR2 F $depth T %SR3 F $calls T %SR4 F $steps T R
:CODE                      # (addr -- op)  $imm too; 0 outside the program
  119 DBG C ! %SR2 F $imm T %SR3 F $plen T %SR1 F R
:BRKSET                    # (addr on --)
  %SA3 T 120 DBG C ! R
:RUN                       # (steps --)  run, then say why it stopped
  113 DBG C ! %SR1 F $why T %SR2 F $code T
  $why F 3 E RENDED *
  $why F 2 E RBREAK *
  $why F 4 E RINT *
  SHOWPC B
:RBREAK
  27 W "[1;33mbreakpoint" 27 W "[0m" CR SHOWPC B
:RINT
  27 W "[1;33mpaused (Ctrl+C)" 27 W "[0m" CR SHOWPC B
:RENDED
  0 $alive T 27 W "[1;31mthe program ended" 27 W "[0m with exit code " $code F Y CR R

# ---------------------------------------------------------------------
#  symbols: /sym/NAME, lines "ADDR LABEL", "V ADDR var", "B ADDR buffer"
# ---------------------------------------------------------------------
:LOADSYM
  @"/sym/" @SYMP SCOPY C @PROG BASENAME C @SYMP 5 A SCOPY C
  @SYMP %SA1 T 0 %SA2 T 9 FSYS C LSNO J
  %SR1 F $fd T 0 $sn T
:LSRD
  $fd F %SA1 T @IOB %SA2 T 512 %SA3 T 10 FSYS C LSRDE J
  %SR1 F D LSRDE0 J $got T 0 $i T
:LSCP
  $i F $got F / LSNX *
  $i F @IOB A F $sn F $i F A %SYMK A T $i PSTO LSCP B
:LSNX
  $sn F $got F A $sn T LSRD B
:LSRDE0
  !
:LSRDE
  $fd F %SA1 T 12 FSYS C ! 0 $p T
:LSLINE
  $p F $sn F / LSNO *
  $p F %SYMK A F D 'V' E SWAP 'B' E O $p F + %SYMK A F 32 E P LSVAR *
  $p F PNUM C $la T
  $nl F 3000 / LSSKIP *
  $la F $nl F @LADDR A T $p F $nl F @LNAME A T $nl PSTO LSSKIP B
:LSVAR
  $p F 2 A $p T $p F PNUM C $la T
  $nv F 1000 / LSSKIP *
  $la F $nv F @VADDR A T $p F $nv F @VNAME A T $nv PSTO
:LSSKIP                    # to the end of the line; the newline becomes a 0
  $p F $sn F / LSNO *
  $p F %SYMK A F 10 E LSEOL *
  $p PSTO LSSKIP B
:LSEOL
  0 $p F %SYMK A T $p PSTO LSLINE B
:LSNO
  R
:PNUM                      # (pos -- n)  digits at SYMK+pos; $p ends after the space
  $p T 0
:PNLP
  $p F %SYMK A F D '0' L PNEND * D '9' G PNEND *
  '0' S SWAP 10 M A $p PSTO PNLP B
:PNEND
  ! $p PSTO R
:LABELAT                   # (addr -- index | -1)  the last label at or before addr
  $lat T 0 1 S $lbest T 0 $li T
:LALP
  $li F $nl F / LARET *
  $li F @LADDR A F $lat F G LARET *
  $li F $lbest T $li PSTO LALP B
:LARET
  $lbest F R
:PRLOC                     # (addr --)  "LABEL+3" or the number
  D LABELAT C D 0 L PRLNUM *
  D @LNAME A F %SYMK A PRINTS C
  @LADDR A F S D PRLZ J
  "+" Y R
:PRLZ
  ! R
:PRLNUM
  ! Y R
:FINDSYM                   # (str -- addr | -1)  a label or a variable by name
  $fs T 0 $fi T
:FSL
  $fi F $nl F / FSV *
  $fi F @LNAME A F %SYMK A $fs F STREQ C FSLHIT *
  $fi PSTO FSL B
:FSLHIT
  $fi F @LADDR A F R
:FSV
  0 $fi T
:FSVL
  $fi F $nv F / FSNONE *
  $fi F @VNAME A F %SYMK A $fs F STREQ C FSVHIT *
  $fi PSTO FSVL B
:FSVHIT
  $fi F @VADDR A F R
:FSNONE
  0 1 S R
:ADDROF                    # (str -- addr | -1)  a number, a name, or a $name
  D ISNUM C ADNUM *
  D F '$' E ADDOLLAR *
  D F '@' E ADDOLLAR *
  FINDSYM B
:ADDOLLAR
  + FINDSYM B
:ADNUM
  ATOI B

# ---------------------------------------------------------------------
#  showing code
# ---------------------------------------------------------------------
:OPNAME                    # (op --)  coloured by its codon
  D 1 L OPBAD * D 64 G OPBAD *
  D - 3 M @opcodons A $oc T
  27 W "[1;38;5;" $oc F F CB C 16 M $oc F + F CB C 4 M A $oc F 2 A F CB C A XT C Y "m"
  - 7 M @opnames A 6 PRINTN C 27 W "[0m" R
:OPBAD
  ! "??????" R
:CB                        # (base letter -- 0-3)
  D 'C' E CB1 *
  D 'G' E CB2 *
  'T' E R
:CB1
  ! 1 R
:CB2
  ! 2 R
:XT                        # (codon -- xterm colour)
  D 4 > 3 P XL C 36 M OVER 2 > 3 P XL C 6 M A SWAP 3 P XL C A 16 A R
:XL                        # palette level, lifted two steps so every codon reads on a dark screen
  2 A R
:PRINTN                    # (str n --)  n characters
  D PNE J
  SWAP D F W + SWAP - PRINTN B
:PNE
  ] R
:ISBR                      # (op -- flag)  JMP CALL JZ JNZ
  D 2 E OVER 3 E O OVER 10 E O SWAP 37 E O R
:DISLINE                   # (addr --)  one instruction
  $da T
  $da F LABELAT C D 0 L DLNOL *
  D @LADDR A F $da F = DLNOL *
  27 W "[1;94m" @LNAME A F %SYMK A PRINTS C ":" 27 W "[0m" CR D
:DLNOL
  !
  $da F $pc F E DLCUR *
  "  " DLBRK B
:DLCUR
  27 W "[1;32m=>" 27 W "[0m"
:DLBRK
  $da F ISBREAK C DLSTAR *
  "  " DLADDR B
:DLSTAR
  27 W "[1;31m* " 27 W "[0m"
:DLADDR
  $da F 1 MAX NDIG C 6 SWAP S SPC C $da F Y "  "
  $da F CODE C D $op T D OPNAME C $imm F $dim T
  11 = DLNOIMM *
  " " $dim F LABELAT C $dli T
  $da F + CODE C ISBR C $dli F 0 L N P DLIMMN J
  $dli F @LADDR A F $dim F = DLIMMN *
  $dli F 27 W "[94m" @LNAME A F %SYMK A PRINTS C 27 W "[0m" CR R
:DLIMMN
  0 $vi T
:DLVL                      # an address of a $variable shows its name
  $vi F $nv F / DLNUM *
  $vi F @VADDR A F $dim F E DLVAR *
  $vi PSTO DLVL B
:DLVAR
  27 W "[96m$" $vi F @VNAME A F %SYMK A PRINTS C 27 W "[0m" CR R
:DLNUM
  $dim F Y
:DLNOIMM
  CR R
:NDIG
  1 SWAP
:NDL
  10 V D NDE J
  SWAP + SWAP NDL B
:NDE
  ! R
:SPC
  D 1 L SPCE *
  32 W - SPC B
:SPCE
  ! R
:ISBREAK                   # (addr -- flag)
  $ib T 0 $bi T
:IBL
  $bi F $nbrk F / IBNO *
  $bi F @BRK A F $ib F E IBYES *
  $bi PSTO IBL B
:IBYES
  1 R
:IBNO
  0 R
:SHOWPC                    # where it is, what is next, the top of the stack
  REGS C
  27 W "[2m" "  at " $pc F PRLOC C "   step " $steps F Y "   stack " $depth F Y "   calls " $calls F Y 27 W "[0m" CR
  $pc F DISLINE C
  $depth F SHOWSEL J
  27 W "[2m" "  stack:" 27 W "[0m" 0 $i T
:SPLP
  $i F $depth F / SPDONE *
  $i F 6 / SPMORE *
  " " $i F 115 DBG C ! %SR1 F Y $i PSTO SPLP B
:SPMORE
  " ..."
:SPDONE
  27 W "[2m" "   (top first)" 27 W "[0m" CR
:SHOWSEL
  R

# ---------------------------------------------------------------------
#  commands
# ---------------------------------------------------------------------
:ARGNUM                    # (default str -- n)
  D F ANDEF J
  SWAP ! ADDROF B
:ANDEF
  ! R
:CSTEP
  1 @W2 ARGNUM C 1 MAX RUN C PROMPT B
:CNEXT                     # step over a CALL: run to the instruction after it
  REGS C $pc F CODE C 3 = CSTEP *
  $pc F + ISBREAK C CNHAS *
  $pc F + 1 BRKSET C 0 RUN C
  $alive F PROMPT J
  $pc F REGS C ! $pc F ISBREAK C PROMPT *
  REGSAFTER B
:REGSAFTER
  $pc F 0 BRKSET C PROMPT B
:CNHAS
  0 RUN C PROMPT B
:CCONT
  0 RUN C PROMPT B
:CBREAK
  @W2 F CBLIST J
  @W2 ADDROF C D 0 L BADSYM *
  D ISBREAK C CBHAVE *
  $nbrk F 31 / CBFULL *
  D $nbrk F @BRK A T $nbrk PSTO
  D 1 BRKSET C
  "breakpoint at " D Y " " PRLOC C CR PROMPT B
:CBHAVE
  ! "there is one already" CR PROMPT B
:CBFULL
  ! "32 breakpoints at most" CR PROMPT B
:BADSYM
  ! "no such address, label or variable: " @W2 PRINTS C CR PROMPT B
:CDEL
  @W2 ADDROF C D 0 L BADSYM *
  $db T 0 $bi T
:CDLP
  $bi F $nbrk F / CDNO *
  $bi F @BRK A F $db F E CDHIT *
  $bi PSTO CDLP B
:CDHIT
  $nbrk F - $nbrk T $nbrk F @BRK A F $bi F @BRK A T
  $db F 0 BRKSET C "deleted" CR PROMPT B
:CDNO
  "no breakpoint there" CR PROMPT B
:CBLIST
  $nbrk F CBLNONE J
  0 $bi T
:CBLL
  $bi F $nbrk F / PROMPT *
  "  * " $bi F @BRK A F D Y "  " PRLOC C CR $bi PSTO CBLL B
:CBLNONE
  "no breakpoints (b LABEL or b ADDRESS)" CR PROMPT B
:CLIST
  REGS C
  $pc F 3 S 0 MAX @W2 ARGNUM C $la T 0 $i T
:CLLP
  $i F 14 / PROMPT *
  $la F $i F A CODE C D CLEND J !
  $la F $i F A DISLINE C $i PSTO CLLP B
:CLEND
  ! PROMPT B
:CSTACK
  REGS C $depth F CSTE J
  "  depth " $depth F Y "   (top first)" CR 0 $i T
:CSLP
  $i F $depth F / PROMPT *
  $i F 16 / CSMORE *
  "  [" $i F Y "]  " $i F 115 DBG C ! %SR1 F Y CR $i PSTO CSLP B
:CSMORE
  "  ..." CR PROMPT B
:CSTE
  "  the stack is empty" CR PROMPT B
:CBT
  REGS C "  #0  " $pc F PRLOC C "   (here)" CR 0 $i T
:CBTL
  $i F $calls F / PROMPT *
  $i F 116 DBG C ! %SR1 F $ra T
  "  #" $i F + Y "  " $ra F - PRLOC C "   (returns to " $ra F Y ")" CR $i PSTO CBTL B
:CREGS
  REGS C "  pc " $pc F Y "  (" $pc F PRLOC C ")   stack depth " $depth F Y "   call depth " $calls F Y "   steps " $steps F Y CR PROMPT B
:CPRINT                    # p X  or  p X=V  (X: $var, label, number)
  @W2 F CPUSE J
  @W2 ADDROF C D 0 L BADSYM *
  $pa T
  @W3 F CPSHOW J
  $pa F %SA2 T @W3 ATOI C @LINE F '-' = CPPOS *
  @W3 F '-' E CPNEG *
:CPPOS
  @W3 ATOI C
:CPPUT
  %SA3 T $pid F %SA1 T 118 %SNUM T
:CPSHOW
  "  " @W2 PRINTS C " @" $pa F Y " = " $pa F 117 DBG C ! %SR1 F Y CR PROMPT B
:CPNEG
  ! 0 @W3 + ATOI C S CPPUT B
:CPUSE
  "usage: p $count   p 1200   p $count=5" CR PROMPT B
:CSET
  @W2 F CPUSE J
  @W3 F CPUSE J
  CPRINT B
:CMEM
  @W2 F CMUSE J
  @W2 ADDROF C D 0 L BADSYM *
  $ma T 16 @W3 ARGNUM C 256 MIN $mn T 0 $i T
:CMLP
  $i F $mn F / CMEND *
  $i F 7 P CMNOADDR *
  "  " $ma F $i F A 6 SWAP D NDIG C ROT SWAP S SPC C Y ":"
:CMNOADDR
  " " $ma F $i F A 117 DBG C ! %SR1 F Y
  $i F 7 P 7 = CMNONL *
  CR
:CMNONL
  $i PSTO CMLP B
:CMEND
  $i F 7 P CMEOL J
  CR
:CMEOL
  PROMPT B
:CMUSE
  "usage: m ADDRESS [count]   (or a $variable / buffer name)" CR PROMPT B
:CJUMP
  @W2 F CJUSE J
  @W2 ADDROF C D 0 L BADSYM *
  121 DBG C ! SHOWPC C PROMPT B
:CJUSE
  "usage: j ADDRESS or LABEL" CR PROMPT B
:CHELP
  27 W "[1mGATC debugger" 27 W "[0m" CR
  "  s [n]      step n instructions (default 1)     n         next: step over a CALL" CR
  "  c          continue to a breakpoint / the end  Ctrl+C    pause the program" CR
  "  b X        breakpoint at X   d X  delete it    bl        list breakpoints" CR
  "  l [X]      list code at X (default: here)      bt        the call stack" CR
  "  st         the data stack                      r         registers" CR
  "  p X        a value   p X=v  change it          m X [n]   memory from X" CR
  "  j X        continue from X (jump)              restart   start again" CR
  "  q          quit      X: a number, a label (LOOP) or a variable ($count)" CR
  PROMPT B
