# rmdir NAME ...: remove empty directories
.include sys.inc
  .init
  GETARGS C 0 $nap T 0 $bad T
  NEXTARG C D USAGE J
:DOONE
  D %SA1 T 6 FSYS C OK *
  "rmdir: " OOPS C 1 $bad T NEXT B
:OK
  !
:NEXT
  NEXTARG C D DOONE *
  ! $bad F Q
:USAGE
  ! "usage: rmdir NAME ..." CR 1 Q
