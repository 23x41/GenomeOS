# cat [file ...]: files (or the input) to the output
.include sys.inc
  .init
  GETARGS C 0 $nap T
  NEXTARG C D STDIN J
  CATONE C
:MORE
  NEXTARG C D DONE J
  CATONE C MORE B
:STDIN
  !
:SLP
  GETC D 0 L DONE *
  W SLP B
:DONE
  ! H
:CATONE                    # (path --)
  D $cp T %SA1 T 0 %SA2 T 9 FSYS C CFAIL J
  %SR1 F $fd T
:CLP
  $fd F %SA1 T @IOB %SA2 T 512 %SA3 T 10 FSYS C CEND J
  %SR1 F D CEND0 J
  1 %SA1 T @IOB %SA2 T %SA3 T 11 FSYS C ! CLP B
:CEND0
  !
:CEND
  $fd F %SA1 T 12 FSYS C ! R
:CFAIL
  "cat: " $cp F OOPS B
