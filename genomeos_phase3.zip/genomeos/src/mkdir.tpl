# mkdir [-p] DIR ...: make directories (-p: with their parents, no error if they exist)
.include sys.inc
  .init
  GETARGS C 0 $nap T 0 $bad T 0 $par T
  NEXTARG C D USAGE J
  D F '-' E OVER + F 'p' E P NOTP J
  ! 1 $par T NEXTARG C D USAGE J
:NOTP
:DOONE
  D %SA1 T $par F %SA2 T 5 FSYS C OK *
  "mkdir: " OOPS C 1 $bad T NEXT B
:OK
  !
:NEXT
  NEXTARG C D DOONE *
  ! $bad F Q
:USAGE
  ! "usage: mkdir [-p] DIR ..." CR 1 Q
