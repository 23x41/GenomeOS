# df: how full the disk is
.include sys.inc
  .init
  @"/" %SA1 T 26 FSYS C !
  "GenomeFS  " %SR1 F 1024 V Y " KiB in all, " %SR1 F %SR2 F S 1024 V Y " KiB used, " %SR2 F 1024 V Y " KiB free" CR H
