# =====================================================================
# gsh  --  the GenomeOS shell
#   prog args            run /bin/prog (or a /full/path)
#   a | b | c            a pipeline: each program's output is the next one's input
#   prog &               run in the background
#   built in: help cd pwd ps kill sleep uname echo clear exit poweroff
# Ctrl+C stops the running job, Ctrl+D on an empty line ends the session.
# =====================================================================
.include sys.inc
.buf LINE 256
.buf SEGS 16
.buf ARGP 16
.buf PIDS 16
.buf PIPES 16
.buf NAME 64
.str s_help "help"
.str s_cd "cd"
.str s_pwd "pwd"
.str s_home "/home"
.buf CWD 256
.buf RFILE 128
.str s_ps "ps"
.str s_kill "kill"
.str s_sleep "sleep"
.str s_uname "uname"
.str s_echo "echo"
.str s_clear "clear"
.str s_exit "exit"
.str s_poweroff "poweroff"
  .init
  1 %SA1 T 112 %SNUM T                # Ctrl+C: a fresh prompt instead of stopping the shell
  @s_home %SA1 T 14 %SNUM T            # start in /home
  27 W "[1;32mgsh" 27 W "[0m - the GenomeOS shell.  Type " 27 W "[1mhelp" 27 W "[0m for the commands." CR
:PROMPT
  @CWD %SA1 T 250 %SA2 T 15 %SNUM T
  27 W "[1;32mgenome" 27 W "[0m:" 27 W "[1;34m" @CWD PUTS C 27 W "[0m$ "
  0 $n T
:RD
  GETC D 0 L EOFIN *
  D 10 E GOT *
  $n F 250 / RDSKIP *
  $n F @LINE A T $n PSTO RD B
:RDSKIP
  ! RD B
:EOFIN
  ! $n F GOT0 *
  CR "logout" CR 99 Q
:GOT
  !
:GOT0
  0 $n F @LINE A T
  REDIR C
  PARSE C
  $nseg F PROMPT J
  $nseg F 1 E BUILTIN *
  RUN C PROMPT B
:BUILTIN
  @SEGS F @s_help STREQ C BHELP *
  @SEGS F @s_cd STREQ C BCD *
  @SEGS F @s_pwd STREQ C BPWD *
  @SEGS F @s_ps STREQ C BPS *
  @SEGS F @s_kill STREQ C BKILL *
  @SEGS F @s_sleep STREQ C BSLEEP *
  @SEGS F @s_uname STREQ C BUNAME *
  @SEGS F @s_clear STREQ C BCLEAR *
  @SEGS F @s_exit STREQ C BEXIT *
  @SEGS F @s_poweroff STREQ C BOFF *
  RUN C PROMPT B

# ---------------------------------------------------------------------
:STREQ                     # (a b -- flag)
  OVER F OVER F = SQNO *
  OVER F SQYES J
  + SWAP + SWAP STREQ B
:SQYES
  ] 1 R
:SQNO
  ] 0 R
:PUTS                      # (str --)
  D F D PSE J
  W + PUTS B
:PSE
  ] R
:SPACES                    # (n --)
  D 1 L SPE *
  32 W - SPACES B
:SPE
  ! R
:PADN                      # (n width --)  right-aligned number
  OVER 0 MAX $pdv T 1 $pdd T
:PDLP
  $pdv F 10 V D $pdv T PDGO J
  $pdd PSTO PDLP B
:PDGO
  $pdd F S SPACES C Y R
:SKIPSP                    # (addr -- addr)  past spaces
  D F 32 E SKIPGO *
  R
:SKIPGO
  + SKIPSP B

:REDIR                     # "> file" or ">> file" at the end of the line
  0 $rapp T 0 @RFILE T @LINE $p T
:RDLP
  $p F F D RDRET J '>' E RDGOT *
  $p PSTO RDLP B
:RDGOT
  0 $p F T $p PSTO
  $p F F '>' = RDONE *
  1 $rapp T $p PSTO
:RDONE
  $p F SKIPSP C @RFILE
:RDCP
  OVER F D 33 L RDCPE *
  OVER T + SWAP + SWAP RDCP B
:RDCPE
  ! 0 SWAP T !
  R
:RDRET
  ! R
:PARSE                     # LINE -> segments: SEGS command, ARGP arguments; $bg
  0 $nseg T 0 $bg T
  @LINE $p T
:PSEG
  $p F SKIPSP C $p T
  $p F F PSEND J
  $p F F '|' E PSEMPTY *
  $p F F '&' E PSAMP *
  $p F $nseg F @SEGS A T
:PWORD                     # the command word
  $p F F D PWEND J D 32 E PWEND * D '|' E PWEND * '&' E PWEND2 *
  $p PSTO PWORD B
:PWEND
  !
:PWEND2
  $p F F $c T 0 $p F T
  $c F 32 E PARGS *
  0 $nseg F @ARGP A T $nseg PSTO
:DELIM                     # $c was at p (now 0): the end, | or &
  $c F PSEND J
  $c F '&' E PSAMP *
  PSEMPTY B
:PNOARG
  0 $nseg F @ARGP A T $nseg PSTO PSEG B
:PARGS                     # arguments run to | or & or the end
  $p PSTO $p F SKIPSP C $p T
  $p F F '|' E $p F F '&' E O $p F F N O PNOARG *
  $p F $nseg F @ARGP A T
:PALP
  $p F F D PAEND J D '|' E PAEND * '&' E PAEND2 *
  $p PSTO PALP B
:PAEND
  !
:PAEND2
  $p F $pe T
:PATRIM                    # drop trailing spaces of the arguments
  $pe F $nseg F @ARGP A F G PATDONE J
  $pe F - F 32 = PATDONE *
  $pe F - $pe T PATRIM B
:PATDONE
  $p F F $c T 0 $pe F T
  $nseg PSTO DELIM B
:PSEMPTY                   # | : the next segment
  $p PSTO PSEG B
:PSAMP
  1 $bg T $p PSTO PSEG B
:PSEND
  R

:RUN                       # start the pipeline, wait for it unless it was &
  0 $i T
:RPIPES                    # one pipe between each pair
  $i F $nseg F - / RSPAWN *
  110 %SNUM T %SST F RNOPIPE J
  %SR1 F $i F @PIPES A T $i PSTO RPIPES B
:RNOPIPE
  "gsh: no free pipe" CR R
:RSPAWN
  0 $i T
:RSLP
  $i F $nseg F / RWAIT *
  $i F @SEGS A F %SA1 T
  $i F @ARGP A F %SA2 T
  0 $i F RSIN J
  ! $i F - @PIPES A F
:RSIN
  $i F $nseg F - / RSNOOUT *
  $i F @PIPES A F 8 < O
:RSNOOUT
  %SA3 T
  $i F $nseg F - E @RFILE F BOOL P RSNORD J
  %SA3 F $sa3 T
  @RFILE %SA1 T $rapp F %SA2 T 20 %SNUM T %SST F RSRDOK *
  "gsh: " @RFILE PUTS C ": cannot write there" CR 0 $i F @PIDS A T RWAIT B
:RSRDOK
  $i F @SEGS A F %SA1 T $i F @ARGP A F %SA2 T $sa3 F %SA3 T
:RSNORD
  $bg F %SA4 T 100 %SNUM T
  %SST F RSFAIL J
  %SR1 F $i F @PIDS A T
  0 %SA1 T 20 %SNUM T                  # our own output back to the screen
  $i PSTO RSLP B
:RSFAIL
  0 %SA1 T 20 %SNUM T
  "gsh: " $i F @SEGS A F PUTS C ": no such program (try ls)" CR
  0 $i F @PIDS A T $i PSTO RSLP B
:RWAIT
  $bg F RBG *
  0 $i T 0 $code T
:RWLP
  $i F $nseg F / RWDONE *
  $i F @PIDS A F RWNX J
  $i F @PIDS A F %SA1 T 101 %SNUM T %SR1 F $code T
:RWNX
  $i PSTO RWLP B
:RWDONE
  $code F RCLOSE J
  $code F 130 E RCLOSE *
  27 W "[2m[exit " $code F Y "]" 27 W "[0m" CR
:RCLOSE
  0 $i T
:RCLP
  $i F $nseg F - / RCRET *
  $i F @PIPES A F %SA1 T 111 %SNUM T $i PSTO RCLP B
:RCRET
  R
:RBG
  "[" $nseg F - @PIDS A F Y "] running in the background" CR R

# ---------------------------------------------------------------------
#  built-in commands
# ---------------------------------------------------------------------
:BHELP
  27 W "[1mGenomeOS shell" 27 W "[0m" CR
  "  prog args         run /bin/prog          a | b | c   pipe one into the next" CR
  "  prog &            run in the background  Ctrl+C      stop the running job" CR
  "  cd DIR, pwd       move around            ps          the running processes" CR
  "  kill PID          stop a process         sleep N     wait N seconds" CR
  "  uname             about the system       prog > FILE into a file (>> adds)" CR
  "  clear             clear the screen       exit        a new shell" CR
  "  poweroff          shut down              Ctrl+D      end of input" CR
  "files: ls cat cp mv rm mkdir rmdir touch df  - and sak, the swiss army knife" CR
  "tools: edit FILE   debug PROG   top   shell   netkit (boot with --net)" CR
  "DNA:   dnakit, paint, life                try:  ls /bin   seq 20 | grep 1 > x" CR
  "keys:  Up/Down history   Tab completes   Left/Right/Home/End edit the line" CR
  PROMPT B
:BCD                       # cd [dir]  (no dir: /home)
  @ARGP F D BCDGO *
  ! @s_home
:BCDGO
  D %SA1 T 14 %SNUM T %SST F BCDOK *
  "cd: " PUTS C ": " %SR1 F %SA1 T @NAME %SA2 T 60 %SA3 T 19 %SNUM T @NAME PUTS C CR PROMPT B
:BCDOK
  ! PROMPT B
:BPWD
  @CWD %SA1 T 250 %SA2 T 15 %SNUM T @CWD PUTS C CR PROMPT B
:STRLEN                    # (a -- n)
  D
:SLLP
  D F SLEND J
  + SLLP B
:SLEND
  SWAP S R
:BPS
  27 W "[1m  PID  PARENT  STATE        STEPS  PROGRAM" 27 W "[0m" CR
  0 $i T
:BPSLP
  $i F %SA1 T @NAME %SA2 T 103 %SNUM T
  %SST F BPSEND J
  %SR1 F BPSNX J
  %SR1 F 5 PADN C %SR3 F 8 PADN C "  " %SR2 F STATENAME C %SR4 F 13 PADN C "  " @NAME PUTS C CR
:BPSNX
  $i PSTO BPSLP B
:BPSEND
  PROMPT B
:STATENAME                 # (state --)  9 characters
  D 1 E SNRUN *
  D 2 E SNIN *
  D 3 E SNIN *
  D 4 E SNWAIT *
  D 5 E SNZ *
  D 6 E SNSL *
  D 7 E SNKEY *
  D 11 E SNDY *
  ! "pipe     " R
:SNRUN
  ! "running  " R
:SNIN
  ! "reading  " R
:SNWAIT
  ! "waiting  " R
:SNZ
  ! "finished " R
:SNSL
  ! "sleeping " R
:SNKEY
  ! "keyboard " R
:SNDY
  ! "stopping " R
:BKILL
  @ARGP F D BKNO J
  ATOI C D $kp T %SA1 T 104 %SNUM T
  %SST F BKBAD J
  "killed " $kp F Y CR PROMPT B
:BKBAD
  "kill: " $kp F Y %SR1 F 1 E BKPERM *
  ": no such process" CR PROMPT B
:BKPERM
  ": init cannot be stopped" CR PROMPT B
:BKNO
  ! "usage: kill PID   (see ps)" CR PROMPT B
:BSLEEP
  @ARGP F D BSL0 J
  ATOI C
:BSL0
  1000 M %SA1 T 105 %SNUM T PROMPT B
:BUNAME
  107 %SNUM T
  "GenomeOS, kernel " %SR2 F Y " on the GATC machine: up " %SR3 F 1000 V Y " s, " %SR4 F Y " processes" CR
  PROMPT B
:BCLEAR
  27 W "[2J" 27 W "[H" PROMPT B
:BEXIT
  0 Q
:BOFF
  0 %SA1 T 109 %SNUM T H
