# top: the running processes, live.  q quits.
.include sys.inc
.include ui.inc
.buf NAME 64
.buf PREVS 16
.buf PREVP 16
.buf RATE 16
  .init
  4153 F 18516 = NOTTY *
  RAWON C ESCB C @"2J" OBS C TICKS C $t0 T
:LOOP
  TSIZE C TICKS C D $t0 F S 1 MAX $dt T $t0 T
  107 %SNUM T %SR3 F 1000 V $up T %SR4 F $np T
  @"/" %SA1 T 26 FSYS C ! %SR2 F 1024 V $free T
  1 1 GOTO C 2 BGC C 63 FGC C BOLDON C @" GenomeOS top " OBS C RST C
  @"  up " OBS C $up F OBN C @" s   " OBS C $np F OBN C @" processes   " OBS C
  $free F OBN C @" KiB free   " OBS C DIM C @"q quits" OBS C RST C CLREOL C
  3 1 GOTO C 21 BGC C 63 FGC C @"   PID PARENT STATE         STEPS    STEPS/S  CPU                     PROGRAM     " OBS C RST C CLREOL C
  0 $i T 0 $tot T
:PASS1                     # each process's rate since the last screen
  $i F 16 / P1END *
  $i F %SA1 T @NAME %SA2 T 103 %SNUM T
  0 $i F @RATE A T
  %SR1 F P1NX J
  %SR1 F $i F @PREVP A F = P1NEW *
  %SR4 F $i F @PREVS A F S 0 MAX 1000 M $dt F V D $i F @RATE A T $tot F A $tot T
:P1NEW
  %SR1 F $i F @PREVP A T %SR4 F $i F @PREVS A T
:P1NX
  $i PSTO PASS1 B
:P1END
  0 $i T 4 $row T
:PASS2
  $i F 16 / P2END *
  $row F $rows F - / P2END *
  $i F %SA1 T @NAME %SA2 T 103 %SNUM T
  %SR1 F P2NX J
  $row F 1 GOTO C
  %SR1 F 6 OBNP C %SR3 F 7 OBNP C 32 OBC C %SR2 F STATENAME C
  %SR4 F 11 OBNP C $i F @RATE A F 11 OBNP C 2 OBSP C
  $i F @RATE A F 100 M $tot F 1 MAX V $pct T
  $pct F 20 M 100 V $bar T 0 $j T
:BAR                       # 20 cells, coloured from green to red through the codon palette
  $j F 20 / BAREND *
  $j F $bar F L BARON *
  DIM C @"." OBS C BARNX B
:BARON
  $j F 8 L BARG *
  $j F 14 L BARY *
  48 FGC C @"|" OBS C BARNX B
:BARG
  12 FGC C @"|" OBS C BARNX B
:BARY
  60 FGC C @"|" OBS C
:BARNX
  $j PSTO BAR B
:BAREND
  RST C 2 OBSP C 31 FGC C @NAME OBS C RST C CLREOL C $row PSTO
:P2NX
  $i PSTO PASS2 B
:P2END
:CLR                       # clear what is left of the screen
  $row F $rows F / CLRE *
  $row F 1 GOTO C CLREOL C $row PSTO CLR B
:CLRE
  OBFLUSH C
  1000 KEY C D 'q' E TQUIT *
  D 'Q' E TQUIT *
  D 27 E TQUIT *
  D 0 L TQUIT *
  ! LOOP B
:TQUIT
  ! ESCB C @"2J" OBS C 1 1 GOTO C RAWOFF C H
:NOTTY
  "top needs the terminal (inside GenomeOS, or run it with --tty)" CR 1 Q
:STATENAME                 # (state --)  10 characters, coloured
  D 1 E SNRUN *
  D 2 E SNIN *
  D 3 E SNIN *
  D 4 E SNWAIT *
  D 5 E SNZ *
  D 6 E SNSL *
  D 7 E SNKEY *
  D 12 E SNSTOP *
  D 13 E SNWAIT *
  ! 10 FGC C @"pipe      " OBS C RST B
:SNRUN
  ! 40 FGC C @"running   " OBS C RST B
:SNIN
  ! 26 FGC C @"reading   " OBS C RST B
:SNWAIT
  ! 21 FGC C @"waiting   " OBS C RST B
:SNZ
  ! DIM C @"finished  " OBS C RST B
:SNSL
  ! 37 FGC C @"sleeping  " OBS C RST B
:SNKEY
  ! 26 FGC C @"keyboard  " OBS C RST B
:SNSTOP
  ! 52 FGC C @"debugged  " OBS C RST B
