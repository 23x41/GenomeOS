# ls [dir ...]: what is in a directory (default: here)
.include sys.inc
.buf NAME 64
  .init
  GETARGS C 0 $nap T 0 $many T
:LSFIRST
  NEXTARG C D LSHERE J
  D F '-' E LSSKIPOPT *
  LSONE C
:LSMORE
  NEXTARG C D DONE J
  LSONE C LSMORE B
:LSSKIPOPT
  ! LSFIRST B
:LSHERE
  ! @"." LSONE C H
:DONE
  ! H
:LSONE                     # (path --)  options (-l ...) are ignored: sizes are always shown
  D F '-' E LSOPT *
  D $lp T %SA1 T 2 FSYS C LSFAIL J
  %SR1 F $h T %SR2 F $cnt T 0 $i T
:LSLP
  $i F $cnt F / LSEND *
  $h F %SA1 T $i F %SA2 T @NAME %SA3 T 60 %SA4 T 3 FSYS C LSNX J
  %SR2 F 2 E LSDIR *
  "  " @NAME PRINTS C %SR1 F 22 S ~ 1 MAX $pad T
:LSPAD
  $pad F LSSZ J
  32 W $pad F - $pad T LSPAD B
:LSSZ
  %SR4 F Y " bytes" CR LSNX B
:LSDIR
  "  " 27 W "[1;34m" @NAME PRINTS C "/" 27 W "[0m" CR
:LSNX
  $i PSTO LSLP B
:LSEND
  $h F %SA1 T 4 FSYS C ! R
:LSFAIL
  "ls: " $lp F OOPS B
:LSOPT
  ! R
