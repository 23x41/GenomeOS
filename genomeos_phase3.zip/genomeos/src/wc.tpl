# wc: lines, words and bytes of its input
.include sys.inc
  .init
  0 $lines T 0 $words T 0 $bytes T 0 $inw T
:LP
  GETC D 0 L DONE *
  $bytes PSTO
  D 10 E NL *
:CHK
  D 33 L SPACE *
  ! $inw F WORDGO *
  1 $inw T $words PSTO LP B
:WORDGO
  LP B
:NL
  $lines PSTO CHK B
:SPACE
  ! 0 $inw T LP B
:DONE
  ! $lines F Y "  lines   " $words F Y "  words   " $bytes F Y "  bytes" CR H
