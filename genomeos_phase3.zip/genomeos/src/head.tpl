# head N: the first N lines of its input (default 10)
.include sys.inc
  .init
  GETARGS C @ARG ATOI C D HAVEN *
  ! 10
:HAVEN
  $n T
  $n F DONE J
:LP
  GETC D 0 L DONE *
  D W 10 E LINE *
  LP B
:LINE
  $n F - D $n T LP *
:DONE
  H
