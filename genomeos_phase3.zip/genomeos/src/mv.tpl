# mv SRC DST: move or rename (DST may be a directory)
.include sys.inc
.buf DST 256
  .init
  GETARGS C 0 $nap T
  NEXTARG C D USAGE J $src T
  NEXTARG C D USAGE J $dst T
  $dst F @DST STRCP C
  @DST ISDIR C NOTDIR J
  @DST $dst F STRLEN C A '/' OVER T + $src F BASENAME C SWAP STRCP C
:NOTDIR
  $src F %SA1 T @DST %SA2 T 8 FSYS C OK *
  "mv: " $src F OOPS C 1 Q
:OK
  H
:USAGE
  ! "usage: mv SOURCE DESTINATION" CR 1 Q
:STRCP
  OVER F OVER T OVER F SCPE J
  + SWAP + SWAP STRCP B
:SCPE
  ] R
:STRLEN
  D
:SLN
  D F SLE J
  + SLN B
:SLE
  SWAP S R
