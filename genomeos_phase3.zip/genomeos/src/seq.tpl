# seq N: the numbers 1 to N (default 10), one per line
.include sys.inc
  .init
  GETARGS C @ARG ATOI C D HAVEN *
  ! 10
:HAVEN
  $n T
  1
:LP
  D $n F G DONE *
  D Y CR + LP B
:DONE
  H
