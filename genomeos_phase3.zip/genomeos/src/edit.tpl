# =====================================================================
# edit FILE  --  a full-screen text editor for GenomeOS (and for --tty --fs)
#   arrows PgUp PgDn Home End, mouse click and wheel   move
#   typing, Enter, Tab, Backspace, Delete              change
#   ^S or ^O save   ^Q or ^X quit   ^F find (again: next)   ^G go to line
#   ^K cut the line (again: more lines)   ^U paste   ^Z undo   ^Y redo
# The text lives in the program's byte space (65536+, one byte per cell),
# so files of several MB fit; inserting and deleting use the VM's insert and
# delete (cell 4096, commands 2 and 3) and undo/redo use its history (6, 7, 13).
# .aa/.tpl files: labels and comments in colour.  .fa: bases in codon colours.
# =====================================================================
.include sys.inc
.include ui.inc
.const TB 65552
.const HCMD 4096
.const HA1 4097
.const HA2 4098
.const HSIZE 4099
.const HA3 4106
.buf FNAME 128
.buf FIND 64
.buf MSGB 100
.buf CLIP 4096
.buf CHUNK 4096
.buf IN 64
  .init
  4153 F 18516 = NOTTY *
  4138 F 18003 = NOFS *
  GETARGS C 0 $nap T
  NEXTARG C D USAGE J @FNAME SCOPY C
  0 $mode T @FNAME FNMODE C
  0 $n T 0 $c T 0 $top T 1 $topln T 0 $left T 0 $gcol T 0 $mod T 0 $clipn T 0 $lastk T
  16 SETSIZE C 14 %HCMD T
  FLOAD C
  RAWON C ESCB C @"?1002h" OBS C ESCB C @"?1006h" OBS C
  @"^S save  ^Q quit  ^F find  ^K cut  ^U paste  ^Z undo" SAY C
:LOOP
  TSIZE C $rows F 2 S $trows T $cols F 6 S $tcols T
  ADJUST C DRAW C
  0 KEY C D 0 L EQUIT *
  $k T DOKEY C
  $k F $lastk T
  LOOP B
:USAGE
  ! "usage: edit FILE" CR 1 Q
:NOTTY
  "edit needs the terminal (inside GenomeOS, or run it with --tty --fs)" CR 1 Q
:NOFS
  "edit needs file access (inside GenomeOS, or run it with --tty --fs)" CR 1 Q
:SCOPY                     # (src dst --)
  OVER F OVER T OVER F SCE J
  + SWAP + SWAP SCOPY B
:SCE
  ] R
:SAY                       # (str --)  message for the bottom line
  @MSGB SCOPY B
:ENDSWITH                  # (str suffix -- flag)
  $esx T $ess T
  $ess F STRLEN C $esx F STRLEN C S D 0 L ESNO *
  $ess F A $esx F STREQ B
:ESNO
  ! 0 R
:FNMODE                    # (name --)  1: GATC source  2: FASTA
  D @".aa" ENDSWITH C OVER @".tpl" ENDSWITH C O OVER @".inc" ENDSWITH C O FMAA *
  D @".fa" ENDSWITH C OVER @".fasta" ENDSWITH C O OVER @".fna" ENDSWITH C O FMFA *
  ! R
:FMAA
  ! 1 $mode T R
:FMFA
  ! 2 $mode T R
:STRLEN
  D
:STLP
  D F STLE J
  + STLP B
:STLE
  SWAP S R
:STREQ
  OVER F OVER F = SQN *
  OVER F SQY J
  + SWAP + SWAP STREQ B
:SQY
  ] 1 R
:SQN
  ] 0 R

# ---------------------------------------------------------------------
#  the text: bytes at TB, $n of them; the byte space is kept TB-65536+$n long
# ---------------------------------------------------------------------
:SETSIZE                   # (bytes in the byte space --)
  %HA1 T 11 %HCMD T R
:TX                        # (i -- byte)
  %TB A F R
:LSTART                    # (p -- start of its line)
  D LSRET J
  D - TX C 10 E LSRET *
  - LSTART B
:LSRET
  R
:LEND                      # (p -- the newline ending its line, or n)
  D $n F / LERET *
  D TX C 10 E LERET *
  + LEND B
:LERET
  R
:INSERT                    # (byte --)  at the cursor
  $ib T
  %TB 65536 S $c F A %HA1 T 1 %HA2 T 2 %HCMD T
  $ib F $c F %TB A T
  $n PSTO $c PSTO 1 $mod T
  $ib F 10 = INRET *
  $nl PSTO
:INRET
  R
:DELETE                    # the byte at the cursor
  $c F $n F / DLRET *
  $c F TX C 10 = DLNL *
  $nl F - $nl T
:DLNL
  %TB 65536 S $c F A %HA1 T 1 %HA2 T 3 %HCMD T
  $n F - $n T 1 $mod T
:DLRET
  R
:EDITSTART                 # one undo step per change
  7 %HCMD T R

# ---------------------------------------------------------------------
#  files
# ---------------------------------------------------------------------
:FLOAD
  @FNAME %SA1 T 0 %SA2 T 9 FSYS C LDNEW J
  %SR1 F $fd T 0 $n T
:LDLP
  $fd F %SA1 T @CHUNK %SA2 T 4096 %SA3 T 10 FSYS C LDEND J
  %SR1 F D LDEND0 J $got T
  %TB 65536 S $n F A $got F A SETSIZE C
  0 $i T
:LDCP
  $i F $got F / LDNX *
  $i F @CHUNK A F $n F $i F A %TB A T $i PSTO LDCP B
:LDNX
  $n F $got F A $n T LDLP B
:LDEND0
  !
:LDEND
  $fd F %SA1 T 12 FSYS C !
  1 $nl T 0 $i T
:LDCNT                     # count the lines
  $i F $n F / LDOK *
  $i F TX C 10 = LDCN *
  $nl PSTO
:LDCN
  $i PSTO LDCNT B
:LDOK
  14 %HCMD T R
:LDNEW
  1 $nl T 1 $newf T R
:SAVE                      # ( -- ok)
  @FNAME %SA1 T 1 %SA2 T 9 FSYS C SVFAIL J
  %SR1 F $fd T 0 $i T
:SVLP
  $i F $n F / SVDONE *
  $n F $i F S 4096 MIN $got T 0 $j T
:SVCP
  $j F $got F / SVW *
  $i F $j F A TX C $j F @CHUNK A T $j PSTO SVCP B
:SVW
  $fd F %SA1 T @CHUNK %SA2 T $got F %SA3 T 11 FSYS C SVWF J
  $i F $got F A $i T SVLP B
:SVDONE
  $fd F %SA1 T 12 FSYS C ! 0 $mod T 0 $newf T
  @MSGB @"saved " SCOPY C @MSGB D STRLEN C A $n F NUMSTR C @MSGB D STRLEN C A @" bytes" SCOPY C 1 R
:SVWF
  $fd F %SA1 T 12 FSYS C !
:SVFAIL
  @"could not save: " SAY C @MSGB D STRLEN C A %SR1 F %SA1 T %SA2 T 60 %SA3 T 19 FSYS C ! 0 R
:NUMSTR                    # (dst n --)  decimal text
  SWAP $nsd T
  D 10 L NS1 *
  D 10 V $nsd F SWAP NUMSTR C $nsd F STRLEN C $nsd F A $nsd T 10 MOD
:NS1
  '0' A $nsd F T 0 $nsd F + T R

# ---------------------------------------------------------------------
#  keys
# ---------------------------------------------------------------------
:DOKEY
  0 @MSGB T
  $k F 1001 E KUP *
  $k F 1002 E KDOWN *
  $k F 1003 E KRIGHT *
  $k F 1004 E KLEFT *
  $k F 1005 E KHOME *
  $k F 1006 E KEND *
  $k F 1007 E KPGUP *
  $k F 1008 E KPGDN *
  $k F 1009 E KDEL *
  $k F 2000 E KMOUSE *
  $k F 2002 E KWUP *
  $k F 2003 E KWDN *
  $k F 8 E KBS *
  $k F 10 E KENTER *
  $k F 9 E KTAB *
  $k F 19 E KSAVE *
  $k F 15 E KSAVE *
  $k F 17 E KQUIT *
  $k F 24 E KQUIT *
  $k F 6 E KFIND *
  $k F 7 E KGOTO *
  $k F 11 E KCUT *
  $k F 21 E KPASTE *
  $k F 26 E KUNDO *
  $k F 25 E KREDO *
  $k F 27 E KRET *
  $k F 32 L KRET *
  $k F 1000 / KRET *
  EDITSTART C
  $k F 128 L KASCII *
  $k F 2048 L KU2 *
  $k F 6 > 224 O INSERT C $k F 6 > 63 P 128 O INSERT C KU1 B
:KU2
  $k F 6 > 192 O INSERT C
:KU1
  $k F 63 P 128 O INSERT C SETGCOL B
:KASCII
  $k F INSERT C SETGCOL B
:KRET
  R
:SETGCOL                   # remember the column for up / down
  $c F D LSTART C S $gcol T R
:KLEFT
  $c F KRET J
  $c F - $c T SETGCOL B
:KRIGHT
  $c F $n F / KRET *
  $c PSTO SETGCOL B
:KHOME
  $c F LSTART C $c T SETGCOL B
:KEND
  $c F LEND C $c T SETGCOL B
:KUP
  $c F LSTART C D KUPNO J
  - D LSTART C $gcol F A MIN $c T R
:KUPNO
  ! R
:KDOWN
  $c F LEND C D $n F / KDNO *
  + D LEND C SWAP $gcol F A MIN $c T R
:KDNO
  ! R
:KPGUP
  $trows F $pg T
:KPGUL
  $pg F KRET J
  KUP C $pg F - $pg T KPGUL B
:KPGDN
  $trows F $pg T
:KPGDL
  $pg F KRET J
  KDOWN C $pg F - $pg T KPGDL B
:KWUP
  KUP C KUP C KUP B
:KWDN
  KDOWN C KDOWN C KDOWN B
:KBS
  $c F KRET J
  EDITSTART C $c F - $c T DELETE C SETGCOL B
:KDEL
  EDITSTART C DELETE C R
:KENTER
  EDITSTART C 10 INSERT C 0 $gcol T R
:KTAB
  EDITSTART C 32 INSERT C 32 INSERT C SETGCOL B
:KMOUSE                    # a click puts the cursor there
  %TR4 F 32 P KRET *
  %TR3 F 1 L KRET * %TR3 F $trows F G KRET *
  $top F %TR3 F - $mr T
:KMLP
  $mr F KMROW J
  LEND C D $n F / KMEND *
  + $mr F - $mr T KMLP B
:KMROW
  D LEND C SWAP %TR2 F 7 S 0 MAX $left F A A MIN $c T SETGCOL B
:KMEND
  $c T SETGCOL B
:KSAVE
  SAVE C ! R
:KQUIT
  $mod F QBYE J
  @"save changes?  y = save and quit   n = quit without saving   Esc = stay" SAY C DRAW C
  0 KEY C D 'y' E QSAVE *
  D 'Y' E QSAVE *
  D 'n' E QBYE0 *
  D 'N' E QBYE0 *
  ! 0 @MSGB T R
:QSAVE
  ! SAVE C QBYE *
  R
:QBYE
:EQUIT
  RAWOFF C H
:QBYE0
  ! QBYE B
:KUNDO
  6 %HCMD T KUNDO2 *
  @"nothing to undo" SAY B
:KUNDO2
  AFTERUNDO B
:KREDO
  13 %HCMD T KUNDO2 *
  @"nothing to redo" SAY B
:AFTERUNDO                 # the size and the line count may have changed
  %HSIZE F %TB 65536 S S 0 MAX $n T
  $c F $n F MIN $c T 1 $mod T
  1 $nl T 0 $i T
:AUCNT
  $i F $n F / AUDONE *
  $i F TX C 10 = AUN *
  $nl PSTO
:AUN
  $i PSTO AUCNT B
:AUDONE
  $top F $n F MIN LSTART C $top T 1 $topln T 0 $i T
:AUTOP
  $i F $top F / KRET *
  $i F TX C 10 = AUT *
  $topln PSTO
:AUT
  $i PSTO AUTOP B
:KCUT                      # the cursor's line into CLIP (repeated ^K adds lines)
  $lastk F 11 E KCMORE *
  0 $clipn T
:KCMORE
  EDITSTART C
  $c F LSTART C $c T
  $c F LEND C $c F S + $cl T
  $c F $cl F A $n F G KCLAST J
  KCGO B
:KCLAST
  $cl F - $cl T
:KCGO
  $cl F KCNONL *
  KRET B
:KCNONL
  0 $i T
:KCLP
  $i F $cl F / SETGCOL *
  $clipn F 4095 L KCSAVE J
  $c F TX C $clipn F @CLIP A T $clipn PSTO
:KCSAVE
  DELETE C $i PSTO KCLP B
:KPASTE
  $clipn F KRET J
  EDITSTART C 0 $i T
:KPLP
  $i F $clipn F / SETGCOL *
  $i F @CLIP A F INSERT C $i PSTO KPLP B
:ASK                       # (prompt -- ok)  read a line into IN on the message line
  @MSGB SCOPY C 0 @IN T 0 $an T 1 $asking T
:ASKLP
  DRAW C @IN OBS C OBFLUSH C
  0 KEY C D 10 E ASKOK *
  D 27 E ASKNO *
  D 0 L ASKNO *
  D 8 E ASKBS *
  D 32 L ASKSK *
  D 126 G ASKSK *
  $an F 60 / ASKSK *
  $an F @IN A T $an PSTO 0 $an F @IN A T ASKLP B
:ASKSK
  ! ASKLP B
:ASKBS
  ! $an F ASKLP J
  $an F - $an T 0 $an F @IN A T ASKLP B
:ASKOK
  ! 0 @MSGB T 0 $asking T @IN F BOOL R
:ASKNO
  ! 0 @MSGB T 0 $asking T 0 R
:KFIND
  $lastk F 6 E @FIND F BOOL P KFNEXT *
  @"find: " ASK C KRET J
  @IN @FIND SCOPY C
:KFNEXT
  @FIND STRLEN C $fl T $c F + $fp T 0 $fwrap T
:KFLP
  $fp F $fl F A $n F G KFWRAP *
  0 $fj T
:KFCMP
  $fj F $fl F / KFHIT *
  $fp F $fj F A TX C $fj F @FIND A F = KFNX *
  $fj PSTO KFCMP B
:KFNX
  $fp PSTO KFLP B
:KFWRAP
  $fwrap F KFNONE *
  1 $fwrap T 0 $fp T KFLP B
:KFHIT
  $fp F $c T SETGCOL C @"found (^F again: next)" SAY B
:KFNONE
  @"not found: " SAY C @MSGB D STRLEN C A @FIND SCOPY B
:KGOTO
  @"go to line: " ASK C KRET J
  @IN ATOI C 1 MAX $gl T 0 $c T 1 $i T 0 $top T 1 $topln T
:KGLP
  $i F $gl F / SETGCOL *
  $c F LEND C D $n F / KGEND *
  + $c T $i PSTO KGLP B
:KGEND
  ! SETGCOL B

# ---------------------------------------------------------------------
#  screen
# ---------------------------------------------------------------------
:ADJUST                    # keep the cursor on screen
  $c F $top F L ADUP *
  0 $ar T $top F $ap T $c F LSTART C $cls T
:ADCNT                     # rows from top down to the cursor's line
  $ap F $cls F E ADFOUND *
  $ar F $trows F 2 M / ADJUMP *
  $ap F LEND C + $ap T $ar PSTO ADCNT B
:ADFOUND
  $ar F $trows F L ADHC *
  $ar F $trows F S + $sc T
:ADSC                      # just below the screen: scroll that many lines
  $sc F ADHC J
  $top F LEND C + $top T $topln PSTO $sc F - $sc T $ar F - $ar T ADSC B
:ADJUMP                    # far away: the cursor's line goes to the top
  $top F $ap T
:ADJL
  $ap F $cls F / ADJD *
  $ap F TX C 10 = ADJN *
  $topln PSTO
:ADJN
  $ap PSTO ADJL B
:ADJD
  $cls F $top T 0 $ar T ADHC B
:ADUP
  $top F - LSTART C $top T $topln F - $topln T ADJUST B
:ADHC
  $c F D LSTART C S $ccol T
  $ccol F $left F L ADLEFT *
  $ccol F $left F $tcols F A L ADROWS *
  $ccol F $tcols F S + $left T ADROWS B
:ADLEFT
  $ccol F $left T
:ADROWS
  $ar F $crow T R

:DRAW
  ESCB C @"?25l" OBS C
  $top F $dp T 0 $dr T
:DRROW
  $dr F $trows F / DRSTATUS *
  $dr F + 1 GOTO C
  $topln F $dr F A $nl F G DRTILDE *
  $c F LSTART C $dp F E DRCURLN J
  52 FGC C DRNUM B
:DRCURLN
  DIM C
:DRNUM
  $topln F $dr F A 5 OBNP C 32 OBC C RST C
  0 $dcol T 0 $dcolr T 0 $dcomm T 99 $dcur T
  $mode F 2 E $dp F TX C '>' E P $dhead T
:DRCH
  $dp F $n F / DRENDL *
  $dp F TX C D 10 E DRNL *
  $dcol F $left F L DRSKIP *
  $dcol F $left F $tcols F A / DRSKIP *
  DRCHAR C DRNEXT B
:DRSKIP
  !
:DRNEXT
  $dp F TX C 192 P 128 E DRCONT *
  $dcol PSTO
:DRCONT
  $dp PSTO DRCH B
:DRNL
  !
:DRENDL
  RST C CLREOL C
  $dp F LEND C + $dp T $dr PSTO DRROW B
:DRTILDE
  DIM C @"    ~" OBS C RST C CLREOL C $dr PSTO DRROW B
:DRCHAR                    # (byte --)  with the file's colours
  $mode F 1 E DRCAA *
  $mode F 2 E DRCFA *
  DRPUT B
:DRCAA                     # GATC source: # comments, :labels, "strings"
  D '#' E $dcomm F O $dcomm T
  $dcomm F DRCCOM *
  $dcol F N OVER ':' E P DRLAB *
  $dcolr F 3 = DRPUT *
  D 32 E DRCLR *
  DRPUTRAW B
:DRCCOM
  $dcur F 2 E DRPUTRAW *
  2 $dcur T DIM C DRPUTRAW B
:DRLAB
  3 $dcolr T 0 $dcur T 39 FGC C DRPUTRAW B
:DRCLR
  0 $dcolr T RST C 99 $dcur T DRPUTRAW B
:DRCFA                     # FASTA: header in one colour, bases in their codon colours
  $dhead F DRFHEAD *
  D 32 O 'a' E DRFA *
  D 32 O 'c' E DRFC *
  D 32 O 'g' E DRFG *
  D 32 O 't' E DRFT *
  RST C 99 $dcur T DRPUTRAW B
:DRFHEAD
  $dcur F 5 E DRPUTRAW *
  5 $dcur T 31 FGC C BOLDON C DRPUTRAW B
:DRFA
  1 12 DRFCOL B
:DRFC
  2 23 DRFCOL B
:DRFG
  3 60 DRFCOL B
:DRFT
  4 52 DRFCOL B
:DRFCOL                    # (byte id codon -- byte)
  SWAP D $dcur F E DRFSAME *
  $dcur T FGC C DRPUTRAW B
:DRFSAME
  ] DRPUTRAW B
:DRPUT
  D 32 L DRCTL *
:DRPUTRAW
  D 9 E DRTAB *
  OBC B
:DRTAB
  ! 32 OBC B
:DRCTL
  D 9 E DRPUTRAW *
  ! DIM C '.' OBC C RST C 99 $dcur T R
:DRSTATUS
  $rows F - 1 GOTO C 18 BGC C 63 FGC C BOLDON C @" edit " OBS C RST C 18 BGC C 63 FGC C 32 OBC C
  @FNAME OBS C
  $newf F DRSNEW J
  @" (new)" OBS C
:DRSNEW
  $mod F DRSMOD J
  @"  [modified]" OBS C
:DRSMOD
  @"   line " OBS C $topln F $crow F A OBN C 47 OBC C $nl F OBN C
  @"  col " OBS C $ccol F + OBN C @"   " OBS C $n F OBN C @" bytes " OBS C
  $mode F 1 E DRSAA *
  $mode F 2 E DRSFA *
  DRSE B
:DRSAA
  @" GATC " OBS C DRSE B
:DRSFA
  @" FASTA " OBS C
:DRSE
  CLREOL C RST C
  $rows F 1 GOTO C @MSGB F DRHELP J
  60 FGC C @MSGB OBS C RST C CLREOL C DRCUR B
:DRHELP
  DIM C @"^S save  ^Q quit  ^F find  ^G line  ^K cut  ^U paste  ^Z undo  ^Y redo" OBS C RST C CLREOL C
:DRCUR
  $asking F DRCURT *
  $crow F + $ccol F $left F S 7 A GOTO C
:DRCURT
  ESCB C @"?25h" OBS C OBFLUSH B
