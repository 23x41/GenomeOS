# GenomeOS system calls: arguments in 4129-4132, number in 4128, status 4133, results 4134-4137
.const SA1 4129
.const SA2 4130
.const SA3 4131
.const SA4 4132
.const SNUM 4128
.const SST 4133
.const SR1 4134
.const SR2 4135
.const SR3 4136
.const SR4 4137
.buf NOTNULL 1
.buf ARG 80
  SYSLIBEND B
:GETARGS                   # ( -- )  the program's arguments into @ARG
  @ARG %SA1 T 79 %SA2 T 106 %SNUM T R
:ATOI                      # (addr -- n)  first number in a string (0 if none)
  0 $atv T
:ATSKIP
  D F D ATEND J
  D '0' L ATNOT * '9' G ATNOT2 *
  ATDIG B
:ATNOT
  !
:ATNOT2
  + ATSKIP B
:ATDIG
  D F D '0' L ATSTOP * D '9' G ATSTOP *
  '0' S $atv F 10 M A $atv T + ATDIG B
:ATSTOP
  ] $atv F R
:ATEND
  ] $atv F R
:SYSLIBEND
# ---- files (the fs bridge): FSYS (cmd -- status), results in SR1..SR4
.buf ERRB 120
.buf IOB 512
  SYSFSEND B
:FSYS
  %SNUM T %SST F R
:NEXTARG                   # ( -- addr | 0)  the next word of @ARG (call GETARGS first)
  $nap F NAINIT *
  @ARG $nap T
:NAINIT
:NASKIP
  $nap F F 32 = NASTART *
  $nap PSTO NASKIP B
:NASTART
  $nap F F NANONE J
  $nap F $nas T
:NAWORD
  $nap F F D NAEND J 32 E NACUT *
  $nap PSTO NAWORD B
:NACUT
  0 $nap F T $nap PSTO $nas F R
:NAEND
  ! $nas F R
:NANONE
  0 R
:PRINTS                    # (str --)
  D F D PRSE J
  W + PRINTS B
:PRSE
  ] R
:OOPS                      # (name --)  "name: why" from the last failed call
  PRINTS C ": " %SR1 F %SA1 T @ERRB %SA2 T 120 %SA3 T 19 FSYS C ! @ERRB PRINTS C CR R
:ISDIR                     # (path -- flag)
  %SA1 T 1 %SA2 T 1 FSYS C D ISDNO J
  ! %SR2 F 2 E R
:ISDNO
  R
:BASENAME                  # (path -- addr)  after the last /
  D $bnr T
:BNLP
  D F BNEND J
  D F '/' E BNSL *
  + BNLP B
:BNSL
  + D $bnr T BNLP B
:BNEND
  ! $bnr F R
:SYSFSEND
