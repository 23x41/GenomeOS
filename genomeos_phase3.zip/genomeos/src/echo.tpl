# echo TEXT: prints its arguments
.include sys.inc
  .init
  GETARGS C @ARG PRINTS C CR H
