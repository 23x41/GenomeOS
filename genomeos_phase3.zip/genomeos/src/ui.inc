# ---- full-screen helpers (tty bridge): output buffer, cursor, codon colours, keys
#  colours come from the 64-codon palette: codon n = 16*first + 4*second + third base
#  (A 0 C 1 G 2 T 3), each base a level of red, green, blue - the same colours as paint.
.const TCMD 4144
.const TA1 4145
.const TA2 4146
.const TST 4148
.const TR1 4149
.const TR2 4150
.const TR3 4151
.const TR4 4152
.buf OB 4100
  UIEND B
:OBC                       # (byte --)
  $obn F @OB A T $obn PSTO
  $obn F 4000 / OBFLUSH *
  R
:OBFLUSH
  $obn F OBFR J
  @OB %TA1 T $obn F %TA2 T 3 %TCMD T 0 $obn T
:OBFR
  R
:OBS                       # (str --)
  D F D OBSE J
  OBC C + OBS B
:OBSE
  ] R
:OBN                       # (n --)
  D 0 L OBNNEG *
  D 10 L OBN1 *
  D 10 V OBN C 10 MOD
:OBN1
  '0' A OBC B
:OBNNEG
  '-' OBC C ~ OBN B
:NDIG                      # (n -- digits)
  1 SWAP
:NDLP
  10 V D NDE J
  SWAP + SWAP NDLP B
:NDE
  ! R
:OBNP                      # (n width --)  right-aligned
  OVER 0 MAX NDIG C S
:OBNPL
  D 1 L OBNPE *
  32 OBC C - OBNPL B
:OBNPE
  ! OBN B
:OBSP                      # (n --)  spaces
  D 1 L OBSPE *
  32 OBC C - OBSP B
:OBSPE
  ! R
:ESCB
  27 OBC C '[' OBC B
:GOTO                      # (row col --)  1-based
  SWAP ESCB C OBN C ';' OBC C OBN C 'H' OBC B
:CLREOL
  ESCB C 'K' OBC B
:RST
  ESCB C '0' OBC C 'm' OBC B
:BOLDON
  ESCB C '1' OBC C 'm' OBC B
:LV                        # (0-3 -- 0 1 3 5)  xterm cube level nearest to 0 85 170 255
  D 2 L LVRET *
  2 M - R
:LVRET
  R
:XT                        # (codon -- xterm colour)
  D 4 > 3 P LV C 36 M OVER 2 > 3 P LV C 6 M A SWAP 3 P LV C A 16 A R
:FGC                       # (codon --)  text colour
  ESCB C @"38;5;" OBS C XT C OBN C 'm' OBC B
:BGC                       # (codon --)  background colour
  ESCB C @"48;5;" OBS C XT C OBN C 'm' OBC B
:DIM
  ESCB C @"38;5;244m" OBS B
:RAWON
  1 %TA1 T 1 %TCMD T
  ESCB C @"?1049h" OBS C ESCB C @"?25l" OBS C OBFLUSH B
:RAWOFF
  RST C ESCB C @"?1002l" OBS C ESCB C @"?1006l" OBS C ESCB C @"?25h" OBS C ESCB C @"?1049l" OBS C OBFLUSH C
  0 %TA1 T 1 %TCMD T R
:TSIZE                     # sets $cols $rows
  4 %TCMD T %TR1 F 20 MAX $cols T %TR2 F 8 MAX $rows T R
:KEY                       # (timeout ms, 0 = wait -- key | 0 timeout | -1 end)
  OBFLUSH C %TA1 T 2 %TCMD T
  %TST F KEYNO J
  %TR1 F R
:KEYNO
  %TR1 F 1 E KEYEND *
  0 R
:KEYEND
  0 1 S R
:TICKS
  6 %TCMD T %TR1 F R
:UIEND
