# rm NAME ...: remove files
.include sys.inc
  .init
  GETARGS C 0 $nap T 0 $bad T
  NEXTARG C D USAGE J
:DOONE
  D %SA1 T 7 FSYS C OK *
  "rm: " OOPS C 1 $bad T NEXT B
:OK
  !
:NEXT
  NEXTARG C D DOONE *
  ! $bad F Q
:USAGE
  ! "usage: rm NAME ..." CR 1 Q
