# init: process 1.  Starts the shell and starts it again when it exits;
# when the shell ends because input ended (exit code 99), powers off.
.include sys.inc
  .init
:AGAIN
  @"/bin/gsh" %SA1 T 0 %SA2 T 0 %SA3 T 0 %SA4 T 100 %SNUM T
  %SST F NOSHELL J
  %SR1 F %SA1 T 101 %SNUM T
  %SR1 F 99 E BYE *
  "[init] the shell stopped - starting a new one" CR
  AGAIN B
:BYE
  0 %SA1 T 109 %SNUM T H
:NOSHELL
  "[init] cannot start /bin/gsh" CR 1 Q
