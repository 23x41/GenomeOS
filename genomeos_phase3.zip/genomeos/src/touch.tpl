# touch FILE ...: make empty files, or update their time
.include sys.inc
  .init
  GETARGS C 0 $nap T 0 $bad T
  NEXTARG C D USAGE J
:DOONE
  D %SA1 T 3 %SA2 T 9 FSYS C BAD J
  %SR1 F %SA1 T 12 FSYS C !
  D %SA1 T 16 FSYS C ! ! NEXT B
:BAD
  "touch: " OOPS C 1 $bad T
:NEXT
  NEXTARG C D DOONE *
  ! $bad F Q
:USAGE
  ! "usage: touch FILE ..." CR 1 Q
