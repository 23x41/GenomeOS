#!/usr/bin/env python3
"""gen_aa.py - expands a .tpl template (shell.tpl, paint.tpl) into a plain GATC .aa file.

Template extras (all resolved to plain numbers; the output needs no special loader support):
  .const NAME value      %NAME          -> value
  .buf   NAME size       @NAME          -> start address of a memory buffer
  .str   NAME "text"     @NAME          -> address of a NUL-terminated UTF-8 string in memory
  $name                  -> address of a one-cell variable (allocated on first use)
  'c'                    -> character code (escapes \\n \\t \\\\ \\')
  @"text"                -> address of an anonymous NUL-terminated string in memory
  .macro NAME / .endm    -> {NAME} pastes the lines in between (inline, no call)
  .include FILE          -> the lines of another template file
  .init                  -> emits the code that writes every .str into memory
Inside "strings" and after # nothing is touched.  The symbol forms of ROT NIP RAND MOD
must be written as words in the template (@ & $ % are sigils here).
"""
import re, sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import GATCnux as G

MEM = G.MEM_SIZE
ESC = {"n": "\n", "t": "\t", "r": "\r", "\\": "\\", '"': '"', "'": "'", "0": "\0"}

def parse_str(lit):
    assert lit[0] == '"' and lit[-1] == '"', lit
    out, i, body = [], 0, lit[1:-1]
    while i < len(body):
        if body[i] == "\\": out.append(ESC.get(body[i + 1], body[i + 1])); i += 2
        else: out.append(body[i]); i += 1
    return "".join(out)

def segments(line):
    """split a source line into (kind, text) with kind in code/str/comment"""
    segs, i, n, buf = [], 0, len(line), ""
    while i < n:
        c = line[i]
        if c == "'" and i + 2 < n and (line[i + 2] == "'" or (line[i + 1] == "\\" and i + 3 < n and line[i + 3] == "'")):
            ln = 4 if line[i + 1] == "\\" else 3
            buf += "\x01" + line[i:i + ln] + "\x01"; i += ln; continue
        if c == '"':
            if buf: segs.append(("code", buf)); buf = ""
            j = i + 1
            while j < n and line[j] != '"':
                j += 2 if line[j] == "\\" else 1
            segs.append(("str", line[i:j + 1])); i = j + 1; continue
        if c == "#":
            if buf: segs.append(("code", buf)); buf = ""
            segs.append(("comment", line[i:])); break
        buf += c; i += 1
    if buf: segs.append(("code", buf))
    return segs

def main(src, dst):
    lines = []
    for ln in open(src, encoding="utf-8").read().splitlines():
        if ln.strip().startswith(".include "):
            inc = os.path.join(os.path.dirname(os.path.abspath(src)), ln.split(None, 1)[1].strip())
            lines += open(inc, encoding="utf-8").read().splitlines()
        else:
            lines.append(ln)
    consts, bufs, strs, order = {}, {}, {}, []
    body = []
    macros, cur = {}, None
    for ln in lines:
        st = ln.strip()
        if cur is not None:
            if st == ".endm": cur = None
            else: macros[cur].append(st)
            continue
        if st.startswith(".macro "):
            cur = st.split()[1]; macros[cur] = []; continue
        if "{" in ln and not st.startswith("#"):
            def mx(m):
                if m.group(1) not in macros: sys.exit("unknown macro {%s}" % m.group(1))
                return " ".join(macros[m.group(1)])
            code, sep, com = ln.partition("#") if '"' not in ln else (ln, "", "")
            ln = re.sub(r"\{(\w+)\}", mx, code) + sep + com
        s = ln.strip()
        if s.startswith(".const "):
            _, k, v = s.split(None, 2); consts[k] = int(v, 0); continue
        if s.startswith(".buf "):
            _, k, v = s.split(None, 2); bufs[k] = int(v); order.append(k); continue
        if s.startswith(".str "):
            m = re.match(r'\.str\s+(\w+)\s+("(?:[^"\\]|\\.)*")\s*$', s)
            if not m: sys.exit("bad .str: " + s)
            strs[m.group(1)] = parse_str(m.group(2)).encode("utf-8"); continue
        body.append(ln)
    # pass 1: anonymous strings @"text" and variables
    anon = {}
    for ln in body:
        sg = segments(ln)
        for i, (kind, t) in enumerate(sg):
            if kind == "str" and i > 0 and sg[i - 1][0] == "code" and sg[i - 1][1].endswith("@"):
                if t not in anon:
                    k = "_s%d" % len(anon); anon[t] = k; strs[k] = parse_str(t).encode("utf-8")
    varnames = []
    for ln in body:
        for kind, t in segments(ln):
            if kind == "code":
                for v in re.findall(r"\$(\w+)", t):
                    if v not in varnames: varnames.append(v)
    # two RAM regions around the device window: [0, 4096) and [4160, 65536).
    # First fit in declaration order, so programs that fit in 4096 cells get the same addresses as before.
    lo, hi = 0, G.HOLE_HI
    def alloc(n, what):
        nonlocal lo, hi
        if lo + n <= G.HOLE_LO: a = lo; lo += n; return a
        if hi + n <= MEM: a = hi; hi += n; return a
        sys.exit(f"memory overflow: {what} ({n} cells) does not fit; low {lo}/{G.HOLE_LO}, high {hi - G.HOLE_HI}/{MEM - G.HOLE_HI}")
    amap = {}
    for k in order: amap[k] = alloc(bufs[k], "buffer @" + k)
    vmap = {}
    for v in varnames: vmap[v] = alloc(1, "variable $" + v)
    smap = {}
    for k, b in strs.items(): smap[k] = alloc(len(b) + 1, "string " + k)
    # labels: must not collide with opcode names/aliases
    labels = set()
    for ln in body:
        for kind, t in segments(ln):
            if kind == "code":
                for lab in re.findall(r":(\w+)", t):
                    u = lab.upper()
                    if u in G.ALIASES or (len(u) == 1): sys.exit(f"label :{lab} collides with an opcode")
                    if u in labels: sys.exit(f"duplicate label :{lab}")
                    labels.add(u)
    out = []
    def sub_code(t, lineno):
        def ch(m):
            lit = m.group(1)[1:-1]
            c = ESC.get(lit[1], lit[1]) if lit.startswith("\\") else lit
            return str(ord(c))
        t = re.sub(r"\x01('(?:\\.|[^'])')\x01", ch, t)
        def look(table, kind):
            def f(m):
                k = m.group(1)
                if k not in table: sys.exit(f"line {lineno}: unknown {kind} {m.group(0)}")
                return str(table[k])
            return f
        t = re.sub(r"\$(\w+)", look(vmap, "variable"), t)
        both = dict(amap); both.update(smap)
        t = re.sub(r"@(\w+)", look(both, "buffer/string"), t)
        t = re.sub(r"%(\w+)", look(consts, "constant"), t)
        if re.search(r"[@$%&']", t): sys.exit(f"line {lineno}: stray sigil in: {t.strip()}")
        if re.search(r"(?<![\w])-\d", t): sys.exit(f"line {lineno}: negative literal (not DNA-safe): {t.strip()}")
        return t
    for no, ln in enumerate(body, 1):
        if ln.strip() == ".init":
            out.append("  # ---- write the string table into memory (generated) ----")
            for k, b in strs.items():
                a = smap[k]; cells = list(b) + [0]; parts = []
                for i, c in enumerate(cells): parts.append(f"{c} {a + i} T")
                for i in range(0, len(parts), 8):
                    out.append("  " + "  ".join(parts[i:i + 8]) + ("   # " + k if i == 0 else ""))
            continue
        res = []
        sg = segments(ln)
        for i, (kind, t) in enumerate(sg):
            if kind == "code":
                if i + 1 < len(sg) and sg[i + 1][0] == "str" and t.endswith("@"):
                    t = t[:-1]
                res.append(sub_code(t, no))
            elif kind == "str" and i > 0 and sg[i - 1][0] == "code" and sg[i - 1][1].endswith("@"):
                res.append(" %d " % smap[anon[t]])
            else:
                res.append(t)
        out.append("".join(res))
    mm = ["# Memory map (generated):"]
    for k in order: mm.append(f"#   {amap[k]:5d}..{amap[k] + bufs[k] - 1:5d}  {k}")
    if hi == G.HOLE_HI:      # everything below the device window: same map lines as before
        v0 = min(vmap.values()) if vmap else lo; s0 = min(smap.values()) if smap else lo
        mm.append(f"#   {v0:5d}..{s0 - 1:5d}  variables ({len(vmap)})")
        mm.append(f"#   {s0:5d}..{lo - 1:5d}  strings ({len(strs)})   free: {G.HOLE_LO - lo} cells")
    else:
        if vmap: mm.append(f"#   {min(vmap.values()):5d}..{max(vmap.values()):5d}  variables ({len(vmap)})")
        mm.append(f"#   strings ({len(strs)});  free: {G.HOLE_LO - lo} low + {MEM - hi} high cells   (4096..4159 = device cells)")
    text = "\n".join(out)
    text = text.replace("#@@MEMMAP", "\n".join(mm))
    open(dst, "w", encoding="utf-8").write(text + "\n")
    import json
    json.dump({"vars": vmap, "bufs": amap, "strs": smap}, open(dst + ".map", "w"))
    print(f"{dst}: {len(out)} lines, memory used {lo}/{G.HOLE_LO}" + (f" + {hi - G.HOLE_HI}/{MEM - G.HOLE_HI} high" if hi > G.HOLE_HI else "") + f" (vars {len(vmap)}, strings {len(strs)})", file=sys.stderr)

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "paint.tpl", sys.argv[2] if len(sys.argv) > 2 else "paint.aa")
