# =====================================================================
# kernel.aa  --  the GenomeOS kernel (phase 2: GenomeFS)
#
#   python3 GATCnux.py mkimage genome.img --kernel kernel.aa /bin/init=init.aa /bin/gsh=gsh.aa ...
#   python3 GATCnux.py boot genome.img
#
# Boots /bin/init (or, without one, every program in /etc/rc).  Up to 16
# processes run together in %QUANTUM-step time slices.  Programs talk to
# the kernel through the same bridge cells they always used:
#   PUTC PUTN CR GETC IN       console or pipe, per process
#   tty bridge (4144)          raw keys, raw writes, size, sleep, ticks
#   fs window (4128), 100+     GenomeOS system calls:
#     100 spawn(path, args, in + 256*out, flags 1=background) r1 pid
#     101 wait(pid) r1 exit code      102 getpid r1 pid r2 parent
#     103 pinfo(slot, namebuf) r1 pid r2 state r3 parent r4 steps
#     104 kill(pid)   105 sleep(ms)   106 getargs(buf, max) r1 length
#     107 uname r1 30303 r2 version r3 ms since boot r4 processes
#     109 poweroff(code)
#     110 pipe() r1 id   111 closepipe(id)   112 setmode(1 = Ctrl+C edits the line)
#   fs commands 1-28 (stat, open, read, write, mkdir, rename ...) work
#   on GenomeFS, the file system on the disk, with a cwd per process.
# Console: the kernel edits a line at a time for the foreground process
# (echo, Backspace, Ctrl+D = end of input, Ctrl+C stops the foreground
# job), and when other programs print it redraws the waiting prompt.
#
# Generated from kernel.tpl by gen_aa.py.
#@@MEMMAP
# =====================================================================

.const KCMD 4096
.const KA1 4097
.const KA2 4098
.const KA3 4099
.const KA4 4100
.const KST 4103
.const KR1 4104
.const KR2 4105
.const KR3 4106
.const KR4 4107
.const KMAGIC 4110
.const GOSMAGIC 30303
.const FBASE 65536
.const LOADAT 1114112
.const KBUF 10551296
.const BMAPK 11599872
.const INODEK 12648448
.const FBUFK 14745600
.const PTRK 14811136
.const PTR2K 14811648
.const DIRK 14812160
.const ZEROK 14812672
.const PPBK 15794176
.const NF 32
.const KOUTB 16842752
.const QUANTUM 2000
.const NP 16
.const NQ 8
.const QSIZE 4096
.const OBMAX 400
.const NONE 99
.const FST 4133
.const FR1 4134
.const FR2 4135
.const FR3 4136
.const FR4 4137
.const TST 4148
.const TR1 4149
.const TR2 4150
.const TR3 4151
.const TR4 4152
.const TMAGICC 4153
.const TTYMAGIC 18516

# process states
.const SFREE 0
.const SREADY 1
.const SCGETC 2
.const SCIN 3
.const SWAIT 4
.const SZOMB 5
.const SSLEEP 6
.const SKEY 7
.const SPGETC 8
.const SPIN 9
.const SPPUT 10
.const SDYING 11

.buf SB 512
.buf PPID 16
.buf PST 16
.buf PPAR 16
.buf PIN 16
.buf POUT 16
.buf PFL 16
.buf PWT 16
.buf PRED 16
.buf PERR 16
.buf PLN 16
.buf PPN 16
.buf PPI 16
.buf PLB 1280
.buf PARG 1280
.buf PCWD 2048
.buf PNM 1024
.buf FU 32
.buf FI 32
.buf FP 32
.buf FM 32
.buf FO 32
.buf FBL 32
.buf FBD 32
.buf FSZ 32
.buf PATHIN 256
.buf TMP 512
.buf CP 256
.buf CP2 256
.buf PARENTB 256
.buf LASTB 64
.buf COMP 64
.buf KNAME 256
.buf DNAME 64
.buf QUSE 8
.buf QHEAD 8
.buf QCNT 8
.buf QW 8
.buf QR 8
.buf QHADW 8
.buf QHADR 8
.buf QBUF 32768
.buf KQ 128
.buf OB 512
.buf LB 256
.buf TA 256
.buf NAMEB 64
.buf NUMB 24
.buf NUMC 24

  .init
  MAIN B

# ---------------------------------------------------------------------
#  machine calls
# ---------------------------------------------------------------------
:PPUT3                     # (pid addr value --)  a cell in a process
  %KA3 T %KA2 T %KA1 T 6 %KCMD T R
:PGET2                     # (pid addr -- value)
  %KA2 T %KA1 T 5 %KCMD T %KR1 F R
:PPUSH                     # (pid value --)  onto its stack
  %KA2 T %KA1 T 2 %KCMD T R
:TICKS                     # ( -- ms)
  16 %KCMD T %KR1 F R
:SLOTOF                    # (pid -- slot | NONE)
  $sof T 0 $soi T
:SOFLP
  $soi F %NP / SOFNO *
  $soi F @PST A F SOFNX J
  $soi F @PPID A F $sof F E SOFHIT *
:SOFNX
  $soi PSTO SOFLP B
:SOFHIT
  $soi F R
:SOFNO
  %NONE R
:SYSRES                    # (st r1 slot --)  result of a system call (fs window cells)
  @PPID A F $srp T $srr T $srs T
  $srp F %FR1 $srr F PPUT3 C
  $srp F %FST $srs F PPUT3 C R
:SYSRES2                   # (r2 slot --)
  @PPID A F %FR2 ROT PPUT3 B
:TTYRES                    # (st r1 slot --)  result of a tty call
  @PPID A F $srp T $srr T $srs T
  $srp F %TR1 $srr F PPUT3 C
  $srp F %TST $srs F PPUT3 C R

# ---------------------------------------------------------------------
#  console output: buffered; the line the foreground program is typing
#  on is redrawn after other programs print
# ---------------------------------------------------------------------
:OBC                       # (byte --)
  $obn F @OB A T $obn PSTO
  $obn F %OBMAX / OBFLUSH *
  R
:OBFLUSH
  $obn F OBFRET J
  @OB %KA1 T $obn F %KA2 T 12 %KCMD T
  0 $obn T
:OBFRET
  R
:OBS                       # (str --)
  D F OBSE J
  D F OBC C + OBS B
:OBSE
  ! R
:OBN                       # (n --)  signed decimal
  D 0 L OBNNEG *
  OBNU B
:OBNNEG
  '-' OBC C ~
:OBNU
  0 $nbn T
:OBNLP
  D 10 MOD '0' A $nbn F @NUMB A T $nbn PSTO 10 V
  D OBNLP *
  !
:OBNOUT
  $nbn F OBNE J
  $nbn F - D $nbn T @NUMB A F OBC C OBNOUT B
:OBNE
  R
:CLEARLINE                 # carriage return + erase the line
  13 OBC C 27 OBC C '[' OBC C 'K' OBC C R

:FRESH                     # (writer slot --)  make room for a writer that is not on screen
  $frw T
  $conown F %NONE E FRRET *
  $conown F $frw F E FRRET *
  $conown F $fg F E FRFG *
  10 OBC C %NONE $conown T R
:FRFG                      # the foreground's prompt: erase it, it is redrawn afterwards
  CLEARLINE C %NONE $conown T
:FRRET
  R
:REDRAW                    # the foreground's partial line + what has been typed
  $fg F %NONE E RDRET *
  $conown F %NONE = RDRET *
  $fg F @PFL A F 2 P RDRET *
  $fg F @PLN A F $lbn F O RDRET J
  0 $rdi T
:RDLP1
  $rdi F $fg F @PLN A F / RDLB *
  $fg F 80 M @PLB A $rdi F A F OBC C $rdi PSTO RDLP1 B
:RDLB
  0 $rdi T
:RDLP2
  $rdi F $lbn F / RDDONE *
  $rdi F @LB A F OBC C $rdi PSTO RDLP2 B
:RDDONE
  $fg F $conown T
:RDRET
  R
:CONOUT                    # (byte slot --)  a program's byte on the console
  $cos T $coc T
  $cos F @PFL A F 2 P COPLAIN *
  $cos F FRESH C
  $coc F OBC C
  $coc F 10 E CONL *
  $cos F @PLN A F 79 / COFULL *
  $coc F $cos F 80 M @PLB A $cos F @PLN A F A T
  $cos F @PLN A PSTO
:COFULL
  $cos F $conown T R
:CONL
  0 $cos F @PLN A T %NONE $conown T
  $cos F $fg F E CONLRET *
  REDRAW C
:CONLRET
  R
:COPLAIN                   # full-screen (raw) programs: no line tracking
  $coc F OBC C R
:KMSG                      # start a kernel message on its own line
  %NONE 1 A FRESH C R
:KMSGEND                   # end it, then redraw the prompt
  10 OBC C %NONE $conown T REDRAW C OBFLUSH B
:PNAMEOUT                  # (slot --)  "[pid name]"
  91 OBC C D @PPID A F OBN C 32 OBC C 64 M @PNM A OBS C 93 OBC C R

# =====================================================================
#  GenomeFS  (the disk format is described in GATCnux.py, "GenomeFS")
#  The block map and the inode table live in kernel memory (file space)
#  and are written back block by block as they change.
# =====================================================================
:SET32                     # (n addr --)  little-endian
  $s3a T D 255 P $s3a F T
  D 8 > 255 P $s3a F + T D 16 > 255 P $s3a F 2 A T 24 > 255 P $s3a F 3 A T R
:DREAD1                    # (block kaddr --)
  %KA3 T %KA1 T 1 %KA2 T 9 %KCMD T R
:DWRITE1                   # (block kaddr --)
  %KA3 T %KA1 T 1 %KA2 T 10 %KCMD T R
:KZERO                     # (kaddr n --)
  %KA2 T %KA1 T 0 %KA3 T 21 %KCMD T R
:NOW                       # ( -- seconds since 1970)
  23 %KCMD T %KR1 F R

# ---- inodes
:IADDR                     # (ino -- kaddr)
  128 M %INODEK A R
:IGET                      # (ino off -- value)
  SWAP IADDR C A LE32 B
:ISET                      # (value ino off --)
  SWAP IADDR C A SET32 B
:IWRITE                    # (ino --)  write its block back
  128 M 512 V D $istart F A SWAP 512 M %INODEK A DWRITE1 B
:IALLOC                    # (type -- ino | 0)
  $iat T 2 $ian T
:IALP
  $ian F $icount F / IANONE *
  $ian F 0 IGET C IAGOT J
  $ian PSTO IALP B
:IAGOT
  $ian F IADDR C 128 KZERO C
  $iat F $ian F 0 ISET C 1 $ian F 16 ISET C NOW C $ian F 8 ISET C
  $iat F 2 E IADIR *
  420 IAMODE B
:IADIR
  493
:IAMODE
  $ian F 12 ISET C $ian F IWRITE C $ian F R
:IANONE
  28 $err T 0 R
:IFREE                     # (ino --)
  D IADDR C 128 KZERO C IWRITE B

# ---- blocks
:MAPSET                    # (block value --)
  OVER %BMAPK A T
  512 V D $mstart F A SWAP 512 M %BMAPK A DWRITE1 B
:BALLOC                    # ( -- block | 0)  a zeroed block
  $nfree F BANONE J
  $brover F $dstart F MAX $total F MIN $bb T 0 $bwrap T
:BALP
  $bb F $total F L BAIN *
  $bwrap F BANONE *
  1 $bwrap T $dstart F $bb T
:BAIN
  $bb F %BMAPK A F BAGOT J
  $bb PSTO BALP B
:BAGOT
  $bb F 1 MAPSET C $nfree F - $nfree T $bb F + $brover T
  $bb F %ZEROK DWRITE1 C
  $bb F $ptag F E BAKEEP J
  0 $ptag T
:BAKEEP
  $bb F R
:BANONE
  28 $err T 0 R
:BFREE                     # (block --)
  D $dstart F L BFNO *
  D $total F / BFNO *
  D %BMAPK A F BFNO J
  D 0 MAPSET C $nfree PSTO
  $ptag F = BFRET *
  0 $ptag T R
:BFNO
  !
:BFRET
  R
:PTRGET                    # (pblock index alloc -- value)  an entry of a pointer block
  $pga T $pgi T $pgb T
  $pgb F $ptag F E PGHAVE *
  $pgb F %PTRK DREAD1 C $pgb F $ptag T
:PGHAVE
  $pgi F 4 M %PTRK A LE32 C D PGRET *
  $pga F PGRET J
  ! BALLOC C D PGRET J
  D $pgi F 4 M %PTRK A SET32 C
  $pgb F %PTRK DWRITE1 C
:PGRET
  R
:BMAP                      # (ino lb alloc -- block | 0)
  $bma T $bml T $bmi T
  $bml F 24 / BMIND *
  $bmi F $bml F 4 M 20 A IGET C D BMRET *
  $bma F BMRET J
  ! BALLOC C D BMRET J
  D $bmi F $bml F 4 M 20 A ISET C $bmi F IWRITE C
:BMRET
  R
:BMTOP                     # (off -- block | 0)  the inode's indirect / double block
  $bmo T
  $bmi F $bmo F IGET C D BMTRET *
  $bma F BMTRET J
  ! BALLOC C D BMTRET J
  D $bmi F $bmo F ISET C $bmi F IWRITE C
:BMTRET
  R
:BMIND
  $bml F 152 / BMDBL *
  116 BMTOP C D BMRET J
  $bml F 24 S $bma F PTRGET B
:BMDBL
  $bml F 152 S D $bml T 16384 / BMNONE *
  120 BMTOP C D BMRET J
  $bml F 128 V $bma F PTRGET C D BMRET J
  $bml F 127 P $bma F PTRGET B
:BMNONE
  27 $err T 0 R

:FREEPTRS                  # (pblock --)  free every block it points to (uses PTRK)
  D %PTRK DREAD1 C $ptag T 0 $fpi T
:FPLP
  $fpi F 128 / FPRET *
  $fpi F 4 M %PTRK A LE32 C D FPNO J
  BFREE C $fpi PSTO FPLP B
:FPNO
  ! $fpi PSTO FPLP B
:FPRET
  0 $ptag T R
:TRUNC                     # (ino --)  free every data block, size 0
  $tri T 0 $trk T
:TRLP
  $trk F 24 / TRIND *
  $tri F $trk F 4 M 20 A IGET C BFREE C
  0 $tri F $trk F 4 M 20 A ISET C $trk PSTO TRLP B
:TRIND
  $tri F 116 IGET C D TRNOIND J
  D FREEPTRS C BFREE C TRDBL B
:TRNOIND
  !
:TRDBL
  $tri F 120 IGET C D TRNODBL J
  D %PTR2K DREAD1 C 0 $trj T
:TRDLP
  $trj F 128 / TRDEND *
  $trj F 4 M %PTR2K A LE32 C D TRDNO J
  D FREEPTRS C BFREE C $trj PSTO TRDLP B
:TRDNO
  ! $trj PSTO TRDLP B
:TRDEND
  BFREE C TRSET B
:TRNODBL
  !
:TRSET
  0 $dltag T
  0 $tri F 116 ISET C 0 $tri F 120 ISET C 0 $tri F 4 ISET C
  NOW C $tri F 8 ISET C $tri F IWRITE B

# ---- directories: 64-byte entries, 8 per block, loaded into DIRK
:DIRLOAD                   # (dir entry --)  the entry's block into DIRK
  8 V $dlb T $dld T
  $dld F $dltag F E $dlb F $dllb F E P DLHAVE *
  $dld F $dlb F 0 BMAP C D DLREAD *
  ! %DIRK 512 KZERO C DLSET B
:DLREAD
  %DIRK DREAD1 C
:DLSET
  $dld F $dltag T $dlb F $dllb T
:DLHAVE
  R
:DENT                      # (dir entry -- kaddr)  the entry's 64 bytes
  D 7 P 64 M $deo T DIRLOAD C $deo F %DIRK A R
:DIRN                      # (dir -- slots)
  4 IGET C 64 V R
:STREQ                     # (a b -- flag)
  OVER F OVER F = SQNO *
  OVER F SQYES J
  + SWAP + SWAP STREQ B
:SQYES
  ] 1 R
:SQNO
  ] 0 R
:DIRSCAN                   # (dir name -- ino | 0)  $dslot = its slot, $dfree = a free slot or -1
  $dsn T $dsd T 0 $dse T 0 1 S $dfree T 0 1 S $dslot T
  $dsd F DIRN C $dsmax T
:DSLP
  $dse F $dsmax F / DSNO *
  $dsd F $dse F DENT C $dsa T
  $dsa F LE32 C DSUSED *
  $dfree F 0 L DSNX J
  $dse F $dfree T DSNX B
:DSUSED
  $dsa F 4 A $dsn F STREQ C DSHIT *
:DSNX
  $dse PSTO DSLP B
:DSHIT
  $dse F $dslot T $dsa F LE32 B
:DSNO
  0 R
:DIRSET                    # (dir slot ino name --)  write one entry
  $dwn T $dwi T $dwe T $dwd T
  $dwd F $dwe F 8 V 1 BMAP C D DWBAD J
  $dwb T
  $dwd F $dwe F DENT C $dwa T
  $dwi F $dwa F SET32 C $dwa F 4 A 60 KZERO C
  $dwn F $dwa F 4 A
:DWCP
  OVER F D DWCPE J
  OVER T + SWAP + SWAP DWCP B
:DWCPE
  ! ]
  $dwb F %DIRK DWRITE1 C
  $dwe F 64 M 64 A $dwd F 4 IGET C G DWNOGROW J
  $dwe F 64 M 64 A $dwd F 4 ISET C
:DWNOGROW
  NOW C $dwd F 8 ISET C $dwd F IWRITE C 1 R
:DWBAD
  ! 0 R
:DIRADD                    # (dir name ino -- ok)
  $dai T $dan T $dad T
  $dad F $dan F DIRSCAN C DAEXIST *
  $dfree F D 0 L DAAPP *
  DAPUT B
:DAAPP                     # no free slot: a new one at the end
  ! $dad F DIRN C
:DAPUT
  $dad F SWAP $dai F $dan F DIRSET B
:DAEXIST
  17 $err T 0 R
:DIRDEL                    # (dir slot --)
  0 @"" DIRSET C ! R
:DIREMPTY                  # (dir -- flag)
  $dmd T 0 $dme T $dmd F DIRN C $dmx T
:DMLP
  $dme F $dmx F / DMYES *
  $dmd F $dme F DENT C LE32 C DMNO *
  $dme PSTO DMLP B
:DMYES
  1 R
:DMNO
  0 R
:DIRNTH                    # (dir i -- ino | 0)  the i-th used entry; name copied to KNAME
  $dhi T $dhd T 0 $dhe T $dhd F DIRN C $dhx T
:DHLP
  $dhe F $dhx F / DHNO *
  $dhd F $dhe F DENT C D LE32 C DHUSED *
  ! $dhe PSTO DHLP B
:DHUSED
  $dhi F DHHIT J
  ! $dhi F - $dhi T $dhe PSTO DHLP B
:DHHIT
  D 4 A @KNAME
:DHCP
  OVER F OVER T OVER F DHCPE J
  + SWAP + SWAP DHCP B
:DHCPE
  ] LE32 B
:DHNO
  0 R

# ---- paths: CANON makes an absolute path without . and .. (in CP);
#      NAMEI walks it from the root
:STRCPY                    # (src dst --)
  OVER F OVER T
  OVER F SCEND J
  + SWAP + SWAP STRCPY B
:SCEND
  ] R
:STRLEN                    # (a -- n)
  D
:STLLP
  D F STLEND J
  + STLLP B
:STLEND
  SWAP S R
:CANON                     # (path slot -- ok)  path (kernel RAM) -> CP; relative to the slot's cwd
  $cns T $cnp T 0 @TMP T
  $cnp F F '/' E CNABS *
  $cns F 128 M @PCWD A @TMP STRCPY C
  @TMP STRLEN C $cnl T '/' $cnl F @TMP A T 0 $cnl F + @TMP A T
:CNABS
  @TMP STRLEN C $cnl T
  $cnp F STRLEN C $cnl F A 250 G CNLONG *
  $cnp F @TMP $cnl F A STRCPY C
  0 $cpn T @TMP $cnq T
:CNCOMP                    # next component
  $cnq F F '/' = CNSTART *
  $cnq PSTO CNCOMP B
:CNSTART
  $cnq F F CNDONE J
  0 $cnk T
:CNC
  $cnq F $cnk F A F D CNCE J '/' E CNCE2 *
  $cnk PSTO CNC B
:CNCE
  !
:CNCE2
  $cnk F 1 E $cnq F F '.' E P CNSKIP *
  $cnk F 2 E $cnq F F '.' E P $cnq F + F '.' E P CNUP *
  $cnk F 59 G CNLONG *
  '/' $cpn F @CP A T $cpn PSTO 0 $cnj T
:CNCP
  $cnj F $cnk F / CNSKIP *
  $cnq F $cnj F A F $cpn F @CP A T $cpn PSTO $cnj PSTO CNCP B
:CNUP                      # .. : back to the previous /
  $cpn F CNSKIP J
  $cpn F - $cpn T
  $cpn F @CP A F '/' = CNUP *
:CNSKIP
  $cnq F $cnk F A $cnq T CNCOMP B
:CNDONE
  $cpn F CNROOT *
  '/' @CP T 1 $cpn T
:CNROOT
  0 $cpn F @CP A T 1 R
:CNLONG
  36 $err T 0 R
:NAMEI                     # (path -- ino | 0)  an absolute, canonical path (CP or CP2)
  + $nmp T 1 $nmi T
:NMLP
  $nmp F F NMRET J
  $nmi F 0 IGET C 2 = NMNOTDIR *
  0 $nmk T
:NMC
  $nmp F $nmk F A F D NMCE J '/' E NMCE2 *
  $nmk PSTO NMC B
:NMCE
  !
:NMCE2
  0 $nmj T
:NMCP                      # copy the component into COMP
  $nmj F $nmk F / NMCPE *
  $nmp F $nmj F A F $nmj F @COMP A T $nmj PSTO NMCP B
:NMCPE
  0 $nmj F @COMP A T
  $nmi F @COMP DIRSCAN C D NMNOENT J
  $nmi T $nmp F $nmk F A $nmp T
  $nmp F F NMRET J
  $nmp PSTO NMLP B
:NMRET
  $nmi F R
:NMNOENT
  ! 2 $err T 0 R
:NMNOTDIR
  20 $err T 0 R
:SPLIT                     # CP -> PARENTB (its directory) and LASTB (its last name)
  @CP STRLEN C $spl T
:SPLLP
  $spl F - D $spl T @CP A F '/' = SPLLP *
  @CP @PARENTB STRCPY C
  $spl F D SPLNR J
  @PARENTB A 0 SWAP T SPLNAME B
:SPLNR
  ! 0 @PARENTB + T
:SPLNAME
  @CP $spl F A + @LASTB STRCPY B
:PARENTI                   # ( -- dir ino | 0)  SPLIT, then the parent must be a directory
  SPLIT C @PARENTB NAMEI C D PIRET J
  D 0 IGET C 2 E PIRET *
  ! 20 $err T 0
:PIRET
  R

# =====================================================================
#  open files: 32 shared slots, each with a one-block buffer at FBUFK
# =====================================================================
:FBA                       # (f -- kaddr)  its block buffer
  512 M %FBUFK A R
:FBFLUSH                   # (f -- ok)  write the buffered block if it changed
  $fff T
  $fff F @FBD A F FFOK J
  $fff F @FI A F $fff F @FBL A F - 1 BMAP C D FFFAIL J
  $fff F FBA C DWRITE1 C 0 $fff F @FBD A T
:FFOK
  1 R
:FFFAIL
  ! 0 R
:FBLOAD                    # (f lb --)  that block into the buffer
  $flb T $flf T
  $flf F @FBL A F $flb F + E FLHAVE *
  $flf F FBFLUSH C !
  $flf F @FI A F $flb F 0 BMAP C D FLREAD *
  ! $flf F FBA C 512 KZERO C FLSET B
:FLREAD
  $flf F FBA C DREAD1 C
:FLSET
  $flb F + $flf F @FBL A T
:FLHAVE
  R
:FNEW                      # ( -- f | -1)  a free slot, owned by $cs
  0 $fnf T
:FNLP
  $fnf F %NF / FNFULL *
  $fnf F @FU A F FNGOT J
  $fnf PSTO FNLP B
:FNGOT
  1 $fnf F @FU A T 0 $fnf F @FP A T 0 $fnf F @FBL A T 0 $fnf F @FBD A T 0 $fnf F @FSZ A T
  $cs F $fnf F @FO A T $fnf F R
:FNFULL
  24 $err T 0 1 S R
:FHANDLE                   # (handle type -- f | -1)  one of this process's files
  $fht T 3 S $fhf T
  $fhf F 0 L FHBAD * $fhf F %NF / FHBAD *
  $fhf F @FU A F $fht F = FHBAD *
  $fhf F @FO A F $cs F = FHBAD *
  $fhf F R
:FHBAD
  9 $err T 0 1 S R
:FCLOSE                    # (f --)
  D FBFLUSH C !
  D @FSZ A F FCNOSZ J
  NOW C OVER @FI A F 8 ISET C D @FI A F IWRITE C
:FCNOSZ
  0 SWAP @FU A T R
:CLOSEALL                  # (slot --)  every file a process left open
  $cas T 0 $caf T
:CALP
  $caf F %NF / CARET *
  $caf F @FU A F CANX J
  $caf F @FO A F $cas F = CANX *
  $caf F FCLOSE C
:CANX
  $caf PSTO CALP B
:CARET
  R
:FSIZE                     # (f -- size)
  @FI A F 4 IGET B
:FGROW                     # (f --)  the size follows the position
  D @FP A F OVER FSIZE C G FGNO J
  D @FP A F OVER @FI A F 4 ISET C 1 SWAP @FSZ A T R
:FGNO
  ! R
:FREAD                     # (f paddr n -- count)  file -> process $cp
  $frn T $frp T $frf T 0 $frd T
  $frf F FSIZE C $frf F @FP A F S 0 MAX $frn F 0 MAX MIN $frn T
:FRLP
  $frd F $frn F / FRDONE *
  $frf F @FP A F 512 V $frl T $frf F @FP A F 511 P $fro T
  512 $fro F S $frn F $frd F S MIN $frc T
  $frf F $frl F FBLOAD C
  $frf F FBA C $fro F A %KA1 T $cp F %KA2 T $frp F $frd F A %KA3 T $frc F %KA4 T 8 %KCMD T
  $frf F @FP A F $frc F A $frf F @FP A T
  $frd F $frc F A $frd T FRLP B
:FRDONE
  $frd F R
:FWRITE                    # (f paddr n -- count)  process $cp -> file
  $fwn T $fwp T $fwf T 0 $fwd T
  $fwf F @FM A F 2 = FWLP *
  $fwf F FSIZE C $fwf F @FP A T
:FWLP
  $fwd F $fwn F / FWDONE *
  $nfree F 3 L FWFULL *
  $fwf F @FP A F 512 V $fwl T $fwf F @FP A F 511 P $fwo T
  512 $fwo F S $fwn F $fwd F S MIN $fwc T
  $fwf F $fwl F FBLOAD C
  $cp F %KA1 T $fwp F $fwd F A %KA2 T $fwf F FBA C $fwo F A %KA3 T $fwc F %KA4 T 7 %KCMD T
  1 $fwf F @FBD A T
  $fwf F @FP A F $fwc F A $fwf F @FP A T $fwf F FGROW C
  $fwd F $fwc F A $fwd T FWLP B
:FWFULL
  28 $err T
:FWDONE
  $fwd F R
:FWB                       # (byte f --)  one byte (a redirected PUTC)
  $fbf T $fbv T
  $nfree F 3 L FWBRET *
  $fbf F @FP A F 512 V $fbf F SWAP FBLOAD C
  $fbv F $fbf F FBA C $fbf F @FP A F 511 P A T
  1 $fbf F @FBD A T
  $fbf F @FP A PSTO $fbf F FGROW C
:FWBRET
  R

# =====================================================================
#  the fs bridge, answered from GenomeFS  (commands 1-28)
# =====================================================================
:FRES                      # (r1 --)  success
  1 SWAP $cs F SYSRES B
:FERR                      # failure with $err
  0 $err F $cs F SYSRES B
:R2                        # (v --)
  $cs F SYSRES2 B
:R3
  $cp F %FR3 ROT PPUT3 B
:R4
  $cp F %FR4 ROT PPUT3 B
:PATHA                     # (paddr -- ok)  a path from the process, made absolute in CP
  $cp F %KA1 T %KA2 T @PATHIN %KA3 T 255 %KA4 T 22 %KCMD T
  @PATHIN F PAEMPTY J
  @PATHIN $cs F CANON B
:PAEMPTY
  2 $err T 0 R
:COPYSTR                   # (kaddr dest max -- len)  a string to the process, cut to fit
  $csm T $csd T $csk T
  $csm F 1 L CSNONE *
  $csk F STRLEN C $csm F - MIN $csl T
  $csk F %KA1 T $cp F %KA2 T $csd F %KA3 T $csl F %KA4 T 8 %KCMD T
  $cp F $csd F $csl F A 0 PPUT3 C $csl F R
:CSNONE
  0 R
:TYPE                      # (ino -- type)
  0 IGET B

:FSCALL                    # (command --)  for slot $cs
  $fsc T 0 $err T
  $cp F 4129 PGET2 C $a1 T $cp F 4130 PGET2 C $a2 T
  $cp F 4131 PGET2 C $a3 T $cp F 4132 PGET2 C $a4 T
  $fsc F 1 L FSBAD *
  $fsc F 28 G FSBAD *
  $fsc F 2 M FSTAB A B
:FSBAD
  22 $err T FERR B
:FSTAB                     # two cells per entry: address, jump
  FSBAD B FS1 B FS2 B FS3 B FS4 B FS5 B FS6 B FS7 B FS8 B FS9 B FS10 B FS11 B FS12 B FS13 B
  FS14 B FS15 B FS16 B FS17 B FS18 B FS19 B FS20 B FS21 B FS22 B FS23 B FS24 B FS25 B FS26 B FS27 B FS28 B

:LOOKA                     # (paddr -- ino | 0)  a path argument, looked up
  PATHA C D LKRET J
  ! @CP NAMEI B
:LKRET
  R
:FS1                       # stat(path) -> size type mode mtime
  $a1 F LOOKA C D FSNO J
  D 12 IGET C R3 C D 8 IGET C R4 C D TYPE C R2 C 4 IGET C FRES B
:FSNO
  ! FERR B
:FS2                       # opendir(path) -> handle count
  $a1 F LOOKA C D FSNO J
  D TYPE C 2 E FS2OK *
  ! 20 $err T FERR B
:FS2OK
  FNEW C D 0 L FSNO *
  2 OVER @FU A T SWAP OVER @FI A T
  D @FI A F 0 $o2n T $o2i T
:FS2CNT                    # used entries
  $o2i F $o2n F DIRNTH C FS2END J
  $o2n PSTO FS2CNT B
:FS2END
  $o2n F R2 C 3 A FRES B
:FS3                       # dirent(handle, i, dest, max) -> len type mode size
  $a1 F 2 FHANDLE C D 0 L FSNO *
  @FI A F $a2 F DIRNTH C D FS3END J
  @KNAME $a3 F $a4 F COPYSTR C $d3l T
  D TYPE C R2 C D 12 IGET C R3 C 4 IGET C R4 C $d3l F FRES B
:FS3END
  ! 22 $err T FERR B
:FS4                       # closedir
  $a1 F 2 FHANDLE C D 0 L FSNO *
  0 SWAP @FU A T 0 FRES B
:MKONE                     # ( -- ino | 0)  make the directory CP
  PARENTI C D MKRET J
  @LASTB F MKEX J
  2 IALLOC C D MKFAIL J
  $mkn T $mkd T
  $mkd F @LASTB $mkn F DIRADD C MKOK *
  $mkn F IFREE C 0 R
:MKOK
  $mkn F R
:MKEX
  ! 17 $err T 0 R
:MKFAIL
  ] 0 R
:MKRET
  R
:FS5                       # mkdir(path, parents)
  $a1 F PATHA C FSNO0 J
  $a2 F FS5P *
  @CP NAMEI C FS5EX *
  0 $err T MKONE C FSNO0 J
  0 FRES B
:FS5EX
  17 $err T FERR B
:FSNO0
  FERR B
:FS5P                      # with parents: every prefix in turn
  1 $mpi T
:FS5PL
  $mpi F @CP A F D '/' E SWAP N O FS5PDO *
  $mpi PSTO FS5PL B
:FS5PDO
  $mpi F @CP A F $mpc T 0 $mpi F @CP A T
  @CP NAMEI C D FS5PHAVE *
  ! 0 $err T MKONE C D FS5PERR J
:FS5PHAVE
  TYPE C 2 = FS5PNOT *
  $mpc F $mpi F @CP A T
  $mpc F FS5POK J
  $mpi PSTO FS5PL B
:FS5POK
  0 FRES B
:FS5PNOT
  20 $err T FERR B
:FS5PERR
  ! FERR B
:REMOVE                    # (ino --)  CP's entry goes; the inode goes when nothing links to it
  $rmi T
  PARENTI C D RMRET J
  @LASTB DIRSCAN C ! $dsd F $dslot F DIRDEL C
  $rmi F 16 IGET C - D $rmi F 16 ISET C RMKEEP *
  $rmi F TRUNC C $rmi F IFREE C
:RMKEEP
  $rmi F IWRITE C 1 R
:RMRET
  R
:FS6                       # rmdir
  $a1 F LOOKA C D FSNO J
  D 1 E FS6BUSY *
  D TYPE C 2 E FS6DIR *
  ! 20 $err T FERR B
:FS6DIR
  D DIREMPTY C FS6GO *
  ! 39 $err T FERR B
:FS6GO
  REMOVE C ! 0 FRES B
:FS6BUSY
  ! 16 $err T FERR B
:FS7                       # unlink
  $a1 F LOOKA C D FSNO J
  D TYPE C 2 = FS7GO *
  ! 21 $err T FERR B
:FS7GO
  REMOVE C ! 0 FRES B

:FS8                       # rename(src, dst)
  $a1 F LOOKA C D FSNO J
  D 1 E FS6BUSY *
  $rsi T @CP @CP2 STRCPY C
  $a2 F PATHA C FSNO0 J
  @CP @CP2 STREQ C FS8SAME *
  @CP2 STRLEN C $rsl T                  # into itself?
  @CP $rsl F A F '/' E FS8NOPRE J
  $rsl F @CP A F $rsc T 0 $rsl F @CP A T
  @CP @CP2 STREQ C $rsc F $rsl F @CP A T FS8INTO *
:FS8NOPRE
  0 $err T @CP NAMEI C $rdi T 0 $err T
  $rdi F FS8FREE J
  $rdi F TYPE C 2 E FS8DDIR *
  $rsi F TYPE C 2 E FS8ENOTDIR *
  $rdi F REMOVE C ! FS8FREE B
:FS8DDIR
  $rsi F TYPE C 2 = FS8EISDIR *
  $rdi F DIREMPTY C FS8ENOTEMPTY J
  $rdi F REMOVE C !
:FS8FREE
  PARENTI C D FSNO J
  @LASTB @DNAME STRCPY C
  @DNAME $rsi F DIRADD C FSNO0 J
  @CP2 @CP STRCPY C PARENTI C D FSNO J
  @LASTB DIRSCAN C ! $dsd F $dslot F DIRDEL C
:FS8SAME
  0 FRES B
:FS8INTO
  22 $err T FERR B
:FS8ENOTDIR
  20 $err T FERR B
:FS8EISDIR
  21 $err T FERR B
:FS8ENOTEMPTY
  39 $err T FERR B

:FS9                       # open(path, mode) -> handle
  $a1 F PATHA C FSNO0 J
  @CP NAMEI C D FS9HAVE *
  ! $a2 F 3 P FS9NEW *
  2 $err T FERR B
:FS9NEW                    # create it
  0 $err T PARENTI C D FSNO J
  @LASTB F FS9NAME J
  1 IALLOC C D FS9FULL J
  $o9n T $o9d T
  $o9d F @LASTB $o9n F DIRADD C FS9MADE *
  $o9n F IFREE C FERR B
:FS9FULL
  ] FERR B
:FS9NAME
  ! 21 $err T FERR B
:FS9MADE
  $o9n F
:FS9HAVE
  D TYPE C 2 = FS9FILE *
  ! 21 $err T FERR B
:FS9FILE
  $a2 F 3 P 1 = FS9NOTR *
  D TRUNC C
:FS9NOTR
  FNEW C D 0 L FSNO *
  SWAP OVER @FI A T
  $a2 F 3 P OVER @FM A T
  $a2 F 3 P 2 = FS9POS *
  D FSIZE C OVER @FP A T
:FS9POS
  3 A FRES B
:FS10                      # read(fd, addr, n) -> count
  $a1 F 1 FHANDLE C D 0 L FSNO *
  $a2 F $a3 F 0 MAX 65536 MIN FREAD C FRES B
:FS11                      # write(fd, addr, n) -> count
  $a3 F 0 MAX 65536 MIN $a3 T
  $a1 F 1 E FS11OUT *
  $a1 F 2 E FS11ERR *
  $a1 F 1 FHANDLE C D 0 L FSNO *
  D @FM A F FS11RO J
  $a2 F $a3 F FWRITE C
  $err F FS11PART J
  D FS11PART *
  ! FERR B
:FS11PART
  FRES B
:FS11RO
  ! 9 $err T FERR B
:FS11OUT                   # stdout: wherever PUTC goes
  $a3 F FRES C $a2 F $a3 F $cs F STDOUTW B
:FS11ERR
  $a3 F FRES C $a2 F $a3 F CONW B
:FS12                      # close
  $a1 F 1 FHANDLE C D 0 L FSNO *
  D 1 A $cs F @PRED A F = FS12GO *
  0 $cs F @PRED A T
:FS12GO
  FCLOSE C 0 FRES B
:FS13                      # seek(fd, off, whence, negative) -> pos
  $a1 F 1 FHANDLE C D 0 L FSNO *
  $sko T
  $a3 F FS13B J
  $a3 F 1 E FS13C *
  $sko F FSIZE C FS13B2 B
:FS13C
  $sko F @FP A F FS13B2 B
:FS13B
  0
:FS13B2
  $a4 F FS13PLUS J
  $a2 F S FS13SET B
:FS13PLUS
  $a2 F A
:FS13SET
  D 0 L FS13NEG *
  D $sko F @FP A T FRES B
:FS13NEG
  ! 22 $err T FERR B
:FS14                      # chdir
  $a1 F LOOKA C D FSNO J
  TYPE C 2 E FS14OK *
  20 $err T FERR B
:FS14OK
  @CP $cs F 128 M @PCWD A STRCPY C 0 FRES B
:FS15                      # getcwd(dest, max) -> len
  $cs F 128 M @PCWD A $a1 F $a2 F COPYSTR C FRES B
:FS16                      # utime
  $a1 F LOOKA C D FSNO J
  NOW C OVER 8 ISET C IWRITE C 0 FRES B
:FS17                      # chmod
  $a1 F LOOKA C D FSNO J
  $a2 F 4095 P OVER 12 ISET C IWRITE C 0 FRES B
:FS18                      # time -> seconds, UTC offset
  23 %KCMD T %KR2 F $tzo T %KR1 F $tnow T
  $tzo F R2 C $tnow F FRES B
:FS19                      # strerror(errno, dest, max) -> len
  $a1 F %KA1 T @KNAME %KA2 T 120 %KA3 T 24 %KCMD T
  @KNAME $a2 F $a3 F COPYSTR C FRES B
:FS20                      # redirect stdout (path, append), path 0 = back
  $cs F @PRED A F D FS20NONE J
  - FCLOSE C 0 $cs F @PRED A T FS20NEW B
:FS20NONE
  !
:FS20NEW
  $a1 F FS20DONE J
  $a2 F BOOL + $a2 T 3 $a3 T
  $a1 F PATHA C FSNO0 J                 # open with mode 1 (truncate) or 2 (append)
  @CP NAMEI C D FS20HAVE *
  ! 0 $err T PARENTI C D FSNO J
  @LASTB F FS9NAME J
  1 IALLOC C D FS9FULL J
  $o9n T $o9d T
  $o9d F @LASTB $o9n F DIRADD C FS20MADE *
  $o9n F IFREE C FERR B
:FS20MADE
  $o9n F
:FS20HAVE
  D TYPE C 2 = FS20FILE *
  ! 21 $err T FERR B
:FS20FILE
  $a2 F 1 = FS20NOTR *
  D TRUNC C
:FS20NOTR
  FNEW C D 0 L FSNO *
  SWAP OVER @FI A T
  $a2 F OVER @FM A T
  $a2 F 2 = FS20POS *
  D FSIZE C OVER @FP A T
:FS20POS
  + $cs F @PRED A T
:FS20DONE
  0 FRES B
:FS21                      # isatty -> stdout tty, stdin tty, columns
  14 %KCMD T %KR1 F 20 MAX 400 MIN R3 C
  $cs F @PIN A F N R2 C
  $cs F @POUT A F $cs F @PRED A F O N FRES B
:FS22                      # realpath(path, dest, max) -> len
  $a1 F PATHA C FSNO0 J
  @CP $a2 F $a3 F COPYSTR C FRES B
:FS23                      # getenv(name, dest, max) -> len
  $cp F %KA1 T $a1 F %KA2 T @PATHIN %KA3 T 60 %KA4 T 22 %KCMD T
  @PATHIN @"HOME" STREQ C FS23HOME *
  @PATHIN @"USER" STREQ C FS23USER *
  @PATHIN @"SHELL" STREQ C FS23SHELL *
  @PATHIN @"PATH" STREQ C FS23PATH *
  @PATHIN @"PWD" STREQ C FS23PWD *
  2 $err T FERR B
:FS23HOME
  @"/home" FS23V B
:FS23USER
  @"genome" FS23V B
:FS23SHELL
  @"/bin/gsh" FS23V B
:FS23PATH
  @"/bin" FS23V B
:FS23PWD
  $cs F 128 M @PCWD A
:FS23V
  $a2 F $a3 F COPYSTR C FRES B
:FS24                      # samefile(a, b) -> same, b inside a
  $a1 F PATHA C FSNO0 J
  @CP NAMEI C $sfa T @CP @CP2 STRCPY C 0 $err T
  $a2 F PATHA C FSNO0 J
  @CP NAMEI C $sfb T 0 $err T
  0 $sfin T
  @CP2 STRLEN C $sfl T
  $sfl F 1 E FS24ROOT *
  @CP $sfl F A F '/' = FS24NO *
  $sfl F @CP A F $sfc T 0 $sfl F @CP A T
  @CP @CP2 STREQ C $sfin T $sfc F $sfl F @CP A T FS24NO B
:FS24ROOT
  @CP F '/' E @CP + F BOOL P $sfin T
:FS24NO
  $sfin F R2 C
  $sfa F $sfb F E $sfa F BOOL P FRES B
:FS25                      # errmode
  $a1 F 1 P $cs F @PERR A T 0 FRES B
:FS26                      # statvfs -> total, free, available bytes
  $nfree F 512 M D R3 C R2 C $total F 512 M FRES B
:FS27                      # link(target, linkpath, hard)
  $a3 F FS27SYM J
  $a1 F LOOKA C D FSNO J
  D TYPE C 1 E FS27FILE *
  ! 1 $err T FERR B
:FS27FILE
  $lki T
  $a2 F PATHA C FSNO0 J
  PARENTI C D FSNO J
  @LASTB $lki F DIRADD C FSNO0 J
  $lki F 16 IGET C + $lki F 16 ISET C $lki F IWRITE C 0 FRES B
:FS27SYM
  38 $err T FERR B
:FS28                      # readlink: GenomeFS has no symbolic links
  22 $err T FERR B

:CONW                      # (paddr n --)  bytes from the process to the console
  $cwn T $cwp T
  $cp F %KA1 T $cwp F %KA2 T %KBUF %KA3 T $cwn F %KA4 T 7 %KCMD T
  0 $cwi T
:CWLP
  $cwi F $cwn F / CWRET *
  %KBUF $cwi F A F $cs F CONOUT C $cwi PSTO CWLP B
:CWRET
  R
:STDOUTW                   # (paddr n slot --)  a write to fd 1
  $sws T $swn T $swp T
  $sws F @PERR A F SWCON *
  $sws F @PRED A F D SWFILE *
  ! $sws F @POUT A F SWCON J
  $cp F %KA1 T $swp F %KA2 T $sws F 4224 M %PPBK A $sws F @PPN A F A %KA3 T $swn F 4100 MIN %KA4 T 7 %KCMD T
  $sws F @PPN A F $swn F 4100 MIN A $sws F @PPN A T
  $sws F OUTCHECK C ! R
:SWFILE
  - $swp F $swn F FWRITE C ! R
:SWCON
  $swp F $swn F CONW B

:LE32                      # (addr -- n)  little-endian 32-bit
  D F OVER + F 8 < O OVER 2 A F 16 < O SWAP 3 A F 24 < O R

# ---------------------------------------------------------------------
#  pipes: 8 rings of %QSIZE bytes
# ---------------------------------------------------------------------
:QNEW                      # ( -- id | 0)
  0 $qi T
:QNLP
  $qi F %NQ / QNNO *
  $qi F @QUSE A F QNGOT J
  $qi PSTO QNLP B
:QNGOT
  1 $qi F @QUSE A T 0 $qi F @QHEAD A T 0 $qi F @QCNT A T
  0 $qi F @QW A T 0 $qi F @QR A T 0 $qi F @QHADW A T 0 $qi F @QHADR A T
  $qi F + R
:QNNO
  0 R
:QFREEMAYBE                # (id --)  free a pipe nobody uses any more
  - $qf T
  $qf F @QW A F $qf F @QR A F O QFRET *
  0 $qf F @QUSE A T
:QFRET
  R
:QEOF                      # (id -- flag)  empty, and every writer has gone
  - D @QCNT A F QEOFNO *
  D @QHADW A F SWAP @QW A F N P R
:QEOFNO
  ! 0 R
:QGET                      # (id -- byte)  caller checked QCNT > 0
  - $qg T
  $qg F @QHEAD A F $qg F %QSIZE M A @QBUF A F
  $qg F @QHEAD A F + %QSIZE MOD $qg F @QHEAD A T
  $qg F @QCNT A F - $qg F @QCNT A T R
:QFEED                     # (pid id --)  hand a reader what the pipe holds (one stretch)
  - $qfq T $qfp T
  $qfq F @QCNT A F %QSIZE $qfq F @QHEAD A F S MIN 4095 MIN $qfn T
  $qfn F QFDRET J
  $qfp F %KA1 T $qfq F %QSIZE M @QBUF A $qfq F @QHEAD A F A %KA2 T $qfn F %KA3 T 25 %KCMD T
  $qfq F @QHEAD A F $qfn F A %QSIZE MOD $qfq F @QHEAD A T
  $qfq F @QCNT A F $qfn F S $qfq F @QCNT A T
:QFDRET
  R
:QPUT                      # (byte id --)  caller checked there is room
  - $qp T
  $qp F @QHEAD A F $qp F @QCNT A F A %QSIZE MOD $qp F %QSIZE M A @QBUF A T
  $qp F @QCNT A PSTO R
:QHASNL                    # (id -- flag)  a whole line is waiting
  - $qh T 0 $qhi T
:QHLP
  $qhi F $qh F @QCNT A F / QHNO *
  $qh F @QHEAD A F $qhi F A %QSIZE MOD $qh F %QSIZE M A @QBUF A F 10 E QHYES *
  $qhi PSTO QHLP B
:QHYES
  1 R
:QHNO
  0 R
:QLINENUM                  # (id -- n)  read a line from a pipe as a number (-1 at the end)
  $ql1 T
  $ql1 F - @QCNT A F QLNEOF J
  0 $qlv T 0 $qls T 0 $qld T
:QLNLP
  $ql1 F - @QCNT A F QLNEND J
  $ql1 F QGET C
  D 10 E QLNNL *
  D '-' E $qld F N P QLNNEG *
  D '0' L QLNSKIP * D '9' G QLNSKIP *
  '0' S $qlv F 10 M A $qlv T 1 $qld T QLNLP B
:QLNNEG
  ! 1 $qls T QLNLP B
:QLNSKIP
  ! QLNLP B
:QLNNL
  !
:QLNEND
  $qls F QLNPOS J
  $qlv F ~ R
:QLNPOS
  $qlv F R
:QLNEOF
  0 1 S R

:PIPEFLUSH                 # (slot -- done)  move a writer's pending bytes into its pipe
  $pfs T $pfs F @POUT A F $pfq T
  $pfq F - @QR A F $pfq F - @QHADR A F N O PFOK *
  PFBROKEN B
:PFOK
:PFLP                      # copy as much as fits, in at most two stretches of the ring
  $pfs F @PPI A F $pfs F @PPN A F / PFDONE *
  $pfq F - $pfx T
  $pfx F @QCNT A F %QSIZE / PFFULL *
  $pfx F @QHEAD A F $pfx F @QCNT A F A %QSIZE MOD $pft T
  $pfs F @PPN A F $pfs F @PPI A F S
  %QSIZE $pfx F @QCNT A F S MIN %QSIZE $pft F S MIN $pfn T
  $pfs F 4224 M %PPBK A $pfs F @PPI A F A %KA1 T
  $pfx F %QSIZE M @QBUF A $pft F A %KA2 T $pfn F %KA3 T 20 %KCMD T
  $pfx F @QCNT A F $pfn F A $pfx F @QCNT A T
  $pfs F @PPI A F $pfn F A $pfs F @PPI A T PFLP B
:PFDONE
  0 $pfs F @PPN A T 0 $pfs F @PPI A T 1 R
:PFFULL
  0 R
:PFBROKEN                  # nobody reads this pipe any more
  141 $pfs F KILLSLOT C 0 R

:PIPEREADERS               # (id --)  give waiting readers what has arrived
  $prq T 0 $pri T
:PRLP
  $pri F %NP / PRRET *
  $pri F @PIN A F $prq F = PRNX *
  $pri F @PST A F %SPGETC E PRGETC *
  $pri F @PST A F %SPIN E PRIN *
:PRNX
  $pri PSTO PRLP B
:PRGETC
  $prq F - @QCNT A F PRGEOF J
  $pri F @PPID A F $prq F QGET C PPUSH C $pri F @PPID A F $prq F QFEED C PRREADY B
:PRGEOF
  $prq F QEOF C PRNX J
  $pri F @PPID A F 0 1 S PPUSH C
:PRREADY
  %SREADY $pri F @PST A T PRNX B
:PRIN
  $prq F QHASNL C $prq F QEOF C O PRNX J
  $pri F @PPID A F $prq F QLINENUM C PPUSH C PRREADY B
:PRRET
  R
:PIPEWRITERS               # (id --)  room again: let blocked writers go on
  $pwq T 0 $pwi T
:PWLP
  $pwi F %NP / PWRET *
  $pwi F @POUT A F $pwq F = PWNX *
  $pwi F @PST A F %SPPUT = PWNX *
  $pwi F PIPEFLUSH C PWNX J
  $pwi F @PFL A F 8 P PWEXIT *
  %SREADY $pwi F @PST A T PWNX B
:PWEXIT                    # it had finished: its last bytes are out now
  $pwi F @PWT A F $pwi F KILLSLOT C
:PWNX
  $pwi PSTO PWLP B
:PWRET
  R
:PUMP                      # move data through every pipe
  1 $pmq T
:PMLP
  $pmq F %NQ G PMRET *
  $pmq F - @QUSE A F PMNX J
  $pmq F PIPEREADERS C $pmq F PIPEWRITERS C $pmq F PIPEREADERS C
:PMNX
  $pmq PSTO PMLP B
:PMRET
  R

:PPBADD                    # (byte slot --)  queue a byte for the pipe
  $pas T $pas F 4224 M %PPBK A $pas F @PPN A F A T $pas F @PPN A PSTO R
:OUTCHECK                  # (slot -- running)  send the queue when it is long enough
  $ocs T $ocs F @PPN A F 20 L OCRUN *
  $ocs F PIPEFLUSH C OCRUN *
  $ocs F @PST A F %SDYING E OCSTOP *
  %SPPUT $ocs F @PST A T
:OCSTOP
  0 R
:OCRUN
  1 R
:OUTBYTE                   # (byte slot -- running)  a program writes one byte
  $obs T
  $obs F @PERR A F OBCON *
  $obs F @PRED A F OBFILE *
  $obs F @POUT A F OBCON J
  $obs F PPBADD C $obs F OUTCHECK B
:OBCON
  $obs F CONOUT C 1 R
:OBFILE                    # stdout redirected to a file
  $obs F @PRED A F - FWB C 1 R
:EMIT1                     # (byte --)  one byte of a number for $onsl
  $onsl F @PERR A F EMCON *
  $onsl F @PRED A F EMFILE *
  $onsl F @POUT A F EMCON J
  $onsl F PPBADD B
:EMCON
  $onsl F CONOUT B
:EMFILE
  $onsl F @PRED A F - FWB B
:OUTNUM                    # (n slot -- running)  all digits go out together
  $onsl T
  D 0 L ONNEG *
  ONU B
:ONNEG
  '-' EMIT1 C ~
:ONU
  0 $onn T
:ONLP
  D 10 MOD '0' A $onn F @NUMC A T $onn PSTO 10 V
  D ONLP *
  !
:ONOUT
  $onn F ONEND J
  $onn F - D $onn T @NUMC A F EMIT1 C ONOUT B
:ONEND
  $onsl F @PERR A F $onsl F @PRED A F O ONCON *
  $onsl F @POUT A F ONCON J
  $onsl F OUTCHECK B
:ONCON
  1 R

# ---------------------------------------------------------------------
#  processes
# ---------------------------------------------------------------------
:NEWPROC                   # (ino -- slot | NONE)  load the program file; path in CP
  $npe T 0 $nps T
:NPFREE
  $nps F %NP / NPFULL *
  $nps F @PST A F NPGOT J
  $nps PSTO NPFREE B
:NPGOT
  $npe F 0 IGET C 1 = NPBAD *
  $npe F 4 IGET C $npz T 0 $npb T
:NPLOAD                    # every block of the file into LOADAT
  $npb F 512 M $npz F / NPLOADED *
  $npe F $npb F 0 BMAP C D NPRD *
  ! %LOADAT $npb F 512 M A 512 KZERO C NPLNX B
:NPRD
  %LOADAT $npb F 512 M A DREAD1 C
:NPLNX
  $npb PSTO NPLOAD B
:NPLOADED
  %LOADAT %KA1 T $npz F %KA2 T 3 %KCMD T
  %KST F NPBAD J
  %KR1 F $nps F @PPID A T
  %SREADY $nps F @PST A T
  0 $nps F @PPAR A T 0 $nps F @PIN A T 0 $nps F @POUT A T 0 $nps F @PFL A T
  0 $nps F @PWT A T 0 $nps F @PLN A T 0 $nps F @PPN A T 0 $nps F @PPI A T
  0 $nps F @PRED A T 0 $nps F @PERR A T
  0 $nps F 80 M @PARG A T
  '/' $nps F 128 M @PCWD A T 0 $nps F 128 M @PCWD A + T
  0 $npk T
:NPNAME                    # its path, for ps
  $npk F 63 / NPNEND *
  $npk F @CP A F D $npk F $nps F 64 M @PNM A A T NPNEND0 J
  $npk PSTO NPNAME B
:NPNEND
  0 $nps F 64 M @PNM A 63 A T NPNE2 B
:NPNEND0
:NPNE2
  $nps F @PPID A F %TMAGICC %TTYMAGIC PPUT3 C
  $nps F @PPID A F 4138 18003 PPUT3 C
  $nps F R
:NPBAD
:NPFULL
  %NONE R

:KILLSLOT                  # (code slot --)  the process stops; tidied up by REAP
  D @PST A F %SFREE E KSRET *
  D @PST A F %SZOMB E KSRET *
  SWAP OVER @PWT A T %SDYING SWAP @PST A T R
:KSRET
  ] R

:REAP                      # tidy up every process that has stopped
  0 $rpi T
:RPLP
  $rpi F %NP / RPRET *
  $rpi F @PST A F %SDYING E RPGO *
  $rpi PSTO RPLP B
:RPGO
  $rpi F EXITPROC C REAP B
:RPRET
  R

:EXITPROC                  # (slot --)
  $xs T $xs F @PPID A F $xp T $xs F @PWT A F $xc T
  $xp F %KA1 T 4 %KCMD T
  $xs F CLOSEALL C
  $xs F @PLN A F $conown F $xs F E P XNOLN J
  10 OBC C %NONE $conown T 0 $xs F @PLN A T
:XNOLN
  $xs F @POUT A F D XNOOUT J
  D - @QW A F - OVER - @QW A T
  D QFREEMAYBE C
:XNOOUT
  !
  $xs F @PIN A F D XNOIN J
  D - @QR A F - OVER - @QR A T
  D - @QR A F XRDGONE J
  QFREEMAYBE C XNOIN0 B
:XRDGONE                   # the last reader: writers blocked on this pipe get "broken pipe"
  D $xq T QFREEMAYBE C 0 $xi T
:XRDLP
  $xi F %NP / XNOIN0 *
  $xi F @POUT A F $xq F E $xi F @PST A F %SPPUT E P XRDNX J
  141 $xi F KILLSLOT C
:XRDNX
  $xi PSTO XRDLP B
:XNOIN
  !
:XNOIN0
  0 $xi T                  # orphans: zombies go, the living are given to init
:XORLP
  $xi F %NP / XOREND *
  $xi F @PST A F XORNX J
  $xi F @PPAR A F $xp F = XORNX *
  $xi F @PST A F %SZOMB E XORFREE *
  1 $xi F @PPAR A T XORNX B
:XORFREE
  0 $xi F @PST A T
:XORNX
  $xi PSTO XORLP B
:XOREND
  $xs F @PPAR A F SLOTOF C $xps T
  $fg F $xs F = XNOFG *
  $xps F $fg T
:XNOFG
  $xp F 1 E $hasinit F P XINIT *
  $xps F %NONE E XFREE *
  $xps F @PST A F %SWAIT E $xps F @PWT A F $xp F E P XWAITER *
  $xs F @PFL A F 1 P XBGDONE *
  $xc F $xs F @PWT A T %SZOMB $xs F @PST A T R
:XWAITER                   # the parent is waiting for exactly this one
  1 $xc F $xps F SYSRES C %SREADY $xps F @PST A T
:XFREE
  0 $xs F @PST A T R
:XBGDONE
  KMSG C $xs F PNAMEOUT C @" done" OBS C
  $xc F XBGOK J
  @" (exit " OBS C $xc F OBN C 41 OBC C
:XBGOK
  KMSGEND C XFREE B
:XINIT
  KMSG C @"[kernel] init has stopped - power off" OBS C KMSGEND C
  0 %KA1 T 19 %KCMD T H

:SPAWNSYS                  # (slot --)  syscall 100 from slot
  $sys T $sys F @PPID A F $syp T
  $syp F 4129 PGET2 C $sa1 T $syp F 4130 PGET2 C $sa2 T
  $syp F 4131 PGET2 C $sa3 T $syp F 4132 PGET2 C $sa4 T
  $syp F %KA1 T $sa1 F %KA2 T @NAMEB 5 A %KA3 T 56 %KA4 T 22 %KCMD T
  @NAMEB 5 A $spq T
:SPSL                      # a name without / is looked up in /bin
  $spq F F D SPBIN J '/' E SPREL *
  $spq PSTO SPSL B
:SPBIN
  ! '/' @NAMEB T 'b' @NAMEB + T 'i' @NAMEB 2 A T 'n' @NAMEB 3 A T '/' @NAMEB 4 A T
  @NAMEB SPCAN B
:SPREL
  @NAMEB 5 A
:SPCAN
  $sys F CANON C SPNOENT0 J
  @CP NAMEI C D SPNOENT J
  D 0 IGET C 1 = SPNOENT *
  NEWPROC C D %NONE E SPNOMEM *
  $sns T
  $syp F $sns F @PPAR A T
  $sa4 F 1 P $sns F @PFL A T
  $sys F 128 M @PCWD A $sns F 128 M @PCWD A STRCPY C
  $sa2 F SPNOARG J
  $syp F %KA1 T $sa2 F %KA2 T $sns F 80 M @PARG A %KA3 T 78 %KA4 T 22 %KCMD T
:SPNOARG
  $sa3 F 255 P 9 MOD D SPNOIN J
  D $sns F @PIN A T D - @QR A PSTO D - 1 SWAP @QHADR A T
:SPNOIN
  !
  $sa3 F 8 > 255 P 9 MOD D SPNOOUT J
  D $sns F @POUT A T D - @QW A PSTO D - 1 SWAP @QHADW A T
:SPNOOUT
  !
  $sys F @PRED A F D SPNORED J      # the parent's stdout is redirected: the child inherits it
  - $spf T $sns F @POUT A F SPNORED *
  FNEW C D 0 L SPNORED *
  $sns F OVER @FO A T D + $sns F @PRED A T
  $spf F @FI A F OVER @FI A T $spf F @FM A F OVER @FM A T $spf F @FP A F OVER @FP A T
:SPNORED
  !
  $sa4 F 1 P SPBG *
  $sns F $fg T
:SPBG
  1 $sns F @PPID A F $sys F SYSRES C R
:SPNOENT
  !
:SPNOENT0
  0 2 $sys F SYSRES C R
:SPNOMEM
  ! 0 12 $sys F SYSRES C R

# ---------------------------------------------------------------------
#  console input: the line being typed (LB), keys for full-screen programs (KQ)
# ---------------------------------------------------------------------
:LBRESET
  0 $lbn T 0 $lbp T 0 $lbready T R
:HAVEINPUT                 # ( -- flag)  a line, or the end of input (once typed-ahead keys are used)
  $lbready F $lbeof F O $eof F $tan F N P O R
:NEXTCH                    # ( -- byte | -1)
  $lbready F NCNOLINE J
  $lbp F @LB A F $lbp PSTO
  $lbp F $lbn F L NCRET *
  LBRESET C
:NCRET
  R
:NCNOLINE
  0 $lbeof T 0 1 S R
:NOWAITER                  # ( -- flag)  nobody is reading the console right now
  READER C %NONE E R
:LBFEED                    # (pid --)  the rest of the typed line, in one go
  $lbready F LBFRET J
  $lbp F $lbn F / LBFRET *
  %KA1 T @LB $lbp F A %KA2 T $lbn F $lbp F S %KA3 T 25 %KCMD T
  LBRESET B
:LBFRET
  ! R
:LINENUM                   # ( -- n | -1)  the typed line as a number
  $lbready F NCNOLINE J
  0 $lnv T 0 $lns T 0 $lnd T
:LNLP
  $lbp F $lbn F / LNEND *
  $lbp F @LB A F $lbp PSTO
  D '-' E $lnd F N P LNNEG *
  D '0' L LNSKIP * D '9' G LNSKIP *
  '0' S $lnv F 10 M A $lnv T 1 $lnd T LNLP B
:LNNEG
  ! 1 $lns T LNLP B
:LNSKIP
  ! LNLP B
:LNEND
  LBRESET C
  $lns F LNPOS J
  $lnv F ~ R
:LNPOS
  $lnv F R

:READER                    # ( -- slot | NONE)  who gets the typed line
  $fg F %NONE E RDANY *
  $fg F @PST A F %SCGETC E $fg F @PST A F %SCIN E O RDANY J
  $fg F @PFL A F 2 P RDANY *
  $fg F R
:RDANY
  0 $rdj T
:RDJLP
  $rdj F %NP / RDJNO *
  $rdj F @PFL A F 3 P RDJNX *
  $rdj F @PST A F %SCGETC E $rdj F @PST A F %SCIN E O RDJHIT *
:RDJNX
  $rdj PSTO RDJLP B
:RDJHIT
  $rdj F R
:RDJNO
  %NONE R
:WAKE                      # give typed input to a program waiting for it
  HAVEINPUT C WKRET J
  READER C D %NONE E WKNONE *
  $wks T
  $wks F @PST A F %SCIN E WKIN *
  NEXTCH C WKGIVE B
:WKIN
  LINENUM C
:WKGIVE
  $wks F @PPID A F SWAP PPUSH C
  %SREADY $wks F @PST A T
  $eof F WAKE *
:WKRET
  R
:WKNONE
  ! R

:KQADD                     # (key c r b --)  queue a key for the full-screen foreground
  $kqn F 32 / KQFULL *
  $kqh F $kqn F A 31 P 4 M @KQ A $kqa T
  $kqa F 3 A T $kqa F 2 A T $kqa F + T $kqa F T $kqn PSTO R
:KQFULL
  ] ] R
:KQPOP                     # ( -- addr)  the oldest key (4 cells)
  $kqh F 4 M @KQ A $kqh F + 31 P $kqh T $kqn F - $kqn T R
:KEYSTOFG                  # hand queued keys to a full-screen foreground that waits
  $fg F %NONE E KFRET *
  $kqn F KFRET J
  $fg F @PST A F %SKEY E KFKEY *
  $fg F @PST A F %SCGETC E KFGETC *
:KFRET
  R
:KFKEY
  KQPOP C $kfa T
  $fg F @PPID A F $kfp T
  $kfp F %TR2 $kfa F + F PPUT3 C $kfp F %TR3 $kfa F 2 A F PPUT3 C $kfp F %TR4 $kfa F 3 A F PPUT3 C
  1 $kfa F F $fg F TTYRES C
  %SREADY $fg F @PST A T R
:KFGETC
  KQPOP C F $fg F @PPID A F SWAP PPUSH C %SREADY $fg F @PST A T R

:ECHOPREP                  # make sure the foreground's line is on screen before echoing
  $fg F FRESH C
  $conown F %NONE = EPRET *
  REDRAW C
:EPRET
  $fg F $conown T R
:FGRAW                     # ( -- flag)
  $fg F %NONE E FGRNO *
  $fg F @PFL A F 2 P R
:FGRNO
  0 R
:TERMRESET                 # leave a full-screen program's screen modes
  27 OBC C @"[0m" OBS C 27 OBC C @"[?1002l" OBS C 27 OBC C @"[?1006l" OBS C
  27 OBC C @"[?25h" OBS C 27 OBC C @"[?1049l" OBS C R

:KEYPOLL                   # (timeout ms; -1 = just look --)  read one key
  OBFLUSH C
  %KA1 T 13 %KCMD T
  %KST F KPNONE J
  %KR1 F $key T
  $key F 3 E KPINTR *
  FGRAW C KPRAW *
  $lbready F KPAHEAD *
  $tan F KPAHEAD *           # keys already queued go first
  NOWAITER C KPAHEAD *       # echo only when someone reads: typed-ahead text waits for the prompt
:KPEDIT                    # (from the type-ahead queue too)
  $key F 4 E KPEOT *
  $key F 10 E KPENTER *
  $key F 8 E KPBS *
  $key F 32 L KPRET *
  $key F 126 G KPRET *
  $lbn F 250 / KPRET *
  ECHOPREP C
  $key F $lbn F @LB A T $lbn PSTO $key F OBC C OBFLUSH B
:KPRET
  R
:KPAHEAD                   # a line is still waiting: keep the key for later
  $tan F 255 / KPRET *
  $key F $tah F $tan F A 255 P @TA A T $tan PSTO R
:TAPUMP                    # the waiting line was taken: edit the keys typed meanwhile
  $tan F TPRET J
  $lbready F TPRET *
  FGRAW C TPRET *
  NOWAITER C TPRET *
  $tah F @TA A F $key T $tah F + 255 P $tah T $tan F - $tan T
  KPEDIT C TAPUMP B
:TPRET
  R
:KPRAW
  $key F %KR2 F %KR3 F %KR4 F KQADD C KEYSTOFG B
:KPENTER
  $lbready F KPRET *
  ECHOPREP C 10 OBC C OBFLUSH C %NONE $conown T
  $fg F %NONE E KPEN2 *
  0 $fg F @PLN A T
:KPEN2
  10 $lbn F @LB A T $lbn PSTO 1 $lbready T
  WAKE B
:KPBS
  $lbready F KPRET *
  $lbn F KPRET J
  ECHOPREP C
  $lbn F - $lbn T 8 OBC C 32 OBC C 8 OBC C OBFLUSH B
:KPEOT                     # Ctrl+D on an empty line: end of input, once
  $lbn F $lbready F O KPRET *
  1 $lbeof T WAKE B
:KPINTR                    # Ctrl+C
  FGRAW C KPINR *
  ECHOPREP C
:KPINR
  @"^C" OBS C 10 OBC C %NONE $conown T LBRESET C 0 $kqn T 0 $tan T
  $fg F %NONE E KPICAN *
  $fg F @PFL A F 4 P KPICAN *
  FGRAW C KPINOT *
  TERMRESET C
:KPINOT
  $fg F @PPAR A F $kpp T 0 $kpi T
:KPILP                     # the foreground job: it and its foreground brothers
  $kpi F %NP / KPIEND *
  $kpi F @PPAR A F $kpp F = KPINX *
  $kpi F @PFL A F 1 P KPINX *
  130 $kpi F KILLSLOT C
:KPINX
  $kpi PSTO KPILP B
:KPIEND
  OBFLUSH B
:KPICAN                    # a shell at its prompt: an empty line
  $fg F %NONE E KPIRET *
  0 $fg F @PLN A T
  10 @LB T 1 $lbn T 1 $lbready T WAKE C
:KPIRET
  OBFLUSH B
:KPNONE
  %KR1 F 1 E KPEOF *
  R
:KPEOF
  $eof F KPRET *
  1 $eof T
  WAKE C 0 $kei T
:KPEOFLP                   # full-screen programs waiting for a key: end of input
  $kei F %NP / KPRET *
  $kei F @PST A F %SKEY = KPEONX *
  0 1 $kei F TTYRES C %SREADY $kei F @PST A T
:KPEONX
  $kei PSTO KPEOFLP B

# ---------------------------------------------------------------------
#  system calls (fs window, numbers 100+) and the tty bridge
# ---------------------------------------------------------------------
:SARG                      # (cell -- value)  an argument cell of the current process
  $cp F SWAP PGET2 B
:SYSCALL                   # (number --)  for slot $cs
  $scn T
  $scn F 100 E SC100 *
  $scn F 101 E SC101 *
  $scn F 102 E SC102 *
  $scn F 103 E SC103 *
  $scn F 104 E SC104 *
  $scn F 105 E SC105 *
  $scn F 106 E SC106 *
  $scn F 107 E SC107 *
  $scn F 108 E SC108 *
  $scn F 109 E SC109 *
  $scn F 110 E SC110 *
  $scn F 111 E SC111 *
  $scn F 112 E SC112 *
  $scn F 29 L SCFS *
  0 38 $cs F SYSRES B
:SCFS                      # 1-28: the fs bridge, answered from GenomeFS
  $scn F FSCALL B
:SC100
  $cs F SPAWNSYS B
:SC101                     # wait(pid)
  4129 SARG C D $wtp T SLOTOF C $wts T
  $wts F %NONE E SCECHILD *
  $wts F @PPAR A F $cp F = SCECHILD *
  $wts F @PST A F %SZOMB E SC101Z *
  $wtp F $cs F @PWT A T %SWAIT $cs F @PST A T R
:SC101Z
  1 $wts F @PWT A F $cs F SYSRES C 0 $wts F @PST A T R
:SCECHILD
  0 10 $cs F SYSRES B
:SC102
  $cs F @PPAR A F $cs F SYSRES2 C 1 $cp F $cs F SYSRES B
:SC103                     # pinfo(slot, namebuf)
  4129 SARG C $pis T
  $pis F %NP / SCPEND *
  $pis F @PST A F SC103F J
  $pis F @PPID A F %KA1 T 18 %KCMD T
  $cp F %FR4 %KR2 F PPUT3 C
  $cp F %FR3 $pis F @PPAR A F PPUT3 C
  $pis F @PST A F $cs F SYSRES2 C
  4130 SARG C $pib T
  $pis F 64 M @PNM A %KA1 T $cp F %KA2 T $pib F %KA3 T 64 %KA4 T 8 %KCMD T
  1 $pis F @PPID A F $cs F SYSRES B
:SC103F
  0 $cs F SYSRES2 C 1 0 $cs F SYSRES B
:SCPEND
  0 0 $cs F SYSRES B
:SC104                     # kill(pid)
  4129 SARG C D $kp T SLOTOF C $kps T
  $kps F %NONE E SCESRCH *
  $kp F 1 E SCEPERM *
  $kps F $fg F E FGRAW C P SC104N J
  TERMRESET C
:SC104N
  137 $kps F KILLSLOT C 1 0 $cs F SYSRES B
:SCESRCH
  0 3 $cs F SYSRES B
:SCEPERM
  0 1 $cs F SYSRES B
:SC105                     # sleep(ms)
  1 0 $cs F SYSRES C
  4129 SARG C 0 MAX TICKS C A + $cs F @PWT A T %SSLEEP $cs F @PST A T R
:SC106                     # getargs(buf, max)
  $cs F 80 M @PARG A $gaa T 0 $gan T
:SC106L
  $gaa F $gan F A F SC106E J
  $gan PSTO SC106L B
:SC106E
  $gan F 4130 SARG C - 0 MAX MIN $gan T
  0 $gan F $gaa F A T
  4129 SARG C $gab T
  $gaa F %KA1 T $cp F %KA2 T $gab F %KA3 T $gan F + %KA4 T 8 %KCMD T
  1 $gan F $cs F SYSRES B
:SC107
  $cp F %FR2 2 PPUT3 C TICKS C $cp F %FR3 ROT PPUT3 C
  LIVE C $cp F %FR4 ROT PPUT3 C
  1 %GOSMAGIC $cs F SYSRES B
:SC108
  0 38 $cs F SYSRES B
:SC109
  KMSG C @"[kernel] power off" OBS C KMSGEND C
  4129 SARG C %KA1 T 19 %KCMD T H
:SC110
  QNEW C D SC110F J
  1 SWAP $cs F SYSRES B
:SC110F
  ! 0 24 $cs F SYSRES B
:SC111
  4129 SARG C D 1 L SC111X * D %NQ G SC111X *
  QFREEMAYBE C 1 0 $cs F SYSRES B
:SC111X
  ! 0 22 $cs F SYSRES B
:SC112                     # setmode(1: Ctrl+C gives an empty line instead of stopping it)
  $cs F @PFL A F 4 INV P 4129 SARG C 1 P 4 M O $cs F @PFL A T
  1 0 $cs F SYSRES B

:TTYCALL                   # (command --)  the tty bridge for slot $cs
  $tcn T
  $tcn F 1 E TC1 *
  $tcn F 2 E TC2 *
  $tcn F 3 E TC3 *
  $tcn F 4 E TC4 *
  $tcn F 5 E TC5 *
  $tcn F 6 E TC6 *
  0 22 $cs F TTYRES B
:TC1                       # raw(on): a full-screen program
  $cs F @PFL A F 2 INV P 4145 SARG C BOOL 2 M O $cs F @PFL A T
  %NONE $conown T 0 $kqn T
  1 0 $cs F TTYRES B
:TC2                       # key(timeout ms)
  $cs F $fg F = TC2WAIT *
  $kqn F TC2WAIT J
  %SKEY $cs F @PST A T KEYSTOFG B
:TC2WAIT
  $eof F TC2EOF *
  4145 SARG C D TC2FOREVER J
  TICKS C A
:TC2FOREVER
  $cs F @PWT A T %SKEY $cs F @PST A T R
:TC2EOF
  0 1 $cs F TTYRES B
:TC3                       # write(addr, n)
  OBFLUSH C
  4146 SARG C 0 MAX 65536 MIN $twn T
  4145 SARG C $twa T
  $cp F %KA1 T $twa F %KA2 T %KBUF %KA3 T $twn F %KA4 T 7 %KCMD T
  %KST F TC3BAD J
  %KBUF %KA1 T $twn F %KA2 T 12 %KCMD T
  %NONE $conown T
  1 0 $cs F TTYRES B
:TC3BAD
  0 14 $cs F TTYRES B
:TC4
  14 %KCMD T %KR1 F $tsc T %KR2 F $tsr T
  $cp F %TR2 $tsr F PPUT3 C 1 $tsc F $cs F TTYRES B
:TC5                       # sleep(ms)
  1 0 $cs F TTYRES C
  4145 SARG C 0 MAX TICKS C A + $cs F @PWT A T %SSLEEP $cs F @PST A T R
:TC6
  1 TICKS C $cs F TTYRES B

# ---------------------------------------------------------------------
#  one time slice
# ---------------------------------------------------------------------
:SLICE                     # (slot --)
  $cs T $cs F @PPID A F $cp T %QUANTUM $ql T
:SLLP
  $cp F %KA1 T $ql F %KA2 T 1 %KCMD T
  %KST F SLLOST J
  $ql F %KR4 F S $ql T
  %KR1 F $ev T
  $ev F 1 E SLEND *
  $ev F 3 E EVPUTC *
  $ev F 4 E EVPUTN *
  $ev F 5 E EVCR *
  $ev F 2 E EVEXIT *
  $ev F 6 E EVGETC *
  $ev F 7 E EVIN *
  $ev F 8 E EVDEV *
  $ev F 9 E EVFAULT *
  $ev F 10 E EVPUTS *
  SLEND B
:SLNEXT
  $cs F @PST A F %SREADY = SLEND *
  $ql F 0 G SLLP *
:SLEND                     # bytes still queued for a pipe go now
  $cs F @PST A F %SREADY = SLRET *
  $cs F @PPN A F SLRET J
  $cs F PIPEFLUSH C SLRET *
  $cs F @PST A F %SREADY = SLRET *
  %SPPUT $cs F @PST A T
:SLRET
  R
:SLLOST
  139 $cs F KILLSLOT C R
:EVPUTS                    # output the machine collected: up to 512 bytes
  $cp F %KA1 T %KOUTB %KA2 T 26 %KCMD T %KR1 F $pon T
  $cs F @PERR A F EVPCON *
  $cs F @PRED A F EVPFILE *
  $cs F @POUT A F EVPCON J
  %KOUTB %KA1 T $cs F 4224 M %PPBK A $cs F @PPN A F A %KA2 T $pon F %KA3 T 20 %KCMD T
  $cs F @PPN A F $pon F A $cs F @PPN A T
  $cs F OUTCHECK C SLNEXT * R
:EVPCON
  0 $poi T
:EVPCL
  $poi F $pon F / SLNEXT *
  %KOUTB $poi F A F $cs F CONOUT C $poi PSTO EVPCL B
:EVPFILE
  0 $poi T
:EVPFL
  $poi F $pon F / SLNEXT *
  %KOUTB $poi F A F $cs F @PRED A F - FWB C $poi PSTO EVPFL B
:EVPUTC
  %KR2 F $cs F OUTBYTE C SLNEXT * R
:EVPUTN
  %KR2 F $cs F OUTNUM C SLNEXT * R
:EVCR
  10 $cs F OUTBYTE C SLNEXT * R
:EVEXIT
  %KR2 F $exc T
  $cs F @PPN A F EVEXGO J
  $cs F PIPEFLUSH C EVEXGO *
  $cs F @PST A F %SDYING E SLRET *
  $exc F $cs F @PWT A T $cs F @PFL A F 8 O $cs F @PFL A T %SPPUT $cs F @PST A T R
:EVEXGO
  $exc F $cs F KILLSLOT C R
:EVGETC
  $cs F @PIN A F D EVGCON J
  $gq T
  $gq F - @QCNT A F EVGQEMPTY J
  $cp F $gq F QGET C PPUSH C $cp F $gq F QFEED C SLNEXT B
:EVGQEMPTY
  $gq F QEOF C EVGQEOF *
  %SPGETC $cs F @PST A T R
:EVGQEOF
  $cp F 0 1 S PPUSH C SLNEXT B
:EVGCON
  !
  $cs F @PFL A F 1 P EVGQEOF *
  $cs F @PFL A F 2 P EVGRAW *
  HAVEINPUT C EVGNOW *
  %SCGETC $cs F @PST A T R
:EVGNOW
  $cp F NEXTCH C PPUSH C $cp F LBFEED C SLNEXT B
:EVGRAW
  %SCGETC $cs F @PST A T
  $cs F $fg F = EVGRRET *
  KEYSTOFG C
:EVGRRET
  $cs F @PST A F %SREADY E SLNEXT * R
:EVIN
  $cs F @PIN A F D EVICON J
  $gq T
  $gq F QHASNL C $gq F QEOF C O EVIQNOW *
  %SPIN $cs F @PST A T R
:EVIQNOW
  $cp F $gq F QLINENUM C PPUSH C SLNEXT B
:EVICON
  !
  $cs F @PFL A F 1 P EVGQEOF *
  HAVEINPUT C EVINOW *
  %SCIN $cs F @PST A T R
:EVINOW
  $cp F LINENUM C PPUSH C SLNEXT B
:EVDEV
  %KR2 F 4128 E EVFS *
  %KR2 F 4144 E EVTTY *
  $cp F 4117 0 PPUT3 C $cp F 4118 38 PPUT3 C SLNEXT B
:EVFS
  %KR3 F SYSCALL C SLNEXT B
:EVTTY
  %KR3 F TTYCALL C SLNEXT B
:EVFAULT
  KMSG C $cs F PNAMEOUT C @" crashed: " OBS C
  %KR2 F 1 E EVFPC *
  @"internal error" OBS C EVFEND B
:EVFPC
  @"jumped outside its code (pc " OBS C %KR3 F OBN C 41 OBC C
:EVFEND
  KMSGEND C 139 $cs F KILLSLOT C R

# ---------------------------------------------------------------------
#  scheduler
# ---------------------------------------------------------------------
:LIVE                      # ( -- processes that have not stopped)
  0 0 $lvi T
:LVLP
  $lvi F %NP / LVRET *
  $lvi F @PST A F D %SFREE = SWAP %SZOMB = P A
  $lvi PSTO LVLP B
:LVRET
  R
:TIMERS                    # wake sleepers and key waits whose time has come; $next = soonest
  TICKS C $now T 0 $next T 0 $tmi T
:TMLP
  $tmi F %NP / TMRET *
  $tmi F @PST A F %SSLEEP E $tmi F @PST A F %SKEY E O TMNX J
  $tmi F @PWT A F D TMNX0 J
  $now F G TMLATER *
  $tmi F @PST A F %SKEY E TMKEY J
  0 0 $tmi F TTYRES C
:TMKEY
  %SREADY $tmi F @PST A T TMNX B
:TMLATER
  $tmi F @PWT A F $next F D TMFIRST J
  MIN $next T TMNX B
:TMFIRST
  ! $next T TMNX B
:TMNX0
  !
:TMNX
  $tmi PSTO TMLP B
:TMRET
  R

:SCHED
  TAPUMP C REAP C PUMP C REAP C
  LIVE C ALLDONE J
  TIMERS C
  0 $ran T 0 $s T
:ROUNDLP
  $s F %NP / ROUNDEND *
  $s F @PST A F %SREADY = RNEXT *
  1 $ran T $s F SLICE C
:RNEXT
  $s PSTO ROUNDLP B
:ROUNDEND
  REAP C PUMP C
  $ran F IDLE J
  0 1 S KEYPOLL C SCHED B
:IDLE
  REAP C LIVE C ALLDONE J
  $ran F SCHED *
  0 $s T
:IDREADY                   # did the pipes make someone ready?
  $s F %NP / IDWAIT *
  $s F @PST A F %SREADY E SCHED *
  $s PSTO IDREADY B
:IDWAIT
  TIMERS C
  $next F D IDFOREVER J
  TICKS C S 1 MAX 1000 MIN
  $eof F IDSLEEP *
  $tan F IDTA *
  KEYPOLL C SCHED B
:IDTA
  ! SCHED B
:IDSLEEP
  %KA1 T 17 %KCMD T SCHED B
:IDFOREVER
  ! $eof F $tan F N P STUCK *
  0 KEYPOLL C SCHED B
:STUCK
  KMSG C @"[kernel] end of input and every program is waiting - power off" OBS C KMSGEND C
  0 %KA1 T 19 %KCMD T H
:ALLDONE
  KMSG C @"[kernel] all programs have finished - power off" OBS C KMSGEND C
  0 %KA1 T 19 %KCMD T H

# ---------------------------------------------------------------------
#  boot
# ---------------------------------------------------------------------
:MAIN
  %KMAGIC F %GOSMAGIC E KOK *
  "kernel.aa is the GenomeOS kernel: boot it with  python3 GATCnux.py boot genome.img" CR 1 Q
:KOK
  0 $obn T LBRESET C 0 $lbeof T 0 $eof T 0 $kqn T 0 $kqh T 0 $tan T 0 $tah T %NONE $fg T %NONE $conown T
  0 $ptag T 0 $dltag T 0 $brover T
  1 %KA1 T 15 %KCMD T
  27 OBC C @"[1;32m" OBS C @"GenomeOS" OBS C 27 OBC C @"[0m" OBS C
  @"  kernel 2 - a GATC operating system with GenomeFS" OBS C 10 OBC C OBFLUSH C
  0 @SB DREAD1 C
  @SB F 'G' = BADDISK * @SB 7 A F 'S' = BADDISK *
  @SB 8 A LE32 C 2 L OLDDISK *
  @SB 16 A LE32 C $total T @SB 28 A LE32 C $mstart T @SB 32 A LE32 C $mblocks T
  @SB 36 A LE32 C $istart T @SB 40 A LE32 C $icount T @SB 44 A LE32 C $iblocks T
  @SB 48 A LE32 C $dstart T
  $mstart F %KA1 T $mblocks F %KA2 T %BMAPK %KA3 T 9 %KCMD T
  $istart F %KA1 T $iblocks F %KA2 T %INODEK %KA3 T 9 %KCMD T
  %ZEROK 512 KZERO C
  0 $nfree T $dstart F $bb T
:CNTFREE                   # count the free blocks once
  $bb F $total F / CNTDONE *
  $bb F %BMAPK A F CNTUSED *
  $nfree PSTO
:CNTUSED
  $bb PSTO CNTFREE B
:CNTDONE
  @"disk " OBS C $total F 2 V OBN C @" KiB, " OBS C $nfree F 2 V OBN C @" KiB free" OBS C 10 OBC C
  @"/bin/init" @CP STRCPY C @CP NAMEI C D NOINIT J
  NEWPROC C D %NONE E NOINIT2 *
  $fg T 1 $hasinit T
  OBFLUSH C SCHED B
:NOINIT2
  !
:NOINIT
  ! @"[kernel] cannot start /bin/init" OBS C 10 OBC C OBFLUSH C
  1 %KA1 T 19 %KCMD T H
:OLDDISK
  @"[kernel] this disk has no file system (made for kernel 0/1): rebuild it with mkimage" OBS C 10 OBC C OBFLUSH C
  1 %KA1 T 19 %KCMD T H
:BADDISK
  @"[kernel] the disk has no GenomeOS superblock" OBS C 10 OBC C OBFLUSH C
  1 %KA1 T 19 %KCMD T H
