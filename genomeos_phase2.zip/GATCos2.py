#!/usr/bin/env python3
"""HolyGATC / GATC64 version 4.0.0 + file load support
64 opcodes, one per codon. Real FASTA runs anyway.
Packed DNA: ATG + 16-bit big-endian length + payload + TAA.
"""
from __future__ import annotations
import argparse, random, sys
from dataclasses import dataclass
from typing import Optional
import os, zlib, collections, io
import socket, ssl, struct, time, ipaddress, re
VERSION = "4.6.0-genomeos"
BANNER = r"""
  ____    _  _____ ____  __ _  _
 / ___|  / \|_   _/ ___|/ /| || |
| |  _  / _ \ | || |   / / | || |_
| |_| |/ ___ \| || |__/ /  |__   _|
 \____/_/   \_\_| \____/      |_|
  64 opcodes. 64 codons. One each.
  Version 4 + --load/--file/--net/--fs. Real FASTA runs anyway.
"""
OPDEF = [
 ("A","ADD",0x01,False,"(a b -- a+b)"),("B","JMP",0x02,False,"(addr --)"),
 ("C","CALL",0x03,False,"(addr --)"),("D","DUP",0x04,False,"(a -- a a)"),
 ("E","EQ",0x05,False,"(a b -- flag)"),("F","FETCH",0x06,False,"(addr -- val)"),
 ("G","GT",0x07,False,"(a b -- flag)"),("H","HALT",0x08,False,"(--)"),
 ("I","IN",0x09,False,"(-- n)"),("J","JZ",0x0A,False,"(flag addr --)"),
 ("K","LIT",0x0B,True,"(-- n)"),("L","LT",0x0C,False,"(a b -- flag)"),
 ("M","MUL",0x0D,False,"(a b -- a*b)"),("N","NOT",0x0E,False,"(a -- flag)"),
 ("O","OR",0x0F,False,"(a b -- a|b)"),("P","AND",0x10,False,"(a b -- a&b)"),
 ("Q","QUIT",0x11,False,"(code --)"),("R","RET",0x12,False,"(--)"),
 ("S","SUB",0x13,False,"(a b -- a-b)"),("T","STORE",0x14,False,"(val addr --)"),
 ("U","OVER",0x15,False,"(a b -- a b a)"),("V","DIV",0x16,False,"(a b -- a/b)"),
 ("W","PUTC",0x17,False,"(n --)"),("X","XOR",0x18,False,"(a b -- a^b)"),
 ("Y","PUTN",0x19,False,"(n --)"),("Z","SWAP",0x1A,False,"(a b -- b a)"),
 ("_","NOP",0x1B,False,"(--)"),("%","MOD",0x1C,False,"(a b -- a%b)"),
 ("~","NEG",0x1D,False,"(a -- -a)"),("!","DROP",0x1E,False,"(a --)"),
 ("?","GETC",0x1F,False,"(-- n)"),("<","SHL",0x20,False,"(a b -- a<<b)"),
 (">","SHR",0x21,False,"(a b -- a>>b)"),("$","RAND",0x22,False,"(n -- r)"),
 ("+","INC",0x23,False,"(a -- a+1)"),("-","DEC",0x24,False,"(a -- a-1)"),
 ("*","JNZ",0x25,False,"(flag addr --)"),("@","ROT",0x26,False,"(a b c -- b c a)"),
 ("&","NIP",0x27,False,"(a b -- b)"),("=","NE",0x28,False,"(a b -- flag)"),
 ("/","GE",0x29,False,"(a b -- flag)"),("^","LE",0x2A,False,"(a b -- flag)"),
 ("|","MAX",0x2B,False,"(a b -- max)"),(";","MIN",0x2C,False,"(a b -- min)"),
 (".","ABS",0x2D,False,"(a -- |a|)"),(",","DEPTH",0x2E,False,"(-- n)"),
 ("`","TUCK",0x2F,False,"(a b -- b a b)"),("'","PICK",0x30,False,"(n -- x)"),
 ("[","DDUP",0x31,False,"(a b -- a b a b)"),("]","DDROP",0x32,False,"(a b --)"),
 ("{","TOR",0x33,False,"(a --)"),("}","RFROM",0x34,False,"(-- a)"),
 ("\\","INV",0x35,False,"(a -- ~a)"),("(","ZERO",0x36,False,"(-- 0)"),
 (")","ONE",0x37,False,"(-- 1)"),("CR","CR",0x38,False,"(--) newline"),
 ("TSWP","TSWP",0x39,False,"(a b c d -- c d a b)"),("BOOL","BOOL",0x3A,False,"(a -- 0|1)"),
 ("PSTO","PSTO",0x3B,False,"(addr --) mem++"),("UNDER","UNDER",0x3C,False,"(a b -- a a b)"),
 ("RDROP","RDROP",0x3D,False,"(R: a --)"),("NROLL","NROLL",0x3E,False,"(a b c -- c a b)"),
 ("SIGN","SIGN",0x3F,False,"(a -- -1|0|1)"),("MADD","MADD",0x40,False,"(n addr --)"),
]
LETTER_TO_OP={s:n for s,n,*_ in OPDEF if len(s)==1}
NAME_TO_BYTE={n:b for _,n,b,*_ in OPDEF}
BYTE_TO_NAME={b:n for _,n,b,*_ in OPDEF}
BYTE_HAS_IMM={b:i for _,_,b,i,*_ in OPDEF}
LETTER_HAS_IMM={s:i for s,_,_,i,*_ in OPDEF if len(s)==1}
NAME_HAS_IMM={n:i for _,n,_,i,*_ in OPDEF}
ALIASES={n:n for _,n,*_ in OPDEF}
ALIASES.update({"PUSH":"LIT","PRINT":"PUTN","EMIT":"PUTC","LOAD":"FETCH","2DUP":"DDUP","2DROP":"DDROP",">R":"TOR","R>":"RFROM","2SWAP":"TSWP","INVERT":"INV"})
CODON_TO_OP={
"TTT":"FETCH","TTC":"LT","TTA":"JMP","TTG":"GT","TCT":"SUB","TCC":"IN","TCA":"JZ","TCG":"PUTC",
"TAT":"PUTN","TAC":"QUIT","TAA":"HALT","TAG":"NOP","TGT":"CALL","TGC":"RET","TGA":"OR","TGG":"AND",
"CTT":"STORE","CTC":"OVER","CTA":"XOR","CTG":"SWAP","CCT":"MOD","CCC":"NEG","CCA":"DROP","CCG":"GETC",
"CAT":"SHL","CAC":"SHR","CAA":"RAND","CAG":"INC","CGT":"DEC","CGC":"JNZ","CGA":"ROT","CGG":"NIP",
"ATT":"NE","ATC":"GE","ATA":"LE","ATG":"MUL","ACT":"MAX","ACC":"MIN","ACA":"ABS","ACG":"DEPTH",
"AAT":"NOT","AAC":"EQ","AAA":"LIT","AAG":"ADD","AGT":"DUP","AGC":"DIV","AGA":"TUCK","AGG":"PICK",
"GTT":"DDUP","GTC":"DDROP","GTA":"TOR","GTG":"RFROM","GCT":"INV","GCC":"ZERO","GCA":"ONE","GCG":"CR",
"GAT":"TSWP","GAC":"BOOL","GAA":"PSTO","GAG":"UNDER","GGT":"RDROP","GGC":"NROLL","GGA":"SIGN","GGG":"MADD"}
MEM_SIZE,STACK_LIMIT,CALL_LIMIT,STEP_LIMIT_DEFAULT=65536,65536,4096,5_000_000
# Memory: cells 0..4095 and 4160..65535 are ordinary RAM (65,472 cells).  4096..4159 is the device
# window (editor, net, fs and tty control cells), so programs written for the old 4096-cell VM keep
# every address.  65536.. is the file-backed byte space (FILE_BASE).
HOLE_LO,HOLE_HI=4096,4160
def mem_ok(addr, n, size=MEM_SIZE):
    "True if cells addr..addr+n-1 are all RAM (no device window, nothing past the end)"
    return 0 <= addr and n >= 0 and addr + n <= size and (addr + n <= HOLE_LO or addr >= HOLE_HI)
def ram(addr, size=MEM_SIZE):
    return 0 <= addr < size and not (HOLE_LO <= addr < HOLE_HI)
# --- file-backed address space (used by hexeditor.aa) -----------------------------------
# FETCH/STORE at FILE_BASE+n read/write byte n of the file given with --file (up to 1 GiB).
# Cells 4096.. are control cells.  STORE a command number into CTL_CMD to run a bulk operation
# in the host (fast); arguments go in CTL_A1/A2/A3, results come back in CTL_R1/R2/R3.
FILE_BASE=65536
MAX_FILE=1<<30                 # 1 GiB editing limit
GROW_CAP=1<<28                 # largest single insert (256 MiB)
UNDO_CAP=1<<28                 # undo history budget (about 256 MiB)
CHUNK=1<<24
CTL_CMD,CTL_A1,CTL_A2,CTL_SIZE,CTL_DIRTY,CTL_MAGIC,CTL_STATUS,CTL_R1,CTL_R2,CTL_R3,CTL_A3,CTL_LOST=range(4096,4108)
# commands: 1 save  2 insert zeros(A1=off,A2=n)  3 delete(A1,A2)  4 find(A1=start,A2=len,A3=mem addr of pattern)
#           5 checksum(A1,A2 -> R1 sum8,R2 xor8,R3 crc32)  6 undo  7 begin undo group
#           8 fill(A1,A2,A3=value)  9 copy(A1=src,A2=len,A3=dst)  10 xor(A1,A2,A3=key)  11 set size(A1)
#           12 checkpoint(A1=off,A2=len): new undo step that keeps one copy of that range, and plain
#              stores inside it are not logged byte by byte until the next 7/12 (paint's canvas)
#           13 redo (after 6)   14 forget all undo/redo history and stop logging until the next 7/12
BITS={"A":0,"C":1,"G":2,"T":3}; BASE="ACGT"
class GATCError(Exception): pass
_seen=set()
def warn(msg):
    key=msg.split(";")[0][:48]
    if key in _seen: return
    _seen.add(key); print("error: "+msg, file=sys.stderr)
@dataclass
class Token:
    kind:str; value:object; line:int; col:int
@dataclass
class Instr:
    name:str; imm:Optional[int]=None; imm_label:Optional[str]=None; line:int=0
def tokenize_aa(src):
    tokens,i,n,line,col=[],0,len(src),1,1
    def peek(k=1):
        j=i+k; return src[j] if j<n else ""
    while i<n:
        ch=src[i]
        if ch in " \t\r":
            i+=1; col+=1; continue
        if ch=="\n":
            i+=1; line+=1; col=1; continue
        if ch=="#":
            while i<n and src[i]!="\n": i+=1; col+=1
            continue
        if ch=='"':
            start=col; i+=1; col+=1; buf=[]
            while i<n and src[i]!='"':
                if src[i]=="\\" and i+1<n:
                    buf.append({"n":"\n","t":"\t","r":"\r","\\":"\\",'"':'"'}.get(src[i+1],src[i+1])); i+=2; col+=2; continue
                if src[i]=="\n": raise GATCError(f"line {line}: unterminated string")
                buf.append(src[i]); i+=1; col+=1
            if i>=n or src[i]!='"': raise GATCError("unterminated string")
            i+=1; col+=1; tokens.append(Token("STR","".join(buf),line,start)); continue
        if ch==":":
            start=col; i+=1; col+=1; name=[]
            while i<n and (src[i].isalnum() or src[i]=="_"): name.append(src[i]); i+=1; col+=1
            if not name: raise GATCError("empty label")
            tokens.append(Token("LABEL","".join(name).upper(),line,start)); continue
        if ch.isdigit() or (ch=="-" and peek(1).isdigit()):
            start,sign=col,1
            if ch=="-": sign=-1; i+=1; col+=1
            if i<n and src[i]=="0" and peek(1) in "xX":
                i+=2; col+=2; d=[]
                while i<n and src[i] in "0123456789abcdefABCDEF": d.append(src[i]); i+=1; col+=1
                num=sign*int("".join(d),16)
            else:
                d=[]
                while i<n and src[i].isdigit(): d.append(src[i]); i+=1; col+=1
                num=sign*int("".join(d) or "0",10)
            tokens.append(Token("NUM",num,line,start)); continue
        if ch.isalpha() or ch in LETTER_TO_OP:
            start=col
            if ch in LETTER_TO_OP and not (peek(1).isalnum() or peek(1)=="_"):
                tokens.append(Token("OP", ch.upper() if ch.isalpha() else ch, line, start)); i+=1; col+=1; continue
            w=[]
            while i<n and (src[i].isalnum() or src[i]=="_"): w.append(src[i]); i+=1; col+=1
            word="".join(w); wu=word.upper()
            if len(word)==1 and (word.upper() if word.isalpha() else word) in LETTER_TO_OP:
                tokens.append(Token("OP", word.upper() if word.isalpha() else word, line, start))
            elif wu in ALIASES: tokens.append(Token("NAME", ALIASES[wu], line, start))
            else: tokens.append(Token("IDENT", wu, line, start))
            continue
        raise GATCError(f"line {line}:{col}: unexpected {ch!r}")
    return tokens
def assemble_tokens(tokens):
    program,labels,i=[],{},0
    while i<len(tokens):
        tok=tokens[i]
        if tok.kind=="LABEL":
            if tok.value in labels: raise GATCError(f"duplicate :{tok.value}")
            labels[str(tok.value)]=len(program); i+=1; continue
        if tok.kind=="STR":
            for ch in str(tok.value):
                program += [Instr("LIT",imm=ord(ch),line=tok.line), Instr("PUTC",line=tok.line)]
            i+=1; continue
        if tok.kind=="NUM":
            program.append(Instr("LIT",imm=int(tok.value),line=tok.line)); i+=1; continue
        if tok.kind=="IDENT":
            program.append(Instr("LIT",imm_label=str(tok.value),line=tok.line)); i+=1; continue
        if tok.kind in ("NAME","OP"):
            name = LETTER_TO_OP[str(tok.value)] if tok.kind=="OP" else str(tok.value)
            has = LETTER_HAS_IMM[str(tok.value)] if tok.kind=="OP" else NAME_HAS_IMM[name]
            imm=imm_label=None
            if has:
                if i+1>=len(tokens): raise GATCError(f"{name} needs an operand")
                nxt=tokens[i+1]
                if nxt.kind=="NUM": imm=int(nxt.value)
                elif nxt.kind=="IDENT": imm_label=str(nxt.value)
                else: raise GATCError(f"{name} needs number or label")
                i+=2
            else: i+=1
            program.append(Instr(name,imm=imm,imm_label=imm_label,line=tok.line)); continue
        raise GATCError(f"cannot assemble {tok}")
    return program, labels
def resolve(program, labels):
    out=[]
    for ins in program:
        if ins.imm_label is not None:
            if ins.imm_label not in labels: raise GATCError(f"unknown label :{ins.imm_label}")
            out.append(Instr(ins.name, imm=labels[ins.imm_label], line=ins.line))
        else: out.append(ins)
    return out
def encode_bytecode(program):
    buf=bytearray()
    for ins in program:
        b=NAME_TO_BYTE[ins.name]; buf.append(b)
        if BYTE_HAS_IMM[b]: buf.extend((int(ins.imm or 0)&0xFFFFFFFF).to_bytes(4,"little"))
    return bytes(buf)
def decode_bytecode(raw):
    if raw[:4]==b"GATC": raw=raw[4:]
    program,i=[],0
    while i<len(raw):
        b=raw[i]; i+=1
        name=BYTE_TO_NAME.get(b)
        if name is None:
            warn(f"unknown opcode byte 0x{b:02X}; NOP"); program.append(Instr("NOP")); continue
        imm=None
        if BYTE_HAS_IMM[b]:
            if i+4>len(raw): warn("LIT truncated; pushing 0"); imm=0; i=len(raw)
            else: imm=int.from_bytes(raw[i:i+4],"little"); i+=4
        program.append(Instr(name, imm=imm))
    return program
def strip_to_bases(text):
    kept=[ln for ln in text.splitlines() if not ln.startswith(">")]
    blob="\n".join(kept) if kept else text
    return "".join(ch for ch in blob.upper().replace("U","T") if ch in "ACGT")
def bytecode_to_dna(bc):
    # length header: 2 bytes; programs of 65535 bytes or more write FFFF + a 4-byte length
    # (smaller programs encode exactly as before, so existing genomes are unchanged)
    head=len(bc).to_bytes(2,"big") if len(bc)<0xFFFF else b"\xff\xff"+len(bc).to_bytes(4,"big")
    packet=head+bc
    bases=[]
    for byte in packet:
        bases += [BASE[(byte>>6)&3],BASE[(byte>>4)&3],BASE[(byte>>2)&3],BASE[byte&3]]
    return "ATG"+"".join(bases)+"TAA"
def dna_to_bytecode(text):
    bases=strip_to_bases(text)
    if bases.startswith("ATG"): bases=bases[3:]
    if bases.endswith("TAA"): bases=bases[:-3]
    if len(bases)%4:
        pad=4-len(bases)%4; warn(f"payload not multiple of 4; padding {pad} A"); bases+="A"*pad
    raw=bytearray()
    for i in range(0,len(bases),4):
        byte=0
        for ch in bases[i:i+4]: byte=(byte<<2)|BITS[ch]
        raw.append(byte)
    if len(raw)<2: warn("missing length; empty payload"); return b""
    ln=int.from_bytes(raw[:2],"big"); payload=bytes(raw[2:])
    if ln==0xFFFF and len(payload)!=0xFFFF and len(raw)>=6:      # extended length (large programs)
        ln=int.from_bytes(raw[2:6],"big"); payload=bytes(raw[6:])
    if ln!=len(payload): warn(f"length header {ln} but payload is {len(payload)}; ignoring length")
    return payload
def codon_value(c):
    return (BITS[c[0]]<<4)|(BITS[c[1]]<<2)|BITS[c[2]]
def compile_gene(text, force_start=True):
    bases=strip_to_bases(text)
    if force_start and not bases.startswith("ATG"):
        warn("no start codon; forcing ATG"); bases="ATG"+bases
    program,i,first=[],0,True
    while i+2<len(bases):
        codon=bases[i:i+3]; i+=3
        if first and codon=="ATG":
            first=False; continue
        first=False
        name=CODON_TO_OP.get(codon,"NOP")
        if name=="LIT":
            if i+2>=len(bases):
                warn("LIT missing immediate; pushing 0"); program.append(Instr("LIT",imm=0)); break
            imm=bases[i:i+3]; i+=3; program.append(Instr("LIT", imm=codon_value(imm)))
        else: program.append(Instr(name))
    if not program: program.append(Instr("HALT"))
    return program
def looks_packed(text):
    bases=strip_to_bases(text)
    if not (bases.startswith("ATG") and bases.endswith("TAA") and len(bases)>=11): return False
    body=bases[3:-3]
    if len(body)<8 or len(body)%4: return False
    raw=bytearray()
    for i in range(0,min(24,len(body)),4):
        byte=0
        for ch in body[i:i+4]: byte=(byte<<2)|BITS[ch]
        raw.append(byte)
    if int.from_bytes(raw[:2],"big")==(len(body)-8)//4: return True
    return len(raw)>=6 and raw[:2]==b"\xff\xff" and int.from_bytes(raw[2:6],"big")==(len(body)-24)//4
def compile_source(text, filename=""):
    lower=filename.lower()
    dna=lower.endswith((".dna",".gatc",".fa",".fasta",".fna"))
    if not dna:
        bases=strip_to_bases(text)
        letters=[c for c in text.upper() if c.isalpha()]
        if bases.startswith("ATG") and len(bases)>=12 and not [c for c in letters if c not in "ACGTU"]:
            dna=True
    if dna:
        if looks_packed(text): return decode_bytecode(dna_to_bytecode(text)), False
        warn("not a packed genome; running every codon")
        return compile_gene(text, force_start=True), True
    program, labels = assemble_tokens(tokenize_aa(text))
    return resolve(program, labels), False
def write_fasta(dna, header, width=60):
    lines=[">"+header]
    for i in range(0,len(dna),width): lines.append(dna[i:i+width])
    return "\n".join(lines)+"\n"
def translate_coding_sequence(text):
    bases=strip_to_bases(text); forced=False
    if not bases.startswith("ATG"): bases="ATG"+bases; forced=True
    out,i,first=[],0,True
    while i+2<len(bases):
        codon=bases[i:i+3]; i+=3
        if first and codon=="ATG":
            out.append("M"); first=False; continue
        first=False
        name=CODON_TO_OP.get(codon,"?")
        sym=next((s for s,n,*_ in OPDEF if n==name), name[:1])
        if name=="LIT" and i+2<len(bases):
            imm=bases[i:i+3]; i+=3; out.append(f"K{codon_value(imm)}")
        else: out.append(sym if len(sym)==1 else name)
    return ("FORCED " if forced else "")+" ".join(out)
def disasm(program):
    return "\n".join(f"{pc:04d}: {ins.name:<6} {ins.imm}" if ins.imm is not None else f"{pc:04d}: {ins.name}" for pc,ins in enumerate(program))
# ---------------------------------------------------------------------------------------
# networking for netkit.aa  (opt-in: run with --net)
#
# The VM has no network opcodes.  Like the file-backed editor, a program STOREs a command
# number into a control cell; the host does the work (DNS, whois, ICMP, TCP/TLS) and prints
# its output straight to stdout.  Strings are passed as the address of a NUL-terminated
# string in VM memory.  Everything has a timeout; nothing runs unless --net is given.
# ---------------------------------------------------------------------------------------
NET_MAGIC = 20037
CTL_NCMD, CTL_NA1, CTL_NA2, CTL_NA3, CTL_NA4, CTL_NSTATUS, CTL_NR1, CTL_NR2, CTL_NMAGIC = range(4112, 4121)
IANA_WHOIS = "whois.iana.org"
WHOIS_ALLOW_PRIVATE = False        # automatic whois referrals may only point at public hosts
MAX_PRINT = 256 * 1024
QTYPES = {"A": 1, "NS": 2, "CNAME": 5, "SOA": 6, "PTR": 12, "MX": 15, "TXT": 16, "AAAA": 28, "SRV": 33,
          "NAPTR": 35, "DS": 43, "DNSKEY": 48, "TLSA": 52, "CAA": 257, "ANY": 255}
QNAMES = {v: k for k, v in QTYPES.items()}
RCODES = ["NOERROR", "FORMERR", "SERVFAIL", "NXDOMAIN", "NOTIMP", "REFUSED", "YXDOMAIN", "YXRRSET",
          "NXRRSET", "NOTAUTH", "NOTZONE"]

def _esc_bytes(b):
    return "".join(chr(c) if 32 <= c < 127 and chr(c) not in '"\\' else "\\%03d" % c for c in b)

def _dns_encode_name(name):
    name = name.rstrip(".")
    if not name: return b"\0"
    out = b""
    for lab in name.split("."):
        if not lab: raise ValueError("empty label in name")
        try: b = lab.encode("ascii")
        except UnicodeEncodeError: b = lab.encode("idna")
        if len(b) > 63: raise ValueError("label longer than 63 bytes")
        out += bytes([len(b)]) + b
    if len(out) + 1 > 255: raise ValueError("name longer than 253 bytes")
    return out + b"\0"

def _dns_decode_name(msg, off):
    labels, end, hops = [], None, 0
    while True:
        if off >= len(msg): raise ValueError("truncated name")
        n = msg[off]
        if n == 0:
            off += 1; break
        if n & 0xC0 == 0xC0:
            if off + 1 >= len(msg): raise ValueError("truncated pointer")
            ptr = ((n & 0x3F) << 8) | msg[off + 1]
            if end is None: end = off + 2
            hops += 1
            if hops > 64 or ptr >= len(msg): raise ValueError("bad compression pointer")
            off = ptr; continue
        if n & 0xC0: raise ValueError("bad label type")
        off += 1
        if off + n > len(msg): raise ValueError("truncated label")
        labels.append(msg[off:off + n]); off += n
        if sum(len(l) + 1 for l in labels) > 255: raise ValueError("name too long")
    if end is None: end = off
    return ".".join(_esc_bytes(l).replace(".", "\\.") for l in labels) + ".", end

def _dns_rdata(msg, rtype, off, rdlen):
    end = off + rdlen; raw = msg[off:end]
    if rtype == 1 and rdlen == 4: return socket.inet_ntoa(raw)
    if rtype == 28 and rdlen == 16: return str(ipaddress.IPv6Address(raw))
    if rtype in (2, 5, 12): return _dns_decode_name(msg, off)[0]
    if rtype == 15 and rdlen >= 3:
        return "%d %s" % (struct.unpack(">H", raw[:2])[0], _dns_decode_name(msg, off + 2)[0])
    if rtype == 16:
        parts, i = [], 0
        while i < rdlen:
            n = raw[i]; parts.append('"' + _esc_bytes(raw[i + 1:i + 1 + n]) + '"'); i += 1 + n
        return " ".join(parts)
    if rtype == 6:
        m, o = _dns_decode_name(msg, off); r, o = _dns_decode_name(msg, o)
        return "%s %s %d %d %d %d %d" % ((m, r) + struct.unpack(">IIIII", msg[o:o + 20]))
    if rtype == 33 and rdlen >= 7:
        p, w, port = struct.unpack(">HHH", raw[:6]); return "%d %d %d %s" % (p, w, port, _dns_decode_name(msg, off + 6)[0])
    if rtype == 257 and rdlen >= 2:
        fl, tl = raw[0], raw[1]; return '%d %s "%s"' % (fl, _esc_bytes(raw[2:2 + tl]), _esc_bytes(raw[2 + tl:]))
    return "\\# %d %s" % (rdlen, raw.hex())

def _icmp_checksum(b):
    if len(b) % 2: b += b"\0"
    s = sum(struct.unpack(">%dH" % (len(b) // 2), b))
    s = (s >> 16) + (s & 0xFFFF); s += s >> 16
    return (~s) & 0xFFFF

class NetKit:
    def __init__(self, out, mem):
        self.out = out; self.mem = mem; self.sock = None

    # ------------------------------------------------------------ helpers
    def w(self, s):
        self.out.write(s); self.out.flush()
    @staticmethod
    def clean(text):
        """remote text is untrusted: no terminal escape sequences or other control characters"""
        return re.sub(r"[\x00-\x08\x0b-\x1f\x7f-\x9f]", ".", text.replace("\r", ""))
    def cs(self, addr, maxlen=255):
        if not ram(addr, len(self.mem)): return ""
        chars = []
        for i in range(maxlen):
            if not ram(addr + i, len(self.mem)): break
            v = self.mem[addr + i]
            if v == 0: break
            chars.append(chr(v) if 0 < v < 0x110000 else "?")
        return "".join(c for c in "".join(chars) if c.isprintable()).strip()
    @staticmethod
    def okhost(h):
        h = h.strip("[]")
        return 1 <= len(h) <= 253 and all(c.isalnum() or c in "._:%-" for c in h)
    @staticmethod
    def hostnorm(h):
        return h.strip("[]")
    def close(self):
        if self.sock is not None:
            try: self.sock.close()
            except OSError: pass
            self.sock = None

    def command(self, cmd, a1, a2, a3, a4):
        """returns (status, r1, r2)"""
        try:
            if cmd == 1: return self.c_resolve(self.cs(a1))
            if cmd == 2: return self.c_dig(self.cs(a1), self.cs(a2), self.cs(a3))
            if cmd == 3: return self.c_whois(self.cs(a1), self.cs(a2))
            if cmd == 4: return self.c_ping(self.cs(a1), a2, a3)
            if cmd == 5: return self.c_connect(self.cs(a1), a2, a3, a4)
            if cmd == 6: return self.c_send(a1, a2)
            if cmd == 7: return self.c_recv(a1, a2)
            if cmd == 8: self.close(); return (1, 0, 0)
            if cmd == 9: return self.c_listen(a1, a2, self.cs(a3))
            if cmd == 10: return self.c_http(self.cs(a1))
            if cmd == 11: return self.c_portcheck(self.cs(a1), a2, a3)
            if cmd == 12: return self.c_rdns(self.cs(a1), self.cs(a2))
            self.w("net: unknown command %s\n" % cmd); return (0, 0, 0)
        except KeyboardInterrupt:
            self.w("\n^C interrupted\n"); return (0, 0, 0)
        except Exception as e:
            self.w("error: %s: %s\n" % (type(e).__name__, e)); return (0, 0, 0)

    # ------------------------------------------------------------ resolve
    def c_resolve(self, name):
        if not self.okhost(name): self.w("error: that is not a valid host name\n"); return (0, 0, 0)
        name = self.hostnorm(name)
        try: infos = socket.getaddrinfo(name, None, 0, socket.SOCK_STREAM)
        except socket.gaierror as e:
            self.w("%s: cannot resolve (%s)\n" % (name, e.strerror or e)); return (0, 0, 0)
        seen = []
        for fam, _, _, _, sa in infos:
            ip = sa[0].split("%")[0]
            if ip not in seen: seen.append(ip)
        self.w("%s:\n" % name)
        for ip in seen: self.w("  %s  (%s)\n" % (ip, "IPv6" if ":" in ip else "IPv4"))
        return (1, len(seen), 0)

    # ------------------------------------------------------------ dig
    def _resolver(self, server):
        port = 53
        if server:
            server = server.lstrip("@")
            if "#" in server: server, p = server.rsplit("#", 1); port = int(p)
            elif server.count(":") == 1 and not server.startswith("["): server, p = server.rsplit(":", 1); port = int(p)
            server = server.strip("[]")
            if not 1 <= port <= 65535: raise ValueError("bad server port")
        else:
            server = None
            try:
                for line in open("/etc/resolv.conf"):
                    parts = line.split()
                    if len(parts) >= 2 and parts[0] == "nameserver": server = parts[1].split("%")[0]; break
            except OSError: pass
            server = server or "1.1.1.1"
        if not self.okhost(server): raise ValueError("bad server name")
        info = socket.getaddrinfo(server, port, 0, socket.SOCK_DGRAM)[0]
        return info[0], info[4]

    def _dns_udp(self, af, addr, query, qid, timeout=3.0, tries=2):
        for _ in range(tries):
            s = socket.socket(af, socket.SOCK_DGRAM)
            deadline = time.time() + timeout
            try:
                s.sendto(query, addr)
                while True:
                    left = deadline - time.time()
                    if left <= 0: break
                    s.settimeout(left)
                    try: data, src = s.recvfrom(65535)
                    except (socket.timeout, TimeoutError): break
                    if src[0].split("%")[0] != addr[0].split("%")[0]: continue
                    if len(data) >= 12 and struct.unpack(">H", data[:2])[0] == qid: return data
            finally: s.close()
        raise TimeoutError("no reply from %s (timed out)" % addr[0])

    def _dns_tcp(self, af, addr, query, qid, timeout=5.0):
        s = socket.socket(af, socket.SOCK_STREAM); s.settimeout(timeout)
        try:
            s.connect(addr); s.sendall(struct.pack(">H", len(query)) + query)
            def rd(n):
                b = b""
                while len(b) < n:
                    c = s.recv(n - len(b))
                    if not c: raise ConnectionError("connection closed by server")
                    b += c
                return b
            ln = struct.unpack(">H", rd(2))[0]; data = rd(ln)
            if len(data) < 12 or struct.unpack(">H", data[:2])[0] != qid: raise ValueError("reply id mismatch")
            return data
        finally: s.close()

    def c_dig(self, name, qtype, server):
        if qtype.startswith("@") and not server: server, qtype = qtype, ""
        qtype = (qtype or "A").upper()
        if qtype not in QTYPES: self.w("error: unknown record type %r (try %s)\n" % (qtype, " ".join(QTYPES))); return (0, 0, 0)
        if not name or " " in name: self.w("error: a name is required\n"); return (0, 0, 0)
        if qtype == "PTR":
            try: name = ipaddress.ip_address(name.strip("[]")).reverse_pointer + "."
            except ValueError: pass
        try:
            qname = _dns_encode_name(name); af, addr = self._resolver(server)
        except (ValueError, socket.gaierror) as e:
            self.w("error: %s\n" % e); return (0, 0, 0)
        qid = random.randrange(1, 65536)
        opt = b"\0" + struct.pack(">HHIH", 41, 1232, 0, 0)          # EDNS0, 1232-byte UDP payload
        query = struct.pack(">HHHHHH", qid, 0x0100, 1, 0, 0, 1) + qname + struct.pack(">HH", QTYPES[qtype], 1) + opt
        t0 = time.time(); via = "UDP"
        try:
            data = self._dns_udp(af, addr, query, qid)
            if data[2] & 0x02:
                self.w(";; Truncated, retrying in TCP mode.\n"); data = self._dns_tcp(af, addr, query, qid); via = "TCP"
        except (TimeoutError, OSError, ValueError) as e:
            self.w(";; connection error: %s\n" % e); return (0, 0, 0)
        ms = int((time.time() - t0) * 1000)
        try: self._dig_print(data, name, qtype, server, addr, ms, via)
        except (ValueError, struct.error, IndexError):
            self.w(";; error: malformed DNS reply (%d bytes)\n" % len(data)); return (0, 0, 0)
        return (1, data[3] & 0x0F, 0)

    def c_rdns(self, ip, server):
        try: ipaddress.ip_address(ip.strip("[]"))
        except ValueError: self.w("error: %r is not an IP address (use dig for names)\n" % ip); return (0, 0, 0)
        return self.c_dig(ip, "PTR", server)

    def _dig_print(self, msg, name, qtype, server, addr, ms, via):
        qid, flags, qd, an, ns, ar = struct.unpack(">HHHHHH", msg[:12])
        off, qs = 12, []
        for _ in range(qd):
            qn, off = _dns_decode_name(msg, off); qt, qc = struct.unpack(">HH", msg[off:off + 4]); off += 4; qs.append((qn, qt, qc))
        secs = []
        for count in (an, ns, ar):
            recs = []
            for _ in range(count):
                rn, off = _dns_decode_name(msg, off)
                rt, rc, ttl, rl = struct.unpack(">HHIH", msg[off:off + 10]); off += 10
                if off + rl > len(msg): raise ValueError("truncated record")
                recs.append((rn, ttl, rc, rt, _dns_rdata(msg, rt, off, rl))); off += rl
            secs.append(recs)
        rcode = flags & 0x0F
        fl = " ".join(n for bit, n in ((0x8000, "qr"), (0x0400, "aa"), (0x0200, "tc"), (0x0100, "rd"), (0x0080, "ra"), (0x0020, "ad"), (0x0010, "cd")) if flags & bit)
        self.w("; <<>> GATC dig <<>> %s %s%s\n" % (name, qtype, (" @" + server.lstrip("@")) if server else ""))
        self.w(";; ->>HEADER<<- opcode: QUERY, status: %s, id: %d\n" % (RCODES[rcode] if rcode < len(RCODES) else "RCODE%d" % rcode, qid))
        self.w(";; flags: %s; QUERY: %d, ANSWER: %d, AUTHORITY: %d, ADDITIONAL: %d\n" % (fl, qd, an, ns, ar))
        cname = lambda c: "IN" if c == 1 else "CLASS%d" % c
        tname = lambda t: QNAMES.get(t, "TYPE%d" % t)
        self.w("\n;; QUESTION SECTION:\n")
        for qn, qt, qc in qs: self.w(";%s\t\t%s\t%s\n" % (qn, cname(qc), tname(qt)))
        for title, recs in zip(("ANSWER", "AUTHORITY", "ADDITIONAL"), secs):
            recs = [r for r in recs if r[3] != 41]
            if recs:
                self.w("\n;; %s SECTION:\n" % title)
                for rn, ttl, rc, rt, rd in recs: self.w("%s\t\t%d\t%s\t%s\t%s\n" % (rn, ttl, cname(rc), tname(rt), rd))
        self.w("\n;; Query time: %d msec\n;; SERVER: %s#%d (%s)\n;; MSG SIZE  rcvd: %d\n" % (ms, addr[0].split("%")[0], addr[1], via, len(msg)))

    # ------------------------------------------------------------ whois
    @staticmethod
    def _split_server(s, default_port=43):
        if s.count(":") == 1 and not s.startswith("["):
            h, p = s.rsplit(":", 1)
            if p.isdigit(): return h, int(p)
        return s.strip("[]"), default_port
    def _public(self, host):
        if WHOIS_ALLOW_PRIVATE: return True
        try:
            for info in socket.getaddrinfo(host, 43, 0, socket.SOCK_STREAM):
                if not ipaddress.ip_address(info[4][0].split("%")[0]).is_global: return False
            return True
        except (socket.gaierror, ValueError): return False
    def _whois_fetch(self, server, query, timeout=10.0):
        host, port = self._split_server(server)
        s = socket.create_connection((host, port), timeout)
        try:
            s.sendall((query + "\r\n").encode("utf-8", "replace"))
            data, deadline = b"", time.time() + 20
            while len(data) < 512 * 1024:
                left = deadline - time.time()
                if left <= 0: break
                s.settimeout(left)
                try: chunk = s.recv(65536)
                except (socket.timeout, TimeoutError): break
                if not chunk: break
                data += chunk
        finally: s.close()
        return data.decode("utf-8", "replace")
    @staticmethod
    def _whois_fmt(server, q):
        sv = server.lower().split(":")[0]
        if sv.endswith("verisign-grs.com"): return "domain " + q
        if sv == "whois.arin.net":
            try: ipaddress.ip_address(q); return "n + " + q
            except ValueError: pass
        return q
    @staticmethod
    def _refer(text, keys):
        for key in keys:
            m = re.search(r"^\s*%s\s*:\s*(\S+)" % key, text, re.I | re.M)
            if m:
                h = m.group(1).strip().lower().rstrip(".")
                h = re.sub(r"^[a-z]+://", "", h).split("/")[0]
                if re.fullmatch(r"[a-z0-9.-]{3,253}", h): return h
        return None
    def c_whois(self, query, server):
        if not query or any(c.isspace() for c in query): self.w("error: give one domain, IP address or AS number\n"); return (0, 0, 0)
        out, path = "", []
        try:
            if server:
                path = [server]; out = self._whois_fetch(server, self._whois_fmt(server, query))
            else:
                path = [IANA_WHOIS]; out = self._whois_fetch(IANA_WHOIS, query)
                nxt = self._refer(out, ("refer", "whois"))
                for hop in range(2):
                    if not nxt or nxt in path: break
                    if not self._public(nxt):
                        self.w("# refusing to follow a referral to a non-public host (%s)\n" % nxt); break
                    got = self._whois_fetch(nxt, self._whois_fmt(nxt, query)); path.append(nxt)
                    if got.strip(): out = got
                    nxt = self._refer(got, ("Registrar WHOIS Server",)) if hop == 0 else None
        except (OSError, socket.gaierror, ValueError) as e:
            self.w("whois: %s: %s\n" % (path[-1] if path else "?", e)); return (0, 0, 0)
        lines = self.clean(out).splitlines()
        self.w("# whois: %s\n" % " -> ".join(path))
        for ln in lines[:300]: self.w(ln + "\n")
        if len(lines) > 300: self.w("# ... %d more lines not shown\n" % (len(lines) - 300))
        if not out.strip(): self.w("# (empty reply)\n"); return (0, 0, 0)
        return (1, len(lines), 0)

    # ------------------------------------------------------------ ping
    def _icmp_socket(self, fam):
        proto = socket.IPPROTO_ICMP if fam == socket.AF_INET else socket.IPPROTO_ICMPV6
        for typ, kind in ((socket.SOCK_DGRAM, "dgram"), (socket.SOCK_RAW, "raw")):
            try: return socket.socket(fam, typ, proto), kind
            except (OSError, AttributeError): continue
        return None, None
    def c_ping(self, host, count, tmo_ms):
        if not self.okhost(host): self.w("error: that is not a valid host name\n"); return (0, 0, 0)
        host = self.hostnorm(host)
        count = max(1, min(count if count > 0 else 4, 100)); tmo = max(200, min(tmo_ms if tmo_ms > 0 else 2000, 10000)) / 1000.0
        try: infos = socket.getaddrinfo(host, None, 0, socket.SOCK_STREAM)
        except socket.gaierror as e: self.w("ping: %s: cannot resolve (%s)\n" % (host, e.strerror or e)); return (0, 0, 0)
        infos.sort(key=lambda i: i[0] != socket.AF_INET)
        fam, _, _, _, sa = infos[0]; ip = sa[0].split("%")[0]; v4 = fam == socket.AF_INET
        sock, kind = self._icmp_socket(fam)
        if sock is None: return self._tcp_ping(host, ip, count, tmo)
        self.w("PING %s (%s): 56 data bytes\n" % (host, ip))
        ident, rtts, sent = os.getpid() & 0xFFFF, [], 0
        want = 0 if v4 else 129
        try:
            for seq in range(1, count + 1):
                payload = struct.pack(">d", time.time()) + bytes(range(48))
                hdr = struct.pack(">BBHHH", 8 if v4 else 128, 0, 0, ident, seq)
                pkt = hdr + payload
                if v4: pkt = struct.pack(">BBHHH", 8, 0, _icmp_checksum(hdr + payload), ident, seq) + payload
                t0 = time.time(); sent += 1
                try: sock.sendto(pkt, sa)
                except OSError as e: self.w("ping: send failed: %s\n" % e); break
                deadline = t0 + tmo; got = False
                while True:
                    left = deadline - time.time()
                    if left <= 0: break
                    sock.settimeout(left)
                    try: data, src = sock.recvfrom(2048)
                    except (socket.timeout, TimeoutError): break
                    ttl = None
                    if v4 and data and data[0] >> 4 == 4:
                        ihl = (data[0] & 0x0F) * 4; ttl = data[8]; data = data[ihl:]
                    if len(data) < 8: continue
                    typ, _, _, rid, rseq = struct.unpack(">BBHHH", data[:8])
                    if typ != want or rseq != seq or (kind == "raw" and rid != ident): continue
                    rtt = (time.time() - t0) * 1000; rtts.append(rtt); got = True
                    self.w("%d bytes from %s: icmp_seq=%d%s time=%.2f ms\n" % (len(data), ip, seq, (" ttl=%d" % ttl) if ttl else "", rtt))
                    break
                if not got: self.w("Request timeout for icmp_seq %d\n" % seq)
                if seq < count:
                    rest = 1.0 - (time.time() - t0)
                    if rest > 0: time.sleep(rest)
        finally: sock.close()
        return self._ping_summary(host, sent, rtts)
    def _ping_summary(self, host, sent, rtts):
        loss = 100.0 * (sent - len(rtts)) / sent if sent else 100.0
        self.w("\n--- %s ping statistics ---\n%d packets transmitted, %d received, %.0f%% packet loss\n" % (host, sent, len(rtts), loss))
        if rtts:
            avg = sum(rtts) / len(rtts); md = (sum((r - avg) ** 2 for r in rtts) / len(rtts)) ** 0.5
            self.w("rtt min/avg/max/mdev = %.3f/%.3f/%.3f/%.3f ms\n" % (min(rtts), avg, max(rtts), md))
        return (1 if rtts else 0, len(rtts), sent)
    def _tcp_ping(self, host, ip, count, tmo):
        self.w("PING %s (%s): ICMP is not permitted here, using TCP connects instead\n" % (host, ip))
        port, rtts, sent = 443, [], 0
        for seq in range(1, count + 1):
            sent += 1; t0 = time.time(); res = None
            for attempt in range(2):
                try:
                    s = socket.create_connection((ip, port), tmo); s.close(); res = "open"
                except ConnectionRefusedError: res = "refused"
                except OSError: res = None
                if res or port == 80: break
                port = 80
            if res:
                rtt = (time.time() - t0) * 1000; rtts.append(rtt)
                self.w("tcp %s:%d seq=%d %s time=%.2f ms\n" % (ip, port, seq, res, rtt))
            else: self.w("tcp %s:%d seq=%d no response\n" % (ip, port, seq))
            if seq < count: time.sleep(max(0, 1.0 - (time.time() - t0)))
        return self._ping_summary(host, sent, rtts)

    # ------------------------------------------------------------ tcp client / server (nc)
    def _tls_info(self, ss):
        info = "%s %s" % (ss.version(), (ss.cipher() or ("?",))[0])
        try:
            cert = ss.getpeercert(); subj = dict(x[0] for x in cert.get("subject", ())); iss = dict(x[0] for x in cert.get("issuer", ()))
            left = (ssl.cert_time_to_seconds(cert["notAfter"]) - time.time()) / 86400.0
            return info, "cert: %s  issuer: %s  expires in %d days" % (subj.get("commonName", "?"), iss.get("organizationName") or iss.get("commonName", "?"), left)
        except Exception: return info, None
    def _open(self, host, port, timeout, tls):
        """returns (socket, connect_ms, ip, tls_info) or raises"""
        last = None
        for fam, typ, proto, _, sa in socket.getaddrinfo(host, port, 0, socket.SOCK_STREAM):
            s = socket.socket(fam, typ, proto); s.settimeout(timeout); t0 = time.time()
            try:
                s.connect(sa); ms = (time.time() - t0) * 1000
                if tls:
                    s = ssl.create_default_context().wrap_socket(s, server_hostname=host)
                return s, ms, sa[0].split("%")[0]
            except (OSError, ssl.SSLError) as e:
                last = e
                try: s.close()
                except OSError: pass
        raise last
    def _why(self, e, host):
        if isinstance(e, socket.gaierror): return "cannot resolve %s (%s)" % (host, e.strerror or e)
        if isinstance(e, ssl.SSLCertVerificationError): return "TLS certificate check failed: %s" % (e.verify_message or e)
        if isinstance(e, ssl.SSLError): return "TLS error: %s" % e
        if isinstance(e, (socket.timeout, TimeoutError)): return "timed out"
        if isinstance(e, ConnectionRefusedError): return "connection refused"
        return e.strerror or str(e)
    def c_connect(self, host, port, tmo, tls):
        self.close()
        if not self.okhost(host): self.w("error: that is not a valid host name\n"); return (0, 0, 0)
        if not 1 <= port <= 65535: self.w("error: port must be 1-65535\n"); return (0, 0, 0)
        host = self.hostnorm(host); tmo = max(1, min(tmo or 5, 60))
        try: s, ms, ip = self._open(host, port, tmo, bool(tls))
        except (OSError, ssl.SSLError) as e: self.w("connect to %s port %d failed: %s\n" % (host, port, self._why(e, host))); return (0, 0, 0)
        self.sock = s
        self.w("connected to %s (%s) port %d in %.0f ms\n" % (host, ip, port, ms))
        if tls:
            info, cert = self._tls_info(s); self.w("tls: %s\n" % info)
            if cert: self.w("%s\n" % cert)
        return (1, int(ms), 0)
    def c_send(self, addr, n):
        if self.sock is None: self.w("error: not connected\n"); return (0, 0, 0)
        if not (0 <= n <= 4096 and mem_ok(addr, n, len(self.mem))): self.w("error: bad send buffer\n"); return (0, 0, 0)
        try: self.sock.settimeout(10); self.sock.sendall(bytes(self.mem[addr + i] & 0xFF for i in range(n)))
        except (OSError, ssl.SSLError) as e:
            self.w("send failed: %s\n" % self._why(e, "")); self.close(); return (0, 0, 0)
        return (1, n, 0)
    def c_recv(self, idle_ms, total_ms):
        if self.sock is None: self.w("error: not connected\n"); return (0, 0, 1)
        idle = max(0.05, min(idle_ms or 1500, 60000) / 1000.0); total = max(idle, min(total_ms or 5000, 300000) / 1000.0)
        deadline, data, closed = time.time() + total, b"", 0
        while len(data) < MAX_PRINT:
            left = min(idle, deadline - time.time())
            if left <= 0: break
            self.sock.settimeout(left)
            try: chunk = self.sock.recv(65536)
            except (socket.timeout, TimeoutError): break
            except ssl.SSLWantReadError: continue
            except (OSError, ssl.SSLError): closed = 1; break
            if not chunk: closed = 1; break
            data += chunk
        if data:
            text = self.clean(data.decode("utf-8", "replace"))
            self.w(text if text.endswith("\n") else text + "\n")
        if closed: self.close()
        return (1 if data else 0, len(data), closed)
    def c_listen(self, port, tmo, bind):
        self.close()
        bind = bind or "127.0.0.1"
        if not self.okhost(bind): self.w("error: bad bind address\n"); return (0, 0, 0)
        if not 1 <= port <= 65535: self.w("error: port must be 1-65535\n"); return (0, 0, 0)
        tmo = max(1, min(tmo or 60, 3600)); bind = self.hostnorm(bind)
        try:
            fam = socket.getaddrinfo(bind, port, 0, socket.SOCK_STREAM, 0, socket.AI_PASSIVE)[0]
            srv = socket.socket(fam[0], socket.SOCK_STREAM); srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            srv.bind(fam[4]); srv.listen(1); srv.settimeout(tmo)
        except (OSError, socket.gaierror) as e:
            self.w("listen on %s port %d failed: %s\n" % (bind, port, self._why(e, bind))); return (0, 0, 0)
        self.w("listening on %s port %d (waits %d s, Ctrl-C cancels)\n" % (bind, port, tmo))
        try: conn, peer = srv.accept()
        except (socket.timeout, TimeoutError): self.w("no connection received (timed out)\n"); return (0, 0, 0)
        finally: srv.close()
        self.sock = conn; self.w("connection from %s port %d\n" % (peer[0].split("%")[0], peer[1]))
        return (1, 0, 0)
    def c_portcheck(self, host, port, tmo):
        if not self.okhost(host): self.w("error: that is not a valid host name\n"); return (0, 0, 0)
        if not 1 <= port <= 65535: self.w("port %d: bad port number\n" % port); return (0, 0, 0)
        host = self.hostnorm(host); tmo = max(1, min(tmo or 3, 30))
        try: s, ms, ip = self._open(host, port, tmo, False); s.close()
        except socket.gaierror as e: self.w("%s: cannot resolve (%s)\n" % (host, e.strerror or e)); return (0, 0, 0)
        except (socket.timeout, TimeoutError): self.w("%s %d/tcp: no response (timed out - filtered or host down)\n" % (host, port)); return (0, 0, 0)
        except ConnectionRefusedError: self.w("%s %d/tcp: closed (connection refused)\n" % (host, port)); return (0, 0, 0)
        except OSError as e: self.w("%s %d/tcp: %s\n" % (host, port, e.strerror or e)); return (0, 0, 0)
        self.w("%s %d/tcp: open (%s, %.0f ms)\n" % (host, port, ip, ms)); return (1, int(ms), 0)

    # ------------------------------------------------------------ http HEAD
    def c_http(self, url):
        from urllib.parse import urlsplit, quote
        u = url if "://" in url else "http://" + url
        try: sp = urlsplit(u); port = sp.port
        except ValueError: self.w("error: bad URL\n"); return (0, 0, 0)
        scheme = sp.scheme.lower()
        if scheme not in ("http", "https") or not sp.hostname or not self.okhost(sp.hostname):
            self.w("error: use http://host/path or https://host/path\n"); return (0, 0, 0)
        tls = scheme == "https"; port = port or (443 if tls else 80)
        path = quote(sp.path or "/", safe="/%:@!$&'()*+,;=~-._") + (("?" + quote(sp.query, safe="=&%:@!$'()*+,;/?~-._")) if sp.query else "")
        hosthdr = sp.hostname + ((":%d" % port) if port != (443 if tls else 80) else "")
        self.w("HEAD %s://%s%s\n" % (scheme, hosthdr, path))
        t0 = time.time()
        try: s, ms, ip = self._open(sp.hostname, port, 8, tls)
        except (OSError, ssl.SSLError) as e: self.w("failed: %s\n" % self._why(e, sp.hostname)); return (0, 0, 0)
        try:
            self.w("connected to %s port %d in %.0f ms\n" % (ip, port, ms))
            if tls:
                info, cert = self._tls_info(s); self.w("tls: %s\n" % info)
                if cert: self.w("%s\n" % cert)
            s.settimeout(8)
            s.sendall(("HEAD %s HTTP/1.1\r\nHost: %s\r\nUser-Agent: GATC-netkit/1.0\r\nAccept: */*\r\nConnection: close\r\n\r\n" % (path, hosthdr)).encode("ascii", "replace"))
            buf, first = b"", None
            while b"\r\n\r\n" not in buf and len(buf) < 65536:
                try: chunk = s.recv(8192)
                except (socket.timeout, TimeoutError): break
                if not chunk: break
                if first is None: first = (time.time() - t0) * 1000
                buf += chunk
        except (OSError, ssl.SSLError) as e: self.w("failed: %s\n" % self._why(e, sp.hostname)); return (0, 0, 0)
        finally: s.close()
        head = buf.split(b"\r\n\r\n")[0].decode("latin-1")
        if not head.strip(): self.w("no response\n"); return (0, 0, 0)
        self.w("\n%s\n" % self.clean(head))
        if first is not None: self.w("\ntime to first byte: %.0f ms\n" % first)
        m = re.match(r"HTTP/\S+\s+(\d+)", head)
        return (1, int(m.group(1)) if m else 0, 0)

# ---------------------------------------------------------------------------------------
# filesystem bridge for shell.aa  (opt-in: run with --fs)
#
# The VM has no file-system opcodes.  Exactly like the --net bridge, a program STOREs a
# command number into a control cell and the host performs ONE small syscall-like step
# (stat, open, read, write, unlink, rename, ...).  Everything else - parsing, globbing,
# recursion, formatting, grep/wc/tail/xxd/crc32 - is done by the .aa program itself.
# Paths are the address of a NUL-terminated byte string in VM memory (one byte per cell).
# Nothing here is reachable unless --fs is given.  --fs-root DIR confines it to DIR.
# Control cells 4128..4138:
#   4128 command  4129-4132 arguments  4133 status (1 ok, 0 failed)
#   4134-4137 results (on failure 4134 = errno)  4138 magic (FS_MAGIC on, 1 = supported but off)
# Commands:
#   1 stat(path,follow)->size,type,mode,mtime   type: 1 file 2 dir 3 symlink 4 other
#   2 opendir(path)->handle,count   3 dirent(h,i,dest,max)->len,type,mode,size   4 closedir(h)
#   5 mkdir(path,parents)  6 rmdir(path)  7 unlink(path)  8 rename(src,dst)
#   9 open(path,mode)->fd   mode: 0 read 1 write+truncate 2 append 3 create (no truncate)
#   10 read(fd,addr,n)->count  11 write(fd,addr,n)->count  (fd 1 = stdout, 2 = stderr)
#   12 close(fd)  13 seek(fd,off,whence,negative)->pos  14 chdir(path)  15 getcwd(dest,max)->len
#   16 utime(path)  17 chmod(path,mode)  18 time()->epoch,utc offset  19 strerror(errno,dest,max)
#   20 redirect stdout(path or 0 to restore, append)  21 isatty()->stdout tty,stdin tty,columns
#   22 realpath(path,dest,max)  23 getenv(name,dest,max)  24 samefile(a,b)->same,b inside a
#   25 errmode(1 = PUTC/PUTN/raw writes go to stderr, 0 = back)  26 statvfs(path)->total,free,avail
#   27 link(target,linkpath,hard)  28 readlink(path,dest,max)->len
# ---------------------------------------------------------------------------------------
FS_MAGIC = 18003
CTL_FCMD, CTL_FA1, CTL_FA2, CTL_FA3, CTL_FA4, CTL_FSTATUS, CTL_FR1, CTL_FR2, CTL_FR3, CTL_FR4, CTL_FMAGIC = range(4128, 4139)
FS_IO_MAX = 4096
FS_MAX_HANDLES = 64

class FSKit:
    def __init__(self, vm, root=None):
        import io, stat as _stat
        self.io, self.st = io, _stat
        self.vm = vm; self.mem = vm.mem
        self.fds = {}; self.dirs = {}; self.next_id = 3
        self.term_out = vm.stdout           # the real stdout text stream
        self.redir_bin = None; self.redir_out = None
        self.err_mode = False
        self.root = os.path.realpath(root) if root else None
        if self.root:
            if not os.path.isdir(self.root): raise GATCError(f"--fs-root {root}: not a directory")
            os.chdir(self.root)

    # ------------------------------------------------------------ helpers
    def cs(self, addr, maxlen=FS_IO_MAX):
        """NUL-terminated byte string at addr -> str path (round-trips any byte via fsdecode)"""
        if not ram(addr, len(self.mem)): raise OSError(14, "bad address")
        b = bytearray()
        for i in range(maxlen):
            if not ram(addr + i, len(self.mem)): break
            v = self.mem[addr + i]
            if v == 0: break
            b.append(v & 0xFF)
        s = os.fsdecode(bytes(b))
        if s == "~" or s.startswith("~/"):
            home = self.root or os.path.expanduser("~")
            s = home + s[1:]
        return s

    def put(self, dest, maxlen, data):
        """write bytes + NUL into VM memory, truncated to fit; returns the length written"""
        if maxlen <= 0 or not ram(dest, len(self.mem)): return 0
        maxlen = min(maxlen, (HOLE_LO if dest < HOLE_LO else len(self.mem)) - dest)
        data = data[:maxlen - 1]
        for i, c in enumerate(data): self.mem[dest + i] = c
        self.mem[dest + len(data)] = 0
        return len(data)

    def jail(self, path, follow=True):
        """with --fs-root, refuse paths that resolve outside the root (best effort)"""
        if not self.root: return path
        full = os.path.abspath(path)
        if follow: real = os.path.realpath(full)
        else: real = os.path.join(os.path.realpath(os.path.dirname(full)), os.path.basename(full))
        if real != self.root and not real.startswith(self.root.rstrip(os.sep) + os.sep):
            raise OSError(13, "outside --fs-root")
        return path

    def ftype(self, mode):
        st = self.st
        if st.S_ISLNK(mode): return 3
        if st.S_ISDIR(mode): return 2
        if st.S_ISREG(mode): return 1
        return 4

    def new_id(self, table):
        if len(self.fds) + len(self.dirs) >= FS_MAX_HANDLES: raise OSError(24, "too many open handles")
        h = self.next_id; self.next_id += 1
        return h

    def cur_out(self):
        return self.redir_out if self.redir_out is not None else self.term_out

    def raw_out(self, data, fd):
        """byte-exact write to stdout (fd 1) or stderr (fd 2), in order with PUTC/PUTN output"""
        if fd == 2 or self.err_mode:
            sys.stderr.flush(); target = getattr(sys.stderr, "buffer", None)
            if target is None: sys.stderr.write(data.decode("latin-1"))
            else: target.write(data); target.flush()
            return
        if self.redir_out is not None:
            self.redir_out.flush(); self.redir_bin.write(data); self.redir_bin.flush(); return
        out = self.term_out; out.flush()
        buf = getattr(out, "buffer", None)
        if buf is None: out.write(data.decode("utf-8", "replace"))
        else: buf.write(data); buf.flush()

    def restore_stdout(self):
        if self.redir_out is not None:
            try: self.redir_out.flush(); self.redir_out.close()
            except (OSError, ValueError): pass
            self.redir_out = self.redir_bin = None
        self.vm.stdout = sys.stderr if self.err_mode else self.term_out

    def close_all(self):
        for fd in list(self.fds.values()):
            try: os.close(fd)
            except OSError: pass
        self.fds.clear(); self.dirs.clear()
        self.err_mode = False
        self.restore_stdout()

    # ------------------------------------------------------------ dispatcher
    def command(self, cmd, a1, a2, a3, a4):
        """returns (status, r1, r2, r3, r4); on failure r1 = errno"""
        try:
            f = getattr(self, "c%d" % cmd, None)
            if f is None: return (0, 22, 0, 0, 0)
            r = f(a1, a2, a3, a4)
            return (1,) + tuple(r) + (0,) * (4 - len(r))
        except OSError as e:
            return (0, e.errno or 5, 0, 0, 0)
        except (ValueError, UnicodeError, OverflowError) as e:
            return (0, 22, 0, 0, 0)

    def c1(self, a1, a2, a3, a4):     # stat
        p = self.jail(self.cs(a1), follow=bool(a2))
        s = os.stat(p) if a2 else os.lstat(p)
        return (s.st_size, self.ftype(s.st_mode), self.st.S_IMODE(s.st_mode), int(s.st_mtime))
    def c2(self, a1, a2, a3, a4):     # opendir
        p = self.jail(self.cs(a1))
        names = os.listdir(p)
        names.sort(key=lambda n: (n.lstrip(".").lower(), n))
        h = self.new_id(self.dirs); self.dirs[h] = (p, names)
        return (h, len(names))
    def c3(self, a1, a2, a3, a4):     # dirent
        p, names = self.dirs[a1] if a1 in self.dirs else (None, None)
        if names is None: raise OSError(9, "bad directory handle")
        if not 0 <= a2 < len(names): raise OSError(22, "index out of range")
        name = names[a2]
        try:
            s = os.lstat(os.path.join(p, name)); t, m, z = self.ftype(s.st_mode), self.st.S_IMODE(s.st_mode), s.st_size
        except OSError: t, m, z = 4, 0, 0
        n = self.put(a3, a4, os.fsencode(name))
        return (n, t, m, z)
    def c4(self, a1, a2, a3, a4):     # closedir
        self.dirs.pop(a1, None); return ()
    def c5(self, a1, a2, a3, a4):     # mkdir
        p = self.jail(self.cs(a1), follow=False)
        if a2: os.makedirs(p, exist_ok=True)
        else: os.mkdir(p)
        return ()
    def c6(self, a1, a2, a3, a4):     # rmdir
        p = self.jail(self.cs(a1), follow=False)
        if os.path.abspath(p) == os.path.abspath(os.sep) or (self.root and os.path.realpath(p) == self.root):
            raise OSError(16, "refusing to remove the root")
        os.rmdir(p); return ()
    def c7(self, a1, a2, a3, a4):     # unlink
        os.unlink(self.jail(self.cs(a1), follow=False)); return ()
    def c8(self, a1, a2, a3, a4):     # rename
        os.rename(self.jail(self.cs(a1), follow=False), self.jail(self.cs(a2), follow=False)); return ()
    def c9(self, a1, a2, a3, a4):     # open
        flags = {0: os.O_RDONLY, 1: os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
                 2: os.O_WRONLY | os.O_CREAT | os.O_APPEND, 3: os.O_WRONLY | os.O_CREAT}.get(a2)
        if flags is None: raise OSError(22, "bad open mode")
        p = self.jail(self.cs(a1), follow=True)
        h = self.new_id(self.fds)
        self.fds[h] = os.open(p, flags | getattr(os, "O_BINARY", 0), 0o666)
        return (h,)
    def _buf(self, addr, n):
        if not (0 <= n <= FS_IO_MAX and mem_ok(addr, n, len(self.mem))): raise OSError(14, "bad buffer")
    def c10(self, a1, a2, a3, a4):    # read
        self._buf(a2, a3)
        if a1 not in self.fds: raise OSError(9, "bad file handle")
        data = os.read(self.fds[a1], a3)
        for i, c in enumerate(data): self.mem[a2 + i] = c
        return (len(data),)
    def c11(self, a1, a2, a3, a4):    # write
        self._buf(a2, a3)
        data = bytes(self.mem[a2 + i] & 0xFF for i in range(a3))
        if a1 in (1, 2): self.raw_out(data, a1); return (len(data),)
        if a1 not in self.fds: raise OSError(9, "bad file handle")
        mv, done = memoryview(data), 0
        while done < len(data): done += os.write(self.fds[a1], mv[done:])
        return (done,)
    def c12(self, a1, a2, a3, a4):    # close
        fd = self.fds.pop(a1, None)
        if fd is None: raise OSError(9, "bad file handle")
        os.close(fd); return ()
    def c13(self, a1, a2, a3, a4):    # seek
        if a1 not in self.fds: raise OSError(9, "bad file handle")
        return (os.lseek(self.fds[a1], -a2 if a4 else a2, a3),)
    def c14(self, a1, a2, a3, a4):    # chdir
        os.chdir(self.jail(self.cs(a1))); return ()
    def c15(self, a1, a2, a3, a4):    # getcwd
        return (self.put(a1, a2, os.fsencode(os.getcwd())),)
    def c16(self, a1, a2, a3, a4):    # utime
        os.utime(self.jail(self.cs(a1)), None); return ()
    def c17(self, a1, a2, a3, a4):    # chmod
        os.chmod(self.jail(self.cs(a1)), a2 & 0o7777); return ()
    def c18(self, a1, a2, a3, a4):    # time
        now = int(time.time())
        return (now, time.localtime(now).tm_gmtoff or 0)
    def c19(self, a1, a2, a3, a4):    # strerror
        return (self.put(a2, a3, os.strerror(a1).encode("utf-8", "replace")),)
    def c20(self, a1, a2, a3, a4):    # redirect stdout
        self.vm.stdout.flush()
        if a1 == 0: self.restore_stdout(); return ()
        p = self.jail(self.cs(a1), follow=True)
        f = open(p, "ab" if a2 else "wb")
        if self.redir_out is not None: self.restore_stdout()
        self.redir_bin = f
        self.redir_out = self.io.TextIOWrapper(f, encoding="latin-1", newline="\n", write_through=True)
        if not self.err_mode: self.vm.stdout = self.redir_out
        return ()
    def c21(self, a1, a2, a3, a4):    # isatty
        def tty(s):
            try: return 1 if s.isatty() else 0
            except (AttributeError, ValueError): return 0
        out = 0 if self.redir_out is not None else tty(self.term_out)
        try:
            import shutil; cols = shutil.get_terminal_size((80, 24)).columns
        except (OSError, ValueError): cols = 80
        return (out, tty(sys.stdin), max(20, min(cols, 400)))
    def c22(self, a1, a2, a3, a4):    # realpath
        return (self.put(a2, a3, os.fsencode(os.path.realpath(self.jail(self.cs(a1))))),)
    def c23(self, a1, a2, a3, a4):    # getenv
        name = self.cs(a1)
        if name == "HOME" and self.root: v = self.root
        else: v = os.environ.get(name)
        if v is None: raise OSError(2, "not set")
        return (self.put(a2, a3, os.fsencode(v)),)
    def c24(self, a1, a2, a3, a4):    # samefile + inside
        a, b = self.cs(a1), self.cs(a2)
        try: same = 1 if os.path.samefile(a, b) else 0
        except OSError: same = 0
        ra, rb = os.path.realpath(a), os.path.realpath(b)
        inside = 1 if rb.startswith(ra.rstrip(os.sep) + os.sep) else 0
        return (same, inside)
    def c25(self, a1, a2, a3, a4):    # errmode
        self.vm.stdout.flush()
        self.err_mode = bool(a1)
        self.vm.stdout = sys.stderr if self.err_mode else self.cur_out()
        return ()
    def c26(self, a1, a2, a3, a4):    # statvfs
        s = os.statvfs(self.jail(self.cs(a1)))
        return (s.f_blocks * s.f_frsize, s.f_bfree * s.f_frsize, s.f_bavail * s.f_frsize)
    def c27(self, a1, a2, a3, a4):    # link / symlink
        target, link = self.cs(a1), self.jail(self.cs(a2), follow=False)
        if a3: os.link(self.jail(target), link)
        else: os.symlink(target, link)
        return ()
    def c28(self, a1, a2, a3, a4):    # readlink
        return (self.put(a2, a3, os.fsencode(os.readlink(self.jail(self.cs(a1), follow=False)))),)

# ---------------------------------------------------------------------------------------
# terminal bridge for paint.aa  (opt-in: run with --tty)
#
# GETC waits for Enter and the VM cannot see the mouse.  With --tty the program can put the
# terminal in raw mode and read single keys (arrows and mouse decoded) and write raw bytes
# (UTF-8, colour escapes) in one call.  Drawing logic stays in the .aa program.
# Control cells 4144..4153:
#   4144 command  4145-4147 arguments  4148 status  4149-4152 results  4153 magic (TTY_MAGIC on, 1 = off)
# Commands:
#   1 raw(on)            enter (1) or leave (0) raw keyboard mode (no echo, no Enter needed)
#   2 key(timeout_ms)    0 = wait.  status 0 = no key (timeout) or end of input (r1 = 1 at EOF)
#                        r1 = code: a character's code point, Enter 10, Tab 9, Backspace 8, Esc 27,
#                        arrows 1001 up 1002 down 1003 right 1004 left, 1005 Home 1006 End,
#                        1007 PgUp 1008 PgDn 1009 Delete, mouse 2000 press/drag 2001 release
#                        2002 wheel up 2003 wheel down (r2 = column, r3 = row, 1-based,
#                        r4 = button 0 left 1 middle 2 right, +32 while dragging)
#   3 write(addr, n)     raw bytes (one per cell) to stdout
#   4 size()             r1 = columns, r2 = rows
#   5 sleep(ms)
#   6 ticks()            r1 = milliseconds since start
# ---------------------------------------------------------------------------------------
TTY_MAGIC = 18516
CTL_TCMD, CTL_TA1, CTL_TA2, CTL_TA3, CTL_TSTATUS, CTL_TR1, CTL_TR2, CTL_TR3, CTL_TR4, CTL_TMAGIC = range(4144, 4154)

class TTYKit:
    def __init__(self, vm):
        self.vm = vm; self.mem = vm.mem
        self.fd = None; self.saved = None; self.raw = False; self.pending = b""
        self.t0 = time.time(); self.eof = False; self.touched = False
        try: self.fd = (vm.stdin if vm.stdin is not None else sys.stdin).fileno()
        except (AttributeError, ValueError, OSError, io_unsupported()): self.fd = None
        self.is_tty = False
        try: self.is_tty = self.fd is not None and os.isatty(self.fd)
        except OSError: pass
        self.win = os.name == "nt"

    def command(self, cmd, a1, a2, a3):
        try:
            f = getattr(self, "c%d" % cmd, None)
            if f is None: return (0, 22, 0, 0, 0)
            r = f(a1, a2, a3)
            if r is None: return (0, 0, 0, 0, 0)
            return (1,) + tuple(r) + (0,) * (4 - len(r))
        except OSError as e:
            return (0, e.errno or 5, 0, 0, 0)

    # ---- raw mode
    def c1(self, a1, a2, a3):
        if a1: self.enter_raw()
        else: self.leave_raw()
        return ()
    def enter_raw(self):
        self.touched = True
        if self.raw or not self.is_tty or self.win: self.raw = True; return
        import termios, tty
        self.saved = termios.tcgetattr(self.fd)
        tty.setcbreak(self.fd)
        attrs = termios.tcgetattr(self.fd); attrs[3] &= ~termios.ECHO
        termios.tcsetattr(self.fd, termios.TCSADRAIN, attrs)
        self.raw = True
    def leave_raw(self):
        if self.saved is not None:
            import termios
            try: termios.tcsetattr(self.fd, termios.TCSADRAIN, self.saved)
            except (OSError, termios.error): pass
            self.saved = None
        self.raw = False
    def close(self):
        if self.touched:   # leave mouse reporting / alternate screen even after a crash
            self.out(b"\x1b[0m\x1b[?1002l\x1b[?1006l\x1b[?25h\x1b[?1049l")
        self.leave_raw()

    # ---- input
    def readbyte(self, timeout):
        """one byte or None on timeout; b'' at end of input.  timeout None = wait"""
        if self.pending:
            b, self.pending = self.pending[:1], self.pending[1:]; return b
        if self.fd is None:
            s = self.vm.stdin.read(1); return s.encode("utf-8") if s else b""
        if self.win and self.is_tty:
            import msvcrt
            end = None if timeout is None else time.time() + timeout
            while not msvcrt.kbhit():
                if end is not None and time.time() >= end: return None
                time.sleep(0.01)
            ch = msvcrt.getwch()
            if ch in ("\x00", "\xe0"):
                k = msvcrt.getwch()
                seq = {"H": b"\x1b[A", "P": b"\x1b[B", "M": b"\x1b[C", "K": b"\x1b[D", "G": b"\x1b[H",
                       "O": b"\x1b[F", "I": b"\x1b[5~", "Q": b"\x1b[6~", "S": b"\x1b[3~"}.get(k, b"")
                if not seq: return None
                self.pending = seq[1:]; return seq[:1]
            if ch == "\r": ch = "\n"
            data = ch.encode("utf-8"); self.pending = data[1:]; return data[:1]
        import select
        r, _, _ = select.select([self.fd], [], [], timeout)
        if not r: return None
        return os.read(self.fd, 1)
    def c2(self, a1, a2, a3):
        if self.eof: raise EOFError_()
        try: sys.stdout.flush(); self.vm.stdout.flush()
        except (OSError, ValueError): pass
        b = self.readbyte(None if a1 <= 0 else a1 / 1000.0)
        if b is None: return None
        if b == b"":
            self.eof = True; raise EOFError_()
        return self.decode(b)
    def decode(self, b):
        c = b[0]
        if c == 27:
            nxt = self.readbyte(0.05)
            if not nxt: return (27,)
            if nxt == b"[" or nxt == b"O":
                seq = b""
                while True:
                    x = self.readbyte(0.05)
                    if not x: break
                    seq += x
                    if 0x40 <= x[0] <= 0x7E and not (nxt == b"[" and seq[:1] == b"<" and x in b"0123456789;"): break
                return self.csi(seq)
            self.pending = nxt + self.pending; return (27,)
        if c in (13, 10): return (10,)
        if c in (127, 8): return (8,)
        if c >= 0x80:   # UTF-8 sequence -> code point
            n = 2 if c >= 0xC0 else 1
            if c >= 0xE0: n = 3
            if c >= 0xF0: n = 4
            data = b
            for _ in range(n - 1):
                x = self.readbyte(0.05)
                if not x: break
                data += x
            try: return (ord(data.decode("utf-8")),)
            except (UnicodeDecodeError, TypeError): return (0xFFFD,)
        return (c,)
    def csi(self, seq):
        keys = {b"A": 1001, b"B": 1002, b"C": 1003, b"D": 1004, b"H": 1005, b"F": 1006,
                b"1~": 1005, b"7~": 1005, b"4~": 1006, b"8~": 1006, b"5~": 1007, b"6~": 1008, b"3~": 1009}
        if seq[:1] == b"<" and seq[-1:] in (b"M", b"m"):       # SGR mouse
            try: btn, col, row = (int(v) for v in seq[1:-1].split(b";"))
            except ValueError: return (0,)
            if btn & 64: return (2002 if (btn & 1) == 0 else 2003, col, row, 0)
            code = 2001 if seq[-1:] == b"m" else 2000
            return (code, col, row, (btn & 3) | (32 if btn & 32 else 0))
        final = seq[-1:]
        if final in (b"A", b"B", b"C", b"D", b"H", b"F"): return (keys[final],)
        return (keys.get(seq.split(b";")[0][-2:] if b"~" in seq else seq, 0),)

    # ---- output
    def out(self, data):
        try:
            self.vm.stdout.flush()
            buf = getattr(self.vm.stdout, "buffer", None)
            if buf is None: self.vm.stdout.write(data.decode("utf-8", "replace"))
            else: buf.write(data); buf.flush()
        except (OSError, ValueError): pass
    def c3(self, a1, a2, a3):
        if not (0 <= a2 <= 65536 and mem_ok(a1, a2, len(self.mem))): raise OSError(14, "bad buffer")
        self.out(bytes(self.mem[a1 + i] & 0xFF for i in range(a2)))
        return (a2,)
    def c4(self, a1, a2, a3):
        try:
            import shutil; s = shutil.get_terminal_size((80, 24)); return (s.columns, s.lines)
        except (OSError, ValueError): return (80, 24)
    def c5(self, a1, a2, a3):
        time.sleep(max(0, min(a1, 10000)) / 1000.0); return ()
    def c6(self, a1, a2, a3):
        return (int((time.time() - self.t0) * 1000),)

class EOFError_(Exception):
    pass

def io_unsupported():
    import io
    return io.UnsupportedOperation

class VM:
    def __init__(self, program, genome=False, stdin=None, stdout=None):
        self.program=program; self.pc=0; self.stack=[]; self.calls=[]; self.mem=[0]*MEM_SIZE
        self.stdin=stdin or sys.stdin; self.stdout=stdout or sys.stdout
        self.halted=False; self.exit_code=0; self.steps=0; self.genome=genome; self._halt_note=False
        self.file=bytearray(); self.filepath=None; self.savepath=None; self.dirty=0
        self.ctl={k:0 for k in range(CTL_A1,CTL_LOST+1)}; self.ctl.update({k:0 for k in range(CTL_NA1,CTL_NR2+1)}); self.net=None
        self.ctl.update({k:0 for k in range(CTL_FA1,CTL_FR4+1)}); self.fs=None
        self.ctl.update({k:0 for k in range(CTL_TA1,CTL_TR4+1)}); self.tty=None
        self.groups=collections.deque(); self.u_total=0; self.u_suspend=0; self.redo=[]; self.u_cov=(0,0)
    def load_file(self, path, addr=0):
        try:
            data = open(path, "rb").read()
        except OSError as e:
            print(f"error: cannot open {path}: {e}", file=sys.stderr)
            return
        n = 0
        for i in range(len(data)):
            if not ram(addr + i, len(self.mem)): break
            self.mem[addr + i] = data[i]; n += 1
        print(f"loaded {n} bytes from {path} at address {addr}", file=sys.stderr)
    # ---------------- file-backed address space ----------------
    def load_edit_file(self, path):
        if not os.path.exists(path):
            self.filepath = path; print(f"new file {path} (empty)", file=sys.stderr); return
        try:
            size = os.path.getsize(path)
            if size > MAX_FILE:
                raise GATCError(f"{path} is {size} bytes, over the 1 GiB limit ({MAX_FILE}) - not opened")
            buf = bytearray(size); pos = 0
            with open(path, "rb") as f:
                mv = memoryview(buf)
                while pos < size:
                    got = f.readinto(mv[pos:pos + CHUNK])
                    if not got: break
                    pos += got
                del mv
            if pos != size: raise GATCError(f"short read on {path}: {pos} of {size} bytes")
        except OSError as e:
            raise GATCError(f"cannot open {path}: {e}")
        self.file = buf; self.filepath = path
        print(f"opened {path}: {len(self.file)} bytes", file=sys.stderr)
    def fetch(self, addr):
        if 0 <= addr < HOLE_LO or HOLE_HI <= addr < MEM_SIZE: return self.mem[addr]
        if addr >= FILE_BASE:
            i = addr - FILE_BASE
            return self.file[i] if i < len(self.file) else 0
        if addr == CTL_SIZE: return len(self.file)
        if addr == CTL_DIRTY: return self.dirty
        if addr == CTL_MAGIC: return 51966
        if addr == CTL_NMAGIC: return NET_MAGIC if self.net is not None else 1   # 1 = supported but off (no --net)
        if addr == CTL_FMAGIC: return FS_MAGIC if self.fs is not None else 1     # 1 = supported but off (no --fs)
        if addr == CTL_TMAGIC: return TTY_MAGIC if self.tty is not None else 1   # 1 = supported but off (no --tty)
        return self.ctl.get(addr, 0)
    def store(self, addr, val):
        if 0 <= addr < HOLE_LO or HOLE_HI <= addr < MEM_SIZE: self.mem[addr] = val; return
        if addr >= FILE_BASE:
            i, v = addr - FILE_BASE, val & 0xFF
            n = len(self.file)
            if i < n:
                if self.file[i] != v:
                    if not (self.u_cov[0] <= i < self.u_cov[1]): self.u_rec(('r', i, bytes((self.file[i],)), n), 120)
                    self.file[i] = v; self.dirty = 1
            elif i < MAX_FILE and i - n <= GROW_CAP:
                self._prep(n, i - n + 1); self.file[i] = v; self.dirty = 1
            else: warn(f"file store too far past the end: {i}")
            return
        if addr == CTL_CMD: self.ctl_command(val); return
        if addr in (CTL_A1, CTL_A2, CTL_A3): self.ctl[addr] = val; return
        if addr == CTL_NCMD: self.net_command(val); return
        if addr in (CTL_NA1, CTL_NA2, CTL_NA3, CTL_NA4): self.ctl[addr] = val; return
        if addr == CTL_FCMD: self.fs_command(val); return
        if addr == CTL_TCMD: self.tty_command(val); return
        if addr in (CTL_TA1, CTL_TA2, CTL_TA3): self.ctl[addr] = val; return
        if addr in (CTL_FA1, CTL_FA2, CTL_FA3, CTL_FA4): self.ctl[addr] = val; return
        warn(f"store out of bounds {addr}")
    def enable_net(self):
        self.net = NetKit(self.stdout, self.mem)
    def enable_tty(self):
        self.tty = TTYKit(self)
    def tty_command(self, cmd):
        c = self.ctl
        if self.tty is None: c[CTL_TSTATUS] = 0; c[CTL_TR1] = 1; return
        try: r = self.tty.command(cmd, c[CTL_TA1], c[CTL_TA2], c[CTL_TA3])
        except EOFError_: r = (0, 1, 0, 0, 0)
        c[CTL_TSTATUS], c[CTL_TR1], c[CTL_TR2], c[CTL_TR3], c[CTL_TR4] = r
    def enable_fs(self, root=None):
        self.fs = FSKit(self, root)
    def fs_command(self, cmd):
        c = self.ctl
        if self.fs is None: c[CTL_FSTATUS] = 0; c[CTL_FR1] = 1; return     # EPERM: --fs not given
        r = self.fs.command(cmd, c[CTL_FA1], c[CTL_FA2], c[CTL_FA3], c[CTL_FA4])
        c[CTL_FSTATUS], c[CTL_FR1], c[CTL_FR2], c[CTL_FR3], c[CTL_FR4] = r
        if self.net is not None: self.net.out = self.stdout
    def net_command(self, cmd):
        c = self.ctl
        if self.net is None: c[CTL_NSTATUS] = 0; return
        st, r1, r2 = self.net.command(cmd, c[CTL_NA1], c[CTL_NA2], c[CTL_NA3], c[CTL_NA4])
        c[CTL_NSTATUS], c[CTL_NR1], c[CTL_NR2] = st, r1, r2
    # ---------------- undo history (kept in the host) ----------------
    def u_begin(self):
        self.u_suspend = 0; self.u_cov = (0, 0); self.redo.clear()
        if not self.groups or self.groups[-1][0]: self.groups.append([[], 0])
    def u_drop(self):
        self.groups.clear(); self.u_total = 0; self.u_suspend = 1; self.ctl[CTL_LOST] = 1; self.redo.clear()
    def u_rec(self, op, cost):
        if self.u_suspend: return
        if self.redo: self.redo.clear()
        if not self.groups: self.groups.append([[], 0])
        g = self.groups[-1]; g[0].append(op); g[1] += cost; self.u_total += cost
        while self.u_total > UNDO_CAP and len(self.groups) > 1:
            self.u_total -= self.groups.popleft()[1]
        if self.u_total > UNDO_CAP: self.u_drop()
    def u_apply(self, ops):
        """undo ops (last first); returns the ops that would put the bytes back (for redo / undo again)"""
        inv = []; size = 0
        for op in reversed(ops):
            k = op[0]
            if k == 'r':
                _, off, old, oldlen = op
                n = len(self.file)
                cur = bytes(self.file[off:]) if n > oldlen else bytes(self.file[off:off + len(old)])
                inv.append(('r', off, cur, n)); size += len(cur)
                self.file[off:off + len(old)] = old
                if len(self.file) > oldlen: del self.file[oldlen:]
            elif k == 'i':
                inv.append(('d', op[1], bytes(self.file[op[1]:op[1] + op[2]]))); size += op[2]
                del self.file[op[1]:op[1] + op[2]]
            elif k == 'd':
                inv.append(('i', op[1], len(op[2])))
                self.file[op[1]:op[1]] = op[2]
        return inv, size          # in the order applied: undoing them again goes last-first
    def u_undo(self):
        while self.groups and not self.groups[-1][0]: self.groups.pop()
        if not self.groups: return 0
        ops, cost = self.groups.pop(); self.u_total -= cost
        inv, size = self.u_apply(ops)
        if size <= UNDO_CAP // 4: self.redo.append((inv, 120 * len(inv) + size))
        else: self.redo.clear()
        self.u_cov = (0, 0)
        self.dirty = 1; self.ctl[CTL_R1] = len(ops); self.ctl[CTL_LOST] = 0
        return 1
    def u_redo(self):
        if not self.redo: return 0
        ops, cost = self.redo.pop()
        inv, size = self.u_apply(ops)
        self.groups.append([inv, 120 * len(inv) + size]); self.u_total += 120 * len(inv) + size
        while self.u_total > UNDO_CAP and len(self.groups) > 1:
            self.u_total -= self.groups.popleft()[1]
        self.u_suspend = 0; self.u_cov = (0, 0); self.dirty = 1; self.ctl[CTL_R1] = len(ops)
        return 1
    def u_checkpoint(self, off, ln):
        """new undo group holding one copy of file[off:off+ln]; stores inside that range are not
        recorded one by one until the next begin/checkpoint (one snapshot instead of a byte log)"""
        self.u_begin()
        n = len(self.file); old = bytes(self.file[off:min(off + ln, n)]) if off < n else b""
        self.u_rec(('r', off, old, n), 120 + len(old))
        self.u_cov = (off, off + ln)
        return 1
    def _prep(self, off, ln):
        """record the old bytes of file[off:off+ln], then zero-extend the file to cover the range"""
        n = len(self.file); op = None
        if ln <= 0: return None
        if ln > UNDO_CAP // 2: self.u_drop()
        else:
            old = bytes(self.file[off:min(off + ln, n)]) if off < n else b""
            op = ('r', off, old, n); self.u_rec(op, 120 + len(old))
        while n < off + ln:
            step = min(CHUNK, off + ln - n); self.file.extend(bytes(step)); n += step
        self.dirty = 1
        return op
    def _commit(self, op, off, ln):
        """if the operation changed nothing, take its undo record back out again"""
        if op is None or not self.groups: return
        ops, cost = self.groups[-1][0], self.groups[-1][1]
        if ops and ops[-1] is op and op[3] == len(self.file) and op[2] == bytes(self.file[off:off + ln]):
            ops.pop(); self.groups[-1][1] -= 120 + len(op[2]); self.u_total -= 120 + len(op[2])
    # ---------------- bulk commands ----------------
    def ctl_command(self, cmd):
        c = self.ctl; off, cnt, a3 = c[CTL_A1], c[CTL_A2], c[CTL_A3]
        n = len(self.file); c[CTL_STATUS] = 0
        if cmd == 7: self.u_begin(); c[CTL_STATUS] = 1
        elif cmd == 6: c[CTL_STATUS] = self.u_undo()
        elif cmd == 12: c[CTL_STATUS] = self.u_checkpoint(off, cnt) if 0 <= off and 0 <= cnt <= UNDO_CAP // 2 else 0
        elif cmd == 13: c[CTL_STATUS] = self.u_redo()
        elif cmd == 14: self.u_drop(); self.ctl[CTL_LOST] = 0; c[CTL_STATUS] = 1
        elif cmd == 1:
            path = self.savepath or self.filepath
            if not path: print("error: nothing to save to - use --file FILE or --save FILE", file=sys.stderr); return
            tmp = path + ".gatc-tmp"
            try:
                with open(tmp, "wb") as f: f.write(self.file)
                if os.path.exists(path):
                    import shutil; shutil.copymode(path, tmp)
                os.replace(tmp, path)
            except OSError as e:
                print(f"error: cannot write {path}: {e}", file=sys.stderr); return
            self.dirty = 0; c[CTL_STATUS] = 1
        elif cmd == 2:
            if 0 <= off <= n and 0 <= cnt <= GROW_CAP and n + cnt <= MAX_FILE:
                if cnt: self.u_rec(('i', off, cnt), 120); self.file[off:off] = bytes(cnt); self.dirty = 1
                c[CTL_R1] = cnt; c[CTL_STATUS] = 1
        elif cmd == 3:
            if 0 <= off < n and cnt >= 0:
                cnt = min(cnt, n - off); removed = bytes(self.file[off:off + cnt])
                if cnt:
                    if len(removed) > UNDO_CAP // 2: self.u_drop()
                    else: self.u_rec(('d', off, removed), 120 + len(removed))
                    del self.file[off:off + cnt]; self.dirty = 1
                c[CTL_R1] = cnt; c[CTL_STATUS] = 1
        elif cmd == 4:
            if 0 < cnt <= 64 and mem_ok(a3, cnt, len(self.mem)) and off >= 0:
                pat = bytes(v & 0xFF for v in self.mem[a3:a3 + cnt]); i = self.file.find(pat, off)
                if i >= 0: c[CTL_R1] = i; c[CTL_STATUS] = 1
        elif cmd == 5:
            if 0 <= off <= n and 0 <= cnt and off + cnt <= n:
                s = x = 0; crc = 0
                for p in range(off, off + cnt, CHUNK):
                    part = self.file[p:min(p + CHUNK, off + cnt)]
                    s += sum(part); crc = zlib.crc32(part, crc); x ^= xor_fold(part)
                c[CTL_R1], c[CTL_R2], c[CTL_R3] = s & 0xFF, x, crc; c[CTL_STATUS] = 1
        elif cmd == 8:
            if 0 <= off <= n and 0 <= cnt and off + cnt <= MAX_FILE:
                op = self._prep(off, cnt); v = a3 & 0xFF
                for p in range(off, off + cnt, CHUNK):
                    m = min(CHUNK, off + cnt - p); self.file[p:p + m] = bytes((v,)) * m
                self._commit(op, off, cnt); c[CTL_R1] = cnt; c[CTL_STATUS] = 1
        elif cmd == 9:
            if 0 <= off and 0 <= cnt and off + cnt <= n and 0 <= a3 <= n and a3 + cnt <= MAX_FILE:
                op = self._prep(a3, cnt)
                if a3 <= off or a3 >= off + cnt: starts = range(0, cnt, CHUNK)
                else: starts = range((cnt - 1) // CHUNK * CHUNK, -1, -CHUNK)
                for p in starts:
                    m = min(CHUNK, cnt - p); self.file[a3 + p:a3 + p + m] = self.file[off + p:off + p + m]
                self._commit(op, a3, cnt); c[CTL_R1] = cnt; c[CTL_STATUS] = 1
        elif cmd == 10:
            if 0 <= off and 0 <= cnt and off + cnt <= n:
                op = self._prep(off, cnt); tbl = bytes(i ^ (a3 & 0xFF) for i in range(256))
                for p in range(off, off + cnt, CHUNK):
                    m = min(CHUNK, off + cnt - p); self.file[p:p + m] = bytes(self.file[p:p + m]).translate(tbl)
                self._commit(op, off, cnt); c[CTL_R1] = cnt; c[CTL_STATUS] = 1
        elif cmd == 11:
            if 0 <= off <= MAX_FILE:
                if off < n:
                    removed = bytes(self.file[off:])
                    if len(removed) > UNDO_CAP // 2: self.u_drop()
                    else: self.u_rec(('d', off, removed), 120 + len(removed))
                    del self.file[off:]; self.dirty = 1
                elif off > n: self._prep(n, off - n)
                c[CTL_STATUS] = 1
        else: warn(f"unknown file command {cmd}")
    def push(self,n):
        if len(self.stack)>=STACK_LIMIT: warn("stack overflow; dropping push"); return
        self.stack.append(int(n))
    def pop(self):
        if not self.stack: warn(f"stack underflow at pc={self.pc}; using 0"); return 0
        return self.stack.pop()
    def run(self, max_steps=STEP_LIMIT_DEFAULT):
        n=len(self.program)
        if n==0: return 0
        while not self.halted:
            if self.steps>=max_steps: warn(f"step limit {max_steps} exceeded; stopping"); return self.exit_code
            if self.pc<0 or self.pc>=n: warn(f"pc {self.pc} out of range; stopping"); return self.exit_code
            self.steps+=1; self._exec(self.program[self.pc])
        return self.exit_code
    def _exec(self, ins):
        op=ins.name
        if op=="LIT": self.push(0 if ins.imm is None else ins.imm); self.pc+=1
        elif op=="ADD":
            b,a=self.pop(),self.pop(); self.push(a+b); self.pc+=1
        elif op=="SUB":
            b,a=self.pop(),self.pop(); self.push(a-b); self.pc+=1
        elif op=="MUL":
            b,a=self.pop(),self.pop(); self.push(a*b); self.pc+=1
        elif op=="DIV":
            b,a=self.pop(),self.pop(); self.push(0 if b==0 else a//b)
            if b==0: warn("division by zero; pushing 0")
            self.pc+=1
        elif op=="MOD":
            b,a=self.pop(),self.pop(); self.push(0 if b==0 else a%b)
            if b==0: warn("modulo by zero; pushing 0")
            self.pc+=1
        elif op in ("AND","OR","XOR"):
            b,a=self.pop(),self.pop(); self.push({"AND":a&b,"OR":a|b,"XOR":a^b}[op]); self.pc+=1
        elif op=="INV": self.push(~self.pop()); self.pc+=1
        elif op=="NOT": self.push(1 if self.pop()==0 else 0); self.pc+=1
        elif op=="NEG": self.push(-self.pop()); self.pc+=1
        elif op=="EQ":
            b,a=self.pop(),self.pop(); self.push(1 if a==b else 0); self.pc+=1
        elif op=="LT":
            b,a=self.pop(),self.pop(); self.push(1 if a<b else 0); self.pc+=1
        elif op=="GT":
            b,a=self.pop(),self.pop(); self.push(1 if a>b else 0); self.pc+=1
        elif op=="NE":
            b,a=self.pop(),self.pop(); self.push(1 if a!=b else 0); self.pc+=1
        elif op=="GE":
            b,a=self.pop(),self.pop(); self.push(1 if a>=b else 0); self.pc+=1
        elif op=="LE":
            b,a=self.pop(),self.pop(); self.push(1 if a<=b else 0); self.pc+=1
        elif op=="MAX":
            b,a=self.pop(),self.pop(); self.push(a if a>b else b); self.pc+=1
        elif op=="MIN":
            b,a=self.pop(),self.pop(); self.push(a if a<b else b); self.pc+=1
        elif op=="ABS": self.push(abs(self.pop())); self.pc+=1
        elif op=="SIGN":
            a=self.pop(); self.push((a>0)-(a<0)); self.pc+=1
        elif op=="BOOL": self.push(0 if self.pop()==0 else 1); self.pc+=1
        elif op=="ZERO": self.push(0); self.pc+=1
        elif op=="ONE": self.push(1); self.pc+=1
        elif op=="DUP": self.push(self.stack[-1] if self.stack else 0); self.pc+=1
        elif op=="SWAP":
            b,a=self.pop(),self.pop(); self.push(b); self.push(a); self.pc+=1
        elif op=="OVER": self.push(self.stack[-2] if len(self.stack)>=2 else 0); self.pc+=1
        elif op=="DROP": self.pop(); self.pc+=1
        elif op=="NIP":
            b=self.pop(); self.pop(); self.push(b); self.pc+=1
        elif op=="ROT":
            if len(self.stack)<3: warn("ROT underflow")
            else:
                c,b,a=self.stack.pop(),self.stack.pop(),self.stack.pop(); self.push(b); self.push(c); self.push(a)
            self.pc+=1
        elif op=="NROLL":
            if len(self.stack)<3: warn("NROLL underflow")
            else:
                c,b,a=self.stack.pop(),self.stack.pop(),self.stack.pop(); self.push(c); self.push(a); self.push(b)
            self.pc+=1
        elif op=="TUCK":
            if len(self.stack)<2: warn("TUCK underflow")
            else: self.stack.insert(-2, self.stack[-1])
            self.pc+=1
        elif op=="UNDER":
            if len(self.stack)<2: warn("UNDER underflow")
            else: self.stack.insert(-1, self.stack[-2])
            self.pc+=1
        elif op=="PICK":
            n=self.pop(); self.push(self.stack[-1-n] if 0<=n<len(self.stack) else 0); self.pc+=1
        elif op=="DDUP":
            if len(self.stack)<2: warn("DDUP underflow")
            else: self.push(self.stack[-2]); self.push(self.stack[-1])
            self.pc+=1
        elif op=="DDROP": self.pop(); self.pop(); self.pc+=1
        elif op=="TSWP":
            if len(self.stack)<4: warn("TSWP underflow")
            else:
                d,c,b,a=self.stack.pop(),self.stack.pop(),self.stack.pop(),self.stack.pop()
                self.push(c); self.push(d); self.push(a); self.push(b)
            self.pc+=1
        elif op=="TOR":
            if len(self.calls)>=CALL_LIMIT: warn("return stack overflow"); self.pop()
            else: self.calls.append(self.pop())
            self.pc+=1
        elif op=="RFROM":
            self.push(self.calls.pop() if self.calls else 0); self.pc+=1
        elif op=="RDROP":
            if self.calls: self.calls.pop()
            else: warn("RDROP on empty return stack")
            self.pc+=1
        elif op=="INC": self.push(self.pop()+1); self.pc+=1
        elif op=="DEC": self.push(self.pop()-1); self.pc+=1
        elif op=="DEPTH": self.push(len(self.stack)); self.pc+=1
        elif op=="SHL":
            b,a=self.pop(),self.pop(); self.push(a<<(b&31)); self.pc+=1
        elif op=="SHR":
            b,a=self.pop(),self.pop(); self.push(a>>(b&31)); self.pc+=1
        elif op=="FETCH":
            self.push(self.fetch(self.pop())); self.pc+=1
        elif op=="STORE":
            addr,val=self.pop(),self.pop(); self.store(addr,val); self.pc+=1
        elif op=="PSTO":
            addr=self.pop()
            if 0<=addr<HOLE_LO or HOLE_HI<=addr<MEM_SIZE: self.mem[addr]+=1
            else: warn(f"psto out of bounds {addr}")
            self.pc+=1
        elif op=="MADD":
            addr,n=self.pop(),self.pop()
            if 0<=addr<HOLE_LO or HOLE_HI<=addr<MEM_SIZE: self.mem[addr]+=n
            else: warn(f"madd out of bounds {addr}")
            self.pc+=1
        elif op=="PUTC":
            self.stdout.write(chr(self.pop()&0xFF)); self.stdout.flush(); self.pc+=1
        elif op=="PUTN":
            self.stdout.write(str(self.pop())); self.stdout.flush(); self.pc+=1
        elif op=="CR":
            self.stdout.write("\n"); self.stdout.flush(); self.pc+=1
        elif op=="IN":
            line=self.stdin.readline()
            if line=="": self.push(-1)
            else:
                try: self.push(int(line.strip()))
                except ValueError: self.push(0)
            self.pc+=1
        elif op=="GETC":
            ch=self.stdin.read(1); self.push(ord(ch) if ch else -1); self.pc+=1
        elif op=="RAND":
            n=self.pop(); self.push(0 if n<=0 else random.randrange(n)); self.pc+=1
        elif op=="JMP":
            addr=self.pop()
            if self.genome: warn("JMP in genome; walking forward"); self.pc+=1
            elif isinstance(addr,int) and 0<=addr<len(self.program): self.pc=addr
            else: warn(f"bad jump {addr}; skipping"); self.pc+=1
        elif op=="JZ":
            addr,flag=self.pop(),self.pop()
            if self.genome: warn("JZ in genome; walking forward"); self.pc+=1
            else: self.pc = addr if flag==0 and 0<=addr<len(self.program) else self.pc+1
        elif op=="JNZ":
            addr,flag=self.pop(),self.pop()
            if self.genome: warn("JNZ in genome; walking forward"); self.pc+=1
            else: self.pc = addr if flag!=0 and 0<=addr<len(self.program) else self.pc+1
        elif op=="CALL":
            addr=self.pop()
            if self.genome: warn("CALL in genome; walking forward"); self.pc+=1
            elif len(self.calls)>=CALL_LIMIT or not (0<=addr<len(self.program)):
                warn(f"bad call {addr}; skipping"); self.pc+=1
            else: self.calls.append(self.pc+1); self.pc=addr
        elif op=="RET":
            if self.genome or not self.calls:
                if not self.calls: warn("return without CALL; ignoring")
                self.pc+=1
            else: self.pc=self.calls.pop()
        elif op=="NOP": self.pc+=1
        elif op=="HALT":
            if self.genome:
                if not self._halt_note: warn("HALT in genome; continuing"); self._halt_note=True
                self.pc+=1
            else: self.halted=True
        elif op=="QUIT":
            code=self.pop()
            if self.genome: warn(f"QUIT {code} in genome; continuing"); self.pc+=1
            else: self.exit_code=code; self.halted=True
        else: warn(f"unknown op {op}; nop"); self.pc+=1
# =========================================================================================
#  GenomeOS machine  (python3 GATCnux.py boot genome.img)
#
#  The machine boots a disk image.  Process 0 is the kernel, a GATC program read from the
#  image.  It runs user processes with RUN(pid, quantum): the user process executes until its
#  time slice ends or it needs the kernel (PUTC GETC PUTN CR IN HALT QUIT, or a store to a
#  bridge command cell 4112 / 4128 / 4144).  Then RUN returns the event to the kernel, which
#  services it and runs the next process.  Each process has its own code, 64K cells of RAM,
#  its own file-backed byte space (65536+) and its own copies of the bridge cells, so the
#  existing programs keep their ABI: the kernel answers their fs / tty calls itself.
#
#  Kernel device cells (in the kernel only; 4096..4159):
#    4096 command  4097-4102 arguments  4103 status (1 ok)  4104-4109 results  4110 magic 30303
#    1  RUN(pid, quantum)        r1 event  r2 r3 data  r4 steps used
#         events 1 timer  2 exit(r2 code)  3 putc(r2)  4 putn(r2)  5 cr  6 getc  7 in  10 output
#         collected (r2 bytes: PUTC/PUTN/CR are gathered by the machine, up to 512, see 26)
#                8 device(r2 cell, r3 value)  9 fault(r2: 1 bad pc 2 internal error)
#    2  PUSH(pid, value)         push a value on the process stack (answer to getc / in)
#    3  SPAWN(kaddr, n)          new process from n bytes of kernel memory (GATC bytecode or
#                                a FASTA genome); r1 pid.   4 KILL(pid)
#    5  PGET(pid, addr) r1       6 PPUT(pid, addr, value)
#    7  COPYIN(pid, paddr, kaddr, n)   8 COPYOUT(kaddr, pid, paddr, n)
#    9  DREAD(block, count, kaddr)    10 DWRITE(block, count, kaddr)   (512-byte blocks,
#                                one byte per cell)   11 DINFO r1 blocks r2 block size
#    12 CWRITE(kaddr, n) bytes to the console   13 CKEY(timeout ms, 0 = wait) status 0 =
#       none (r1 1 at end of input), else r1 key (as tty key: 1001.. arrows, 2000 mouse) r2-r4
#    14 CSIZE r1 cols r2 rows   15 CRAW(on)   16 TICKS r1 ms   17 SLEEP(ms)
#    18 PINFO(pid) r1 alive r2 steps r3 stack depth   19 POWEROFF(code)
#    20 KCOPY(src, dst, n) inside kernel memory   21 KFILL(addr, n, value)
#    22 PSTR(pid, paddr, kaddr, max) NUL-terminated string from a process, r1 length
#    23 TIME r1 seconds since 1970 r2 UTC offset   24 STRERR(errno, kaddr, max) r1 length
#    25 FEED(pid, kaddr, n) bytes its next GETCs return   26 TAKEOUT(pid, kaddr) r1 n: its output
# =========================================================================================
GOS_MAGIC = 30303
BLOCK = 512
K_CMD = 4096; K_A = range(4097, 4103); K_ST = 4103; K_R = range(4104, 4110); K_MAGIC = 4110
EV_TIMER, EV_EXIT, EV_PUTC, EV_PUTN, EV_CR, EV_GETC, EV_IN, EV_DEV, EV_FAULT, EV_PUTS = range(1, 11)
OUTBUF_MAX = 512
TRAP_CELLS = (CTL_NCMD, CTL_FCMD, CTL_TCMD)

class Trap(Exception):
    def __init__(self, ev, a=0, b=0): self.ev, self.a, self.b = ev, a, b

class ProcVM(VM):
    """a user process: bridge cells are private copies, I/O and bridge commands trap"""
    def __init__(self, program):
        super().__init__(program, stdin=io.StringIO(), stdout=io.StringIO())
        self.shadow = {CTL_NMAGIC: 1, CTL_FMAGIC: 1, CTL_TMAGIC: 1}
        self.inbuf = bytearray(); self.inpos = 0      # bytes the kernel handed over in advance (FEED)
        self.outbuf = bytearray(); self.pending = None  # output collected for the kernel (EV_PUTS)
    def fetch(self, addr):
        if 0 <= addr < HOLE_LO or HOLE_HI <= addr < MEM_SIZE: return self.mem[addr]
        if addr >= FILE_BASE or CTL_CMD <= addr <= CTL_LOST: return VM.fetch(self, addr)
        return self.shadow.get(addr, 0)
    def store(self, addr, val):
        if 0 <= addr < HOLE_LO or HOLE_HI <= addr < MEM_SIZE: self.mem[addr] = val; return
        if addr >= FILE_BASE or CTL_CMD <= addr <= CTL_LOST: VM.store(self, addr, val); return
        if HOLE_LO <= addr < HOLE_HI:
            self.shadow[addr] = val
            if addr in TRAP_CELLS: raise Trap(EV_DEV, addr, val)
            return
        warn(f"store out of bounds {addr}")
    def _exec(self, ins):
        op = ins.name
        if op == "PUTC":
            self.pc += 1; self.outbuf.append(self.pop() & 0xFF)
            if len(self.outbuf) >= OUTBUF_MAX: raise Trap(EV_PUTS)
            return
        if op == "PUTN":
            self.pc += 1; self.outbuf += str(self.pop()).encode()
            if len(self.outbuf) >= OUTBUF_MAX: raise Trap(EV_PUTS)
            return
        if op == "CR":
            self.pc += 1; self.outbuf.append(10)
            if len(self.outbuf) >= OUTBUF_MAX: raise Trap(EV_PUTS)
            return
        if op == "GETC":
            self.pc += 1
            if self.inpos < len(self.inbuf):
                self.push(self.inbuf[self.inpos]); self.inpos += 1
                if self.inpos >= len(self.inbuf): self.inbuf = bytearray(); self.inpos = 0
                return
            raise Trap(EV_GETC)
        if op == "IN": self.pc += 1; raise Trap(EV_IN)
        if op == "HALT": self.pc += 1; self.halted = True; raise Trap(EV_EXIT, 0)
        if op == "QUIT": self.pc += 1; self.halted = True; raise Trap(EV_EXIT, self.pop())
        try: VM._exec(self, ins)
        except Trap: self.pc += 1; raise
    def mget(self, a):
        if 0 <= a < MEM_SIZE: return self.mem[a] if ram(a) else self.shadow.get(a, 0) if not (CTL_CMD <= a <= CTL_LOST) else VM.fetch(self, a)
        if a >= FILE_BASE: i = a - FILE_BASE; return self.file[i] if i < len(self.file) else 0
        return 0
    def mset(self, a, v):
        if ram(a): self.mem[a] = v
        elif a >= FILE_BASE: VM.store(self, a, v)
        elif HOLE_LO <= a < HOLE_HI: self.shadow[a] = v

class KernelVM(VM):
    """process 0: its device window is the machine"""
    def __init__(self, program, machine):
        super().__init__(program); self.machine = machine; self.kc = {}
    def fetch(self, addr):
        if 0 <= addr < HOLE_LO or HOLE_HI <= addr < MEM_SIZE: return self.mem[addr]
        if addr >= FILE_BASE: i = addr - FILE_BASE; return self.file[i] if i < len(self.file) else 0
        if addr == K_MAGIC: return GOS_MAGIC
        return self.kc.get(addr, 0)
    def store(self, addr, val):
        if 0 <= addr < HOLE_LO or HOLE_HI <= addr < MEM_SIZE: self.mem[addr] = val; return
        if addr >= FILE_BASE:
            i = addr - FILE_BASE
            if i < MAX_FILE:
                if i >= len(self.file): self.file.extend(bytes(i - len(self.file) + 1))
                self.file[i] = val & 0xFF
            return
        if addr == K_CMD: self.machine.command(val); return
        if HOLE_LO <= addr < HOLE_HI: self.kc[addr] = val; return
        warn(f"store out of bounds {addr}")
    def kget(self, a):
        if ram(a): return self.mem[a]
        if a >= FILE_BASE: i = a - FILE_BASE; return self.file[i] if i < len(self.file) else 0
        return 0
    def kbytes(self, a, n):
        if a >= FILE_BASE:
            i = a - FILE_BASE; b = bytes(self.file[i:i + n]); return b + bytes(n - len(b))
        return bytes(self.kget(a + j) & 0xFF for j in range(n))
    def kput(self, a, data):
        if a >= FILE_BASE:
            i = a - FILE_BASE
            if i + len(data) > MAX_FILE: raise OSError(14, "bad address")
            if i + len(data) > len(self.file): self.file.extend(bytes(i + len(data) - len(self.file)))
            self.file[i:i + len(data)] = data; return
        if not mem_ok(a, len(data)): raise OSError(14, "bad address")
        for j, v in enumerate(data): self.mem[a + j] = v

def load_program_bytes(data):
    """bytecode, or a FASTA / plain-DNA genome, or .aa source text -> program"""
    head = data[:1]
    if head == b">" or (data[:64].strip() and all(c in b"ACGTacgtUuNn\r\n " for c in data[:64])):
        prog, _ = compile_source(data.decode("ascii", "replace"), "genome.fa"); return prog
    return decode_bytecode(data)

class Machine:
    def __init__(self, image, stdin=None, stdout=None):
        self.path = image
        self.img = open(image, "r+b")
        self.size = os.path.getsize(image)
        sb = self.read(0, 1)
        if sb[:8] != b"GENOMEOS": raise GATCError(f"{image} is not a GenomeOS image (no GENOMEOS superblock)")
        u = lambda o: int.from_bytes(sb[o:o + 4], "little")
        koff, klen = u(20), u(24)
        self.img.seek(koff); kern = self.img.read(klen)
        self.kernel = KernelVM(load_program_bytes(kern), self)
        if stdin is not None: self.kernel.stdin = stdin
        if stdout is not None: self.kernel.stdout = stdout
        self.tty = TTYKit(self.kernel)
        self.procs = {}; self.next_pid = 1; self.poweroff = None; self.t0 = time.time()
    def read(self, block, count):
        self.img.seek(block * BLOCK); d = self.img.read(count * BLOCK); return d + bytes(count * BLOCK - len(d))
    def command(self, cmd):
        k = self.kernel; a = [k.kc.get(i, 0) for i in K_A]
        try:
            self._st = 1
            r = getattr(self, "k%d" % cmd)(*a)
            r = () if r is None else r
            k.kc[K_ST] = self._st
        except (OSError, GATCError, KeyError, ValueError, IndexError) as e:
            r = (getattr(e, "errno", None) or 5,); k.kc[K_ST] = 0
        for i, reg in enumerate(K_R): k.kc[reg] = r[i] if i < len(r) else 0
    def proc(self, pid):
        p = self.procs.get(pid)
        if p is None: raise KeyError(pid)
        return p
    # ---- processes
    def k1(self, pid, quantum, *_):
        """run a process; collected output is always reported (EV_PUTS) before anything else"""
        p = self.proc(pid); prog = p.program; n = len(prog); s0 = p.steps
        if p.pending is not None:
            t = p.pending; p.pending = None; return (t.ev, t.a, t.b, 0)
        end = s0 + max(1, quantum)
        try:
            while p.steps < end:
                if not 0 <= p.pc < n: raise Trap(EV_FAULT, 1, p.pc)
                p.steps += 1; p._exec(prog[p.pc])
            t = Trap(EV_TIMER)
        except Trap as e: t = e
        except RecursionError: t = Trap(EV_FAULT, 2, p.pc)
        if p.outbuf and t.ev != EV_PUTS:
            if t.ev != EV_TIMER: p.pending = t
            t = Trap(EV_PUTS)
        if t.ev == EV_PUTS: return (EV_PUTS, len(p.outbuf), 0, p.steps - s0)
        return (t.ev, t.a, t.b, p.steps - s0)
    def k25(self, pid, kaddr, n, *_):
        """FEED: bytes of kernel memory become the process's next GETC results"""
        p = self.proc(pid); k = self.kernel
        if not 0 <= n <= 65536: raise OSError(22, "bad length")
        data = k.kbytes(kaddr, n) if kaddr >= FILE_BASE else bytes(k.kget(kaddr + j) & 0xFF for j in range(n))
        if p.inpos: p.inbuf = p.inbuf[p.inpos:]; p.inpos = 0
        p.inbuf += data
    def k26(self, pid, kaddr, *_):
        """TAKEOUT: the process's collected output into kernel memory; r1 length"""
        p = self.proc(pid); d = bytes(p.outbuf); p.outbuf = bytearray()
        if kaddr >= FILE_BASE: self.kernel.kput(kaddr, d)
        else:
            for j, v in enumerate(d): self.kernel.store(kaddr + j, v)
        return (len(d),)
    def k2(self, pid, value, *_): self.proc(pid).push(value)
    def k3(self, kaddr, n, *_):
        prog = load_program_bytes(self.kernel.kbytes(kaddr, n))
        if not prog: raise GATCError("empty program")
        pid = self.next_pid; self.next_pid += 1
        self.procs[pid] = ProcVM(prog)
        return (pid,)
    def k4(self, pid, *_): self.procs.pop(pid, None)
    def k5(self, pid, addr, *_): return (self.proc(pid).mget(addr),)
    def k6(self, pid, addr, value, *_): self.proc(pid).mset(addr, value)
    def k7(self, pid, paddr, kaddr, n, *_):
        p = self.proc(pid)
        if not 0 <= n <= 1 << 20: raise OSError(22, "bad length")
        if paddr >= FILE_BASE:
            i = paddr - FILE_BASE; d = bytes(p.file[i:i + n]); d += bytes(n - len(d))
            self.kernel.kput(kaddr, d) if kaddr >= FILE_BASE else [self.kernel.store(kaddr + j, d[j]) for j in range(n)]
        else:
            vals = [p.mget(paddr + j) for j in range(n)]
            if kaddr >= FILE_BASE: self.kernel.kput(kaddr, bytes(v & 0xFF for v in vals))
            elif mem_ok(kaddr, n): self.kernel.mem[kaddr:kaddr + n] = vals
            else: raise OSError(14, "bad address")
    def k8(self, kaddr, pid, paddr, n, *_):
        p = self.proc(pid)
        if not 0 <= n <= 1 << 20: raise OSError(22, "bad length")
        k = self.kernel
        vals = list(k.kbytes(kaddr, n)) if kaddr >= FILE_BASE else [k.kget(kaddr + j) for j in range(n)]
        if paddr >= FILE_BASE:
            i = paddr - FILE_BASE
            if i + n > len(p.file): p.file.extend(bytes(i + n - len(p.file)))
            p.file[i:i + n] = bytes(v & 0xFF for v in vals)
        elif mem_ok(paddr, n): p.mem[paddr:paddr + n] = vals
        else: raise OSError(14, "bad address")
    def k22(self, pid, paddr, kaddr, mx, *_):
        p = self.proc(pid); out = []
        while len(out) < mx:
            v = p.mget(paddr + len(out))
            if v == 0: break
            out.append(v)
        for j, v in enumerate(out + [0]): self.kernel.store(kaddr + j, v) if not ram(kaddr + j) else self.kernel.mem.__setitem__(kaddr + j, v)
        return (len(out),)
    def k18(self, pid, *_):
        p = self.procs.get(pid)
        return (0, 0, 0) if p is None else (1, p.steps, len(p.stack))
    # ---- disk
    def k9(self, block, count, kaddr, *_):
        if block < 0 or count < 0 or (block + count) * BLOCK > self.size: raise OSError(5, "past the end of the disk")
        self.kernel.kput(kaddr, self.read(block, count))
    def k10(self, block, count, kaddr, *_):
        if block < 0 or count < 0 or (block + count) * BLOCK > self.size: raise OSError(5, "past the end of the disk")
        self.img.seek(block * BLOCK); self.img.write(self.kernel.kbytes(kaddr, count * BLOCK)); self.img.flush()
    def k11(self, *_): return (self.size // BLOCK, BLOCK)
    # ---- console, clock
    def k12(self, kaddr, n, *_):
        if not 0 <= n <= 1 << 20: raise OSError(22, "bad length")
        self.tty.out(self.kernel.kbytes(kaddr, n))
    def k13(self, timeout, *_):
        t = self.tty
        try:
            if timeout < 0:                      # -1: only look, never wait
                if t.eof: raise EOFError_()
                b = t.readbyte(0)
                if b is None: r = (0, 0, 0, 0, 0)
                elif b == b"": t.eof = True; raise EOFError_()
                else:
                    d = tuple(t.decode(b)); r = (1,) + d + (0,) * (4 - len(d))
            else: r = t.command(2, timeout, 0, 0)
        except EOFError_: r = (0, 1, 0, 0, 0)
        self._st = r[0]
        return r[1:]
    def k14(self, *_): return self.tty.command(4, 0, 0, 0)[1:3]
    def k15(self, on, *_):
        """raw console; also turns off the terminal's own Ctrl+C / Ctrl+Z so the kernel gets them"""
        self.tty.command(1, on, 0, 0)
        if on and self.tty.is_tty and not self.tty.win:
            import termios
            try:
                at = termios.tcgetattr(self.tty.fd); at[3] &= ~(termios.ISIG | termios.IEXTEN)
                at[0] &= ~termios.IXON; termios.tcsetattr(self.tty.fd, termios.TCSADRAIN, at)
            except (OSError, termios.error): pass
    def k16(self, *_): return (int((time.time() - self.t0) * 1000),)
    def k17(self, ms, *_): time.sleep(max(0, min(ms, 60000)) / 1000)
    def k23(self, *_):
        now = int(time.time()); return (now, time.localtime(now).tm_gmtoff or 0)
    def k24(self, errno, kaddr, mx, *_):
        b = os.strerror(errno).encode("utf-8", "replace")[:max(0, mx - 1)] + b"\0"
        self.kernel.kput(kaddr, b); return (len(b) - 1,)
    def k19(self, code, *_): self.poweroff = code; self.kernel.halted = True; self.kernel.exit_code = code
    def k20(self, src, dst, n, *_):
        k = self.kernel; d = k.kbytes(src, n) if src >= FILE_BASE else [k.kget(src + j) for j in range(n)]
        if dst >= FILE_BASE: k.kput(dst, bytes(v & 0xFF for v in d))
        elif mem_ok(dst, n): k.mem[dst:dst + n] = list(d)
        else: raise OSError(14, "bad address")
    def k21(self, addr, n, value, *_):
        k = self.kernel
        if addr >= FILE_BASE: k.kput(addr, bytes([value & 0xFF]) * n)
        elif mem_ok(addr, n): k.mem[addr:addr + n] = [value] * n
        else: raise OSError(14, "bad address")
    def boot(self, max_steps):
        try: return self.kernel.run(max_steps=max_steps)
        finally:
            self.tty.close(); self.img.close()

def cmd_boot(argv):
    import argparse
    p = argparse.ArgumentParser(prog="GATCnux.py boot", description="boot a GenomeOS disk image")
    p.add_argument("image"); p.add_argument("--max-steps", type=int, default=10**12)
    a = p.parse_args(argv)
    try: m = Machine(a.image)
    except (OSError, GATCError) as e: print(f"boot: {e}", file=sys.stderr); return 1
    try: code = m.boot(a.max_steps)
    except KeyboardInterrupt: print("\n[GenomeOS: interrupted]", file=sys.stderr); return 130
    return code or 0

# =========================================================================================
#  GenomeFS (disk format 2)  -  512-byte blocks, all numbers little-endian 32-bit
#    block 0       superblock: "GENOMEOS", 8 version 2, 12 block size, 16 blocks,
#                  20 kernel byte offset, 24 kernel length, 28 map start, 32 map blocks,
#                  36 inode start, 40 inode count, 44 inode blocks, 48 data start, 52 root inode
#    kernel area   the kernel program (bytecode), read by the machine at boot
#    block map     one byte per block: 0 free, 1 used
#    inode table   128-byte inodes, inode n at byte n*128 (0 unused, 1 = /):
#                  0 type (0 free 1 file 2 dir)  4 size  8 mtime  12 mode  16 links
#                  20-115 direct blocks [24]  116 indirect  120 double indirect
#    directories   64-byte entries: 0 inode (0 = empty slot), 4 name (NUL-terminated, <= 59)
# =========================================================================================
GFS_INODE = 128; GFS_DIRENT = 64; GFS_NDIRECT = 24; GFS_PER = BLOCK // 4

class GenomeFS:
    def __init__(self, path):
        self.path = path; self.f = open(path, "r+b")
        sb = self.blk(0)
        if sb[:8] != b"GENOMEOS": raise GATCError(f"{path}: not a GenomeOS disk")
        u = lambda o: int.from_bytes(sb[o:o + 4], "little")
        if u(8) < 2: raise GATCError(f"{path}: an old (phase 0/1) disk - it has no file system; rebuild it with mkimage")
        self.total, self.mstart, self.mblocks, self.istart, self.icount, self.iblocks, self.dstart = \
            u(16), u(28), u(32), u(36), u(40), u(44), u(48)
        self.map = bytearray(self.read(self.mstart, self.mblocks))
        self.inodes = bytearray(self.read(self.istart, self.iblocks))
    # ---- raw blocks
    def read(self, b, n=1):
        self.f.seek(b * BLOCK); d = self.f.read(n * BLOCK); return d + bytes(n * BLOCK - len(d))
    def blk(self, b): return self.read(b, 1)
    def write(self, b, data):
        self.f.seek(b * BLOCK); self.f.write(bytes(data).ljust(BLOCK, b"\0")[:BLOCK])
    def flush(self):
        self.f.seek(self.mstart * BLOCK); self.f.write(self.map)
        self.f.seek(self.istart * BLOCK); self.f.write(self.inodes); self.f.flush()
    def close(self): self.flush(); self.f.close()
    # ---- allocation
    def balloc(self):
        for b in range(self.dstart, self.total):
            if not self.map[b]:
                self.map[b] = 1; self.write(b, b""); return b
        raise GATCError("disk full")
    def bfree(self, b):
        if self.dstart <= b < self.total: self.map[b] = 0
    def ialloc(self, typ):
        for n in range(1, self.icount):
            if self.ival(n, 0) == 0:
                self.inodes[n * GFS_INODE:(n + 1) * GFS_INODE] = bytes(GFS_INODE)
                self.iset(n, 0, typ); self.iset(n, 16, 1); self.iset(n, 12, 0o755 if typ == 2 else 0o644)
                self.iset(n, 8, int(time.time())); return n
        raise GATCError("no free inodes")
    def ival(self, n, off): return int.from_bytes(self.inodes[n * GFS_INODE + off:n * GFS_INODE + off + 4], "little")
    def iset(self, n, off, v): self.inodes[n * GFS_INODE + off:n * GFS_INODE + off + 4] = int(v).to_bytes(4, "little")
    # ---- block map of a file
    def ptr(self, pb, i, alloc):
        d = bytearray(self.blk(pb)); v = int.from_bytes(d[i * 4:i * 4 + 4], "little")
        if v == 0 and alloc:
            v = self.balloc(); d[i * 4:i * 4 + 4] = v.to_bytes(4, "little"); self.write(pb, d)
        return v
    def bmap(self, n, lb, alloc=False):
        if lb < GFS_NDIRECT:
            v = self.ival(n, 20 + 4 * lb)
            if v == 0 and alloc: v = self.balloc(); self.iset(n, 20 + 4 * lb, v)
            return v
        lb -= GFS_NDIRECT
        if lb < GFS_PER:
            ind = self.ival(n, 116)
            if ind == 0:
                if not alloc: return 0
                ind = self.balloc(); self.iset(n, 116, ind)
            return self.ptr(ind, lb, alloc)
        lb -= GFS_PER
        if lb >= GFS_PER * GFS_PER: raise GATCError("file too big for GenomeFS (about 8 MB)")
        dbl = self.ival(n, 120)
        if dbl == 0:
            if not alloc: return 0
            dbl = self.balloc(); self.iset(n, 120, dbl)
        mid = self.ptr(dbl, lb // GFS_PER, alloc)
        return self.ptr(mid, lb % GFS_PER, alloc) if mid else 0
    def read_file(self, n):
        size = self.ival(n, 4); out = bytearray()
        for lb in range((size + BLOCK - 1) // BLOCK):
            p = self.bmap(n, lb); out += self.blk(p) if p else bytes(BLOCK)
        return bytes(out[:size])
    def truncate(self, n):
        for i in range(GFS_NDIRECT): self.bfree(self.ival(n, 20 + 4 * i)); self.iset(n, 20 + 4 * i, 0)
        ind = self.ival(n, 116)
        if ind:
            d = self.blk(ind)
            for i in range(GFS_PER): self.bfree(int.from_bytes(d[i * 4:i * 4 + 4], "little"))
            self.bfree(ind)
        dbl = self.ival(n, 120)
        if dbl:
            d = self.blk(dbl)
            for i in range(GFS_PER):
                mid = int.from_bytes(d[i * 4:i * 4 + 4], "little")
                if mid:
                    m = self.blk(mid)
                    for j in range(GFS_PER): self.bfree(int.from_bytes(m[j * 4:j * 4 + 4], "little"))
                    self.bfree(mid)
            self.bfree(dbl)
        self.iset(n, 116, 0); self.iset(n, 120, 0); self.iset(n, 4, 0)
    def write_file(self, n, data):
        self.truncate(n)
        for lb in range((len(data) + BLOCK - 1) // BLOCK):
            self.write(self.bmap(n, lb, True), data[lb * BLOCK:(lb + 1) * BLOCK])
        self.iset(n, 4, len(data)); self.iset(n, 8, int(time.time()))
    # ---- directories
    def entries(self, n):
        d = self.read_file(n); out = []
        for i in range(len(d) // GFS_DIRENT):
            e = d[i * GFS_DIRENT:(i + 1) * GFS_DIRENT]; ino = int.from_bytes(e[:4], "little")
            if ino: out.append((e[4:].split(b"\0")[0].decode("utf-8", "replace"), ino))
        return out
    def lookup(self, path):
        n = 1
        for part in [p for p in path.split("/") if p and p != "."]:
            if self.ival(n, 0) != 2: return 0
            hit = [i for nm, i in self.entries(n) if nm == part]
            if not hit: return 0
            n = hit[0]
        return n
    def add_entry(self, d, name, ino):
        nb = name.encode()
        if not nb or len(nb) > 59 or b"/" in nb: raise GATCError(f"bad name {name!r}")
        data = bytearray(self.read_file(d)); e = ino.to_bytes(4, "little") + nb.ljust(60, b"\0")
        for i in range(len(data) // GFS_DIRENT):
            if int.from_bytes(data[i * 64:i * 64 + 4], "little") == 0:
                data[i * 64:(i + 1) * 64] = e; break
        else: data += e
        self.write_file(d, bytes(data))
    def remove_entry(self, d, name):
        data = bytearray(self.read_file(d))
        for i in range(len(data) // GFS_DIRENT):
            e = data[i * 64:(i + 1) * 64]
            if int.from_bytes(e[:4], "little") and e[4:].split(b"\0")[0].decode() == name:
                data[i * 64:(i + 1) * 64] = bytes(64); self.write_file(d, bytes(data)); return True
        return False
    def mkdirs(self, path):
        n = 1
        for part in [p for p in path.split("/") if p and p != "."]:
            hit = [i for nm, i in self.entries(n) if nm == part]
            if hit:
                n = hit[0]
                if self.ival(n, 0) != 2: raise GATCError(f"{part} is a file, not a directory")
            else:
                c = self.ialloc(2); self.add_entry(n, part, c); n = c
        return n
    def put(self, path, data):
        parent, _, name = path.rstrip("/").rpartition("/")
        d = self.mkdirs(parent)
        n = self.lookup(path)
        if n and self.ival(n, 0) != 1: raise GATCError(f"{path} is a directory")
        if not n: n = self.ialloc(1); self.add_entry(d, name, n)
        self.write_file(n, data)
    def remove(self, path):
        n = self.lookup(path)
        if not n or n == 1: raise GATCError(f"{path}: no such file")
        if self.ival(n, 0) == 2 and self.entries(n): raise GATCError(f"{path}: directory not empty")
        parent, _, name = path.rstrip("/").rpartition("/")
        self.remove_entry(self.lookup(parent or "/"), name)
        links = self.ival(n, 16) - 1; self.iset(n, 16, links)
        if links <= 0: self.truncate(n); self.inodes[n * GFS_INODE:(n + 1) * GFS_INODE] = bytes(GFS_INODE)
    def free_blocks(self): return sum(1 for b in range(self.dstart, self.total) if not self.map[b])
    def blocks_of(self, n):
        out = [self.ival(n, 20 + 4 * i) for i in range(GFS_NDIRECT)]
        ind = self.ival(n, 116)
        if ind:
            out.append(ind); d = self.blk(ind); out += [int.from_bytes(d[i * 4:i * 4 + 4], "little") for i in range(GFS_PER)]
        dbl = self.ival(n, 120)
        if dbl:
            out.append(dbl); d = self.blk(dbl)
            for i in range(GFS_PER):
                mid = int.from_bytes(d[i * 4:i * 4 + 4], "little")
                if mid:
                    out.append(mid); m = self.blk(mid); out += [int.from_bytes(m[j * 4:j * 4 + 4], "little") for j in range(GFS_PER)]
        return [b for b in out if b]
    def check(self):
        """fsck: every used block belongs to exactly one inode, every inode is reachable"""
        bad = []; owner = {}; seen = set(); links = {}
        def walk(n, path):
            if n in seen and self.ival(n, 0) == 2: bad.append(f"{path}: directory reached twice"); return
            seen.add(n)
            if self.ival(n, 0) == 2:
                for name, c in self.entries(n):
                    links[c] = links.get(c, 0) + 1
                    if self.ival(c, 0) == 0: bad.append(f"{path}/{name}: points to a free inode {c}")
                    else: walk(c, path.rstrip("/") + "/" + name)
        walk(1, "/")
        for n in range(1, self.icount):
            if self.ival(n, 0) == 0: continue
            if n not in seen: bad.append(f"inode {n}: in use but in no directory")
            if n != 1 and links.get(n, 0) != self.ival(n, 16): bad.append(f"inode {n}: link count {self.ival(n, 16)}, found {links.get(n, 0)}")
            for b in self.blocks_of(n):
                if b in owner: bad.append(f"block {b}: used by inodes {owner[b]} and {n}")
                owner[b] = n
                if not self.map[b]: bad.append(f"block {b} (inode {n}) is marked free")
        for b in range(self.dstart, self.total):
            if self.map[b] and b not in owner: bad.append(f"block {b}: marked used but nobody owns it")
        return bad

def gfs_format(path, kernel, size_mb, ninodes=4096):
    total = max(2048, int(size_mb * 1024 * 1024) // BLOCK)
    kblocks = max(512, (len(kernel) + BLOCK - 1) // BLOCK)
    mstart = 1 + kblocks; mblocks = (total + BLOCK - 1) // BLOCK
    istart = mstart + mblocks; iblocks = ninodes * GFS_INODE // BLOCK
    dstart = istart + iblocks
    le = lambda v: int(v).to_bytes(4, "little")
    with open(path, "wb") as f:
        f.truncate(total * BLOCK)
        sb = (b"GENOMEOS" + le(2) + le(BLOCK) + le(total) + le(BLOCK) + le(len(kernel)) + le(mstart) + le(mblocks)
              + le(istart) + le(ninodes) + le(iblocks) + le(dstart) + le(1)).ljust(64, b"\0")
        f.seek(0); f.write(sb + b"GenomeOS disk - GenomeFS 2, built by GATCnux.py mkimage\0")
        f.seek(BLOCK); f.write(kernel)
        f.seek(mstart * BLOCK); f.write(bytes([1]) * dstart)
        root = bytearray(GFS_INODE); root[0:4] = le(2); root[8:12] = le(int(time.time())); root[12:16] = le(0o755); root[16:20] = le(1)
        f.seek(istart * BLOCK + GFS_INODE); f.write(root)
    return GenomeFS(path)

def cmd_mkimage(argv):
    import argparse
    p = argparse.ArgumentParser(prog="GATCnux.py mkimage", description="build a GenomeOS disk image (GenomeFS)")
    p.add_argument("image"); p.add_argument("--kernel", required=True)
    p.add_argument("files", nargs="*", help="/path/in/image=hostfile  (.aa files under /bin are compiled)")
    p.add_argument("--dir", action="append", default=[], help="/path/in/image=hostdir  copy a whole folder")
    p.add_argument("--size", type=float, default=32, help="disk size in MiB (default 32)")
    a = p.parse_args(argv)
    def compiled(path):
        program, _ = compile_source(open(path, encoding="utf-8", errors="replace").read(), path)
        return encode_bytecode(program)
    kern = open(a.kernel, "rb").read() if a.kernel.lower().endswith(".gbc") else compiled(a.kernel)
    items = []
    for spec in a.files:
        if "=" not in spec: print(f"mkimage: {spec}: use /path=hostfile", file=sys.stderr); return 1
        name, host = spec.split("=", 1); items.append((name, host))
    for spec in a.dir:
        name, host = spec.split("=", 1)
        for root, dirs, files in os.walk(host):
            for fn in sorted(files):
                hp = os.path.join(root, fn); rel = os.path.relpath(hp, host).replace(os.sep, "/")
                items.append((name.rstrip("/") + "/" + rel, hp))
    try:
        fs = gfs_format(a.image, kern, a.size)
        for d in ("/bin", "/home", "/tmp", "/etc"): fs.mkdirs(d)
        for name, host in items:
            if not name.startswith("/"): raise GATCError(f"{name}: paths in the image start with /")
            data = compiled(host) if name.startswith("/bin/") and host.lower().endswith((".aa", ".gatc")) else open(host, "rb").read()
            fs.put(name, data)
        free = fs.free_blocks(); fs.close()
    except (OSError, GATCError) as e: print(f"mkimage: {e}", file=sys.stderr); return 1
    print(f"{a.image}: GenomeFS, {a.size:g} MiB, kernel {len(kern):,} bytes, {len(items)} files, "
          f"{free * BLOCK // 1024:,} KiB free", file=sys.stderr)
    return 0

def cmd_genomefs(argv):
    """genomefs IMAGE ls|tree|cat|get|put|mkdir|rm|df ..."""
    import argparse
    p = argparse.ArgumentParser(prog="GATCnux.py genomefs", description="look inside a GenomeOS disk and copy files in and out")
    p.add_argument("image"); p.add_argument("op", choices=["ls", "tree", "cat", "get", "put", "mkdir", "rm", "df", "check"])
    p.add_argument("args", nargs="*")
    a = p.parse_args(argv)
    try:
        fs = GenomeFS(a.image)
        if a.op in ("ls", "tree"):
            start = a.args[0] if a.args else "/"
            n = fs.lookup(start)
            if not n: raise GATCError(f"{start}: not found")
            def show(n, path, depth):
                for name, c in sorted(fs.entries(n)):
                    t = fs.ival(c, 0)
                    print(f"{'  ' * depth}{name}{'/' if t == 2 else ''}" + ("" if t == 2 else f"  {fs.ival(c, 4):,} bytes"))
                    if t == 2 and a.op == "tree": show(c, path + "/" + name, depth + 1)
            show(n, start, 0)
        elif a.op == "cat":
            n = fs.lookup(a.args[0]); sys.stdout.buffer.write(fs.read_file(n)) if n else print("not found", file=sys.stderr)
        elif a.op == "get":
            n = fs.lookup(a.args[0])
            if not n: raise GATCError(f"{a.args[0]}: not found")
            open(a.args[1], "wb").write(fs.read_file(n))
        elif a.op == "put":
            fs.put(a.args[1], open(a.args[0], "rb").read())
        elif a.op == "mkdir": fs.mkdirs(a.args[0])
        elif a.op == "check":
            bad = fs.check()
            print("\n".join(bad) if bad else "GenomeFS check: everything is consistent")
            fs.f.close(); return 1 if bad else 0
        elif a.op == "rm": fs.remove(a.args[0])
        elif a.op == "df":
            free = fs.free_blocks(); print(f"{fs.total * BLOCK // 1024:,} KiB total, {free * BLOCK // 1024:,} KiB free, "
                                           f"{sum(1 for n in range(1, fs.icount) if fs.ival(n, 0))} of {fs.icount} inodes used")
        fs.close()
    except (OSError, GATCError, IndexError) as e: print(f"genomefs: {e}", file=sys.stderr); return 1
    return 0

def xor_fold(data):
    """xor of all bytes of `data` using big-int folding (fast for megabyte chunks)"""
    if not data: return 0
    size = 1
    while size < len(data): size <<= 1
    v = int.from_bytes(bytes(data) + bytes(size - len(data)), "big"); w = size * 8
    while w > 8:
        w //= 2; v = (v >> w) ^ (v & ((1 << w) - 1))
    return v
def cmd_opcodes():
    by={}
    for c,n in sorted(CODON_TO_OP.items()): by.setdefault(n,[]).append(c)
    print(f"HolyGATC {VERSION} — {len(OPDEF)} opcodes, {len(CODON_TO_OP)} codons\n")
    print(f"{'Sym':<6} {'Name':<7} {'Byte':<6} {'Codon':<8} Stack")
    print("-"*62)
    for sym,name,byte,imm,stack in OPDEF:
        print(f"{sym:<6} {name:<7} 0x{byte:02X}  {','.join(by.get(name,['-'])):<8} {stack}")
def main(argv=None):
    _av = sys.argv[1:] if argv is None else list(argv)
    if _av and _av[0] == "boot": return cmd_boot(_av[1:])
    if _av and _av[0] == "mkimage": return cmd_mkimage(_av[1:])
    if _av and _av[0] == "genomefs": return cmd_genomefs(_av[1:])
    p=argparse.ArgumentParser(prog="gatcload")
    p.add_argument("command", nargs="?", default="help", choices=["run","compile","disasm","translate","opcodes","help","version"])
    p.add_argument("source", nargs="?")
    p.add_argument("-o","--output"); p.add_argument("--dna", action="store_true")
    p.add_argument("--max-steps", type=int, default=STEP_LIMIT_DEFAULT)
    p.add_argument("--no-banner", action="store_true"); p.add_argument("--gene", action="store_true")
    p.add_argument("--load", help="load a binary file into VM memory at address 0")
    p.add_argument("--file", help="open FILE (up to 1 GiB) in the file-backed address space used by hexeditor.aa")
    p.add_argument("--net", action="store_true", help="allow the program to use the network (ping, dig, whois, TCP/TLS) - needed by netkit.aa")
    p.add_argument("--save", help="where the editor's w command writes (default: the --file path, in place)")
    p.add_argument("--fs", action="store_true", help="allow the program to use the file system (ls, cp, mv, rm, ...) - needed by shell.aa")
    p.add_argument("--tty", action="store_true", help="raw keyboard, mouse and fast screen output for the program - needed by paint.aa")
    p.add_argument("--fs-root", metavar="DIR", help="with --fs: start in DIR and refuse paths outside it (best-effort jail)")
    args=p.parse_intermixed_args(argv)
    if args.command=="help" and not args.source:
        print(BANNER); p.print_help()
        print("\n  python3 GATCloader.py run program.aa --no-banner")
        print("  python3 GATCnux.py run netkit.aa --no-banner --net --max-steps 500000000")
        print("  python3 GATCnux.py run shell.aa --no-banner --fs --max-steps 2000000000")
        print("  python3 GATCnux.py run paint.aa --no-banner --tty --fs --max-steps 2000000000")
        print("  python3 GATCload.py run hex.aa --no-banner --load /etc/passwd")
        print("  python3 GATCload.py compile program.aa --dna -o program.dna")
        return 0
    if args.command=="version":
        print(f"HolyGATC {VERSION} — 64 opcodes — 64 codons"); return 0
    if args.command=="opcodes":
        cmd_opcodes(); return 0
    if not args.source: warn("source file required"); return 2
    try:
        text=open(args.source, encoding="utf-8", errors="replace").read()
        if args.command=="translate":
            sys.stdout.write(translate_coding_sequence(text)+"\n"); return 0
        if args.command=="compile":
            program,_ = (compile_gene(text), True) if args.gene else compile_source(text, args.source)
            bc=encode_bytecode(program)
            if args.dna:
                payload=write_fasta(bytecode_to_dna(bc), f"HolyGATC64 genome from {args.source}")
                (open(args.output,"w",encoding="utf-8").write(payload) if args.output else sys.stdout.write(payload))
            else:
                (open(args.output,"wb").write(bc) if args.output else sys.stdout.buffer.write(bc))
            return 0
        if args.command=="disasm":
            if args.gene: program=compile_gene(text)
            elif args.source.lower().endswith(".gbc"): program=decode_bytecode(open(args.source,"rb").read())
            else: program,_=compile_source(text, args.source)
            sys.stdout.write(disasm(program)+"\n"); return 0
        if not args.no_banner: print(BANNER, file=sys.stderr)
        if args.gene: program, genome = compile_gene(text), True
        elif args.source.lower().endswith(".gbc"): program, genome = decode_bytecode(open(args.source,"rb").read()), False
        else: program, genome = compile_source(text, args.source)
        vm = VM(program, genome=genome)
        if args.load:
            vm.load_file(args.load)
        vm.savepath = args.save
        if args.file:
            vm.load_edit_file(args.file)
        if args.net:
            vm.enable_net()
        if args.fs or args.fs_root:
            vm.enable_fs(args.fs_root)
        if args.tty:
            vm.enable_tty()
        try:
            return vm.run(max_steps=args.max_steps)
        except BrokenPipeError:            # e.g. piped into head: stop quietly
            try: sys.stdout = open(os.devnull, "w")
            except OSError: pass
            return 0
        finally:
            if vm.net is not None: vm.net.close()
            if vm.fs is not None: vm.fs.close_all()
            if vm.tty is not None: vm.tty.close()
    except GATCError as e:
        warn(str(e)); return 1
if __name__=="__main__":
    sys.exit(main())
